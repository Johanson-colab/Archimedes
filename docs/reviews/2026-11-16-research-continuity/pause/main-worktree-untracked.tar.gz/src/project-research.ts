export type ResearchItemKind = "paper" | "reproduction" | "run" | "analysis" | "figure" | "manuscript" | "milestone" | "review" | "artifact" | "session";

// These are locators for existing objects, rather than copies of their contents.
export type ResearchEvidenceRef = {
  kind: ResearchItemKind;
  id: string;
  projectId: string;
  dataRoot: string;
  workspaceId?: string | null;
  executionRoot?: string;
  path?: string;
  mainPath?: string;
  sourceVersion?: string;
  reproductionId?: string;
  threadId?: string | null;
  paperId?: string;
  libraryId?: string;
  reviewSource?: "paper" | "manuscript";
};

export type ResearchIndexItem = ResearchEvidenceRef & {
  title: string;
  summary: string;
  updatedAt: string;
  status?: string;
  available: boolean;
};
export type ResearchNoteKind = "conclusion" | "question";
export type ProjectResearchNote = {
  id: string;
  projectId: string;
  kind: ResearchNoteKind;
  text: string;
  evidenceRefs: Array<ResearchEvidenceRef & { title: string; available: boolean }>;
  createdAt: string;
  updatedAt: string;
};
export type ProjectResearchIndex = {
  project: { id: string; name: string; description: string };
  dataRoot: string;
  canEdit: boolean;
  items: ResearchIndexItem[];
  notes: ProjectResearchNote[];
};
export type SaveProjectResearchNoteInput = {
  projectId: string;
  id?: string;
  kind: ResearchNoteKind;
  text: string;
  evidenceRefs: ResearchEvidenceRef[];
};
export type ProjectResearchBridge = {
  listProjectResearchIndex(input: { projectId: string }): Promise<ProjectResearchIndex>;
  saveProjectResearchNote(input: SaveProjectResearchNoteInput): Promise<ProjectResearchNote>;
  deleteProjectResearchNote(input: { projectId: string; id: string }): Promise<{ deleted: boolean }>;
};

export const researchItemLabels: Record<ResearchItemKind, string> = {
  paper: "Papers",
  reproduction: "Reproductions",
  run: "Experiment runs",
  analysis: "Analyses",
  figure: "Figures",
  manuscript: "Manuscripts",
  milestone: "Named manuscript versions",
  review: "Reviews",
  artifact: "Research outputs",
  session: "Research sessions",
};

export function researchEvidenceKey(ref: ResearchEvidenceRef): string {
  return JSON.stringify([ref.kind, ref.id, ref.workspaceId || "", ref.executionRoot || "", ref.path || ref.mainPath || "", ref.reviewSource || ""]);
}

export function filterResearchItems(items: ResearchIndexItem[], kind: ResearchItemKind | "all" | "research", query: string): ResearchIndexItem[] {
  const needle = query.trim().toLocaleLowerCase();
  return items.filter((item) => {
    const matchesKind = kind === "all" || (kind === "research" ? item.kind !== "session" && item.kind !== "artifact" : item.kind === kind);
    return matchesKind && (!needle || `${item.title} ${item.summary} ${item.path || item.mainPath || ""}`.toLocaleLowerCase().includes(needle));
  });
}

export function researchItemStatusLabel(status: string): string {
  const labels: Record<string, string> = { verified: "Checkpoints passed", "checks-passed": "Checkpoints passed", unread: "Unread", reading: "Reading", read: "Already read", draft: "Draft", planned: "Plan ready", running: "Running", queued: "Queued", complete: "Complete", completed: "Complete", failed: "Failed", blocked: "Blocked", cancelled: "Cancelled", interrupted: "Interrupted", stopped: "Stopped", error: "Error" };
  return labels[status] || status;
}
