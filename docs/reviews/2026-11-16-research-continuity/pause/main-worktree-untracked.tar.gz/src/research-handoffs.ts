import { analysisOwnerKey, taskDraftKey, threadTaskSelection, type TaskSelection } from "./task-selection";
import type { AnalysisChatInput, ProjectResultDetail, ResultFigureRequest } from "./project-results";
import type { ManuscriptChatSource, ManuscriptOrigin, ManuscriptSource } from "./manuscript-handoff";

type HandoffContext = {
  bridge: Pick<ResearchDeskBridge, "getProjectResult" | "getResearchThread" | "createResearchThread">;
  workspaces: ProjectWorkspace[];
  getSelection: () => TaskSelection;
  isDataFolderLoading: () => boolean;
  t: (key: string) => string;
};
type DiscussionTarget = { thread: ResearchThreadDetail; selection: TaskSelection; attachment?: ContextAttachment };

/** Prepare domain handoffs; the caller decides which selection and view to show. */
export function createResearchHandoffService() {
  const analysisSessions = new Map<string, string>();
  const analysisPending = new Map<string, Promise<ResearchThreadDetail>>();
  const manuscriptPending = new Map<string, Promise<ResearchThreadDetail>>();

  async function analysisDiscussion(input: AnalysisChatInput, owner: TaskSelection, context: HandoffContext): Promise<DiscussionTarget> {
    const { bridge, workspaces, getSelection, isDataFolderLoading, t } = context;
    if (!owner.projectId || isDataFolderLoading() || getSelection().dataRoot !== owner.dataRoot || getSelection().projectId !== owner.projectId) throw new Error(t("Select a project before continuing the analysis."));
    const result = input.resultId ? await bridge.getProjectResult(input.resultId) : null;
    if (result && (result.kind !== "analysis" || result.projectId !== owner.projectId || result.workspaceId !== owner.workspaceId || result.fileState !== "ready")) throw new Error(t("The saved source does not match this analysis workspace."));
    const sessionOwner = result ? { ...owner, executionRoot: result.executionRoot } : owner;
    const sessionKey = `${analysisOwnerKey(sessionOwner)}:${input.id}`;
    if (isDataFolderLoading() || getSelection().dataRoot !== owner.dataRoot) throw new Error(t("Return to the analysis data folder before attaching its source."));
    let pending = analysisPending.get(sessionKey);
    if (!pending) {
      const threadId = input.threadId || analysisSessions.get(sessionKey);
      pending = threadId ? bridge.getResearchThread(threadId, owner.dataRoot)
        : bridge.createResearchThread({ projectId: owner.projectId, workspaceId: owner.workspaceId || undefined, workspacePath: sessionOwner.executionRoot, basedOnResultId: result?.id, mode: "free-chat", title: `${t("Data analysis")}: ${input.name}` });
      analysisPending.set(sessionKey, pending);
    }
    let thread: ResearchThreadDetail;
    try { thread = await pending; }
    finally { if (analysisPending.get(sessionKey) === pending) analysisPending.delete(sessionKey); }
    const selection = threadTaskSelection(owner.dataRoot, thread, workspaces);
    if (selection.projectId !== owner.projectId || selection.workspaceId !== owner.workspaceId || selection.executionRoot !== sessionOwner.executionRoot) throw new Error(t("The analysis session does not match its project workspace."));
    analysisSessions.set(sessionKey, thread.id);
    let attachment: ContextAttachment | undefined;
    if (input.resultId && input.attachSource && result) {
      if (getSelection().dataRoot !== owner.dataRoot) throw new Error(t("Return to the analysis data folder before attaching its source."));
      const source = result.files.find(file => file.role === "source" && file.path === input.sourcePath);
      if (result.kind !== "analysis" || result.projectId !== selection.projectId || result.workspaceId !== selection.workspaceId || result.executionRoot !== selection.executionRoot || result.fileState !== "ready" || !source) throw new Error(t("The saved source does not match this analysis workspace."));
      attachment = { id: `result:${result.id}:${source.name}`, type: "file", name: input.name, path: `${selection.executionRoot.replace(/[\\/]$/, "")}/${source.path}`, size: source.sizeBytes, detail: t("Complete original dataset. Workspace tools can read this file; the message contains only a summary and sample.") };
    }
    return { thread, selection, attachment };
  }

  async function manuscriptDiscussion(source: ManuscriptChatSource, kind: "discussion" | "revision", context: HandoffContext, storage: Pick<Storage, "getItem" | "setItem">): Promise<DiscussionTarget> {
    const { bridge, workspaces, getSelection, isDataFolderLoading, t } = context;
    if (isDataFolderLoading() || getSelection().dataRoot !== source.dataRoot) throw new Error(t("Return to the manuscript data folder before continuing."));
    const cacheKey = `archimedes-manuscript-chat:${JSON.stringify([source.dataRoot, source.projectId, source.workspaceId, source.workspace, source.mainPath, kind])}`;
    let pending = manuscriptPending.get(cacheKey);
    if (!pending) {
      pending = (async () => {
        let stored: string | null = null;
        try { stored = storage.getItem(cacheKey); } catch { /* Session persistence is optional. */ }
        if (stored) {
          try { return await bridge.getResearchThread(stored, source.dataRoot); }
          catch (reason) { if (!/not found|no longer exists/i.test(String(reason))) throw reason; }
        }
        if (getSelection().dataRoot !== source.dataRoot || isDataFolderLoading()) throw new Error(t("Return to the manuscript data folder before continuing."));
        return bridge.createResearchThread({ projectId: source.projectId, workspaceId: source.workspaceId, workspacePath: source.workspace, basedOnThreadId: source.threadId || undefined, mode: "paper-generation", title: `${kind === "revision" ? t("Manuscript revision") : t("Manuscript discussion")}: ${source.mainPath}` });
      })();
      manuscriptPending.set(cacheKey, pending);
    }
    let thread: ResearchThreadDetail;
    try { thread = await pending; }
    finally { if (manuscriptPending.get(cacheKey) === pending) manuscriptPending.delete(cacheKey); }
    const selection = threadTaskSelection(source.dataRoot, thread, workspaces);
    if (selection.projectId !== source.projectId || selection.workspaceId !== source.workspaceId || selection.executionRoot !== source.workspace) throw new Error(t("The manuscript session does not match its source workspace."));
    try { storage.setItem(cacheKey, thread.id); } catch { /* The in-memory task still works. */ }
    const filePath = source.selectedPath || source.mainPath;
    const attachment: ContextAttachment = { id: `file:${source.workspace}/${filePath}`, type: "file", name: filePath.split("/").at(-1) || filePath, path: `${source.workspace.replace(/[\\/]$/, "")}/${filePath}`, detail: `LaTeX manuscript source · ${filePath}` };
    return { thread, selection, attachment };
  }

  async function figureInsertion(result: ProjectResultDetail, fileName: string, context: HandoffContext): Promise<ResultFigureRequest | null> {
    const selected = context.getSelection();
    if (!selected.projectId || result.projectId !== selected.projectId || result.fileState !== "ready" || !result.files.some(file => file.name === fileName && file.role === "output" && file.fileState === "ready")) throw new Error(context.t("Save a current figure in the selected project before inserting it."));
    const checked = await context.bridge.getProjectResult(result.id);
    if (taskDraftKey(context.getSelection()) !== taskDraftKey(selected) || checked.projectId !== selected.projectId || checked.fileState !== "ready") return null;
    return { dataRoot: selected.dataRoot, projectId: checked.projectId, resultId: checked.id, fileName, title: checked.title, token: crypto.randomUUID() };
  }

  return { analysisDiscussion, manuscriptDiscussion, figureInsertion };
}

export function manuscriptHandoffOrigin(source: ManuscriptSource, selection: TaskSelection, loading: boolean, t: (key: string) => string): ManuscriptOrigin {
  if (loading || !selection.workspaceId || selection.projectId !== source.projectId || selection.executionRoot !== source.workspace) throw new Error(t("Return to the source manuscript project before handing it off."));
  return { ...source, dataRoot: selection.dataRoot, workspaceId: selection.workspaceId, threadId: selection.threadId };
}

export function manuscriptRevisionPrompt(run: PaperReviewRunSummary, findings: PaperReviewFinding[]): string {
  const origin = run.manuscript!;
  return ["Plan a manuscript revision using this selected simulated-review feedback. Preserve the current manuscript until I approve specific edits.", `Reviewed manuscript: ${origin.mainPath}`, `Reviewed source version: ${origin.sourceVersion}`, `Reviewed PDF SHA256: ${origin.pdfSha256}`, `Review run: ${run.id}`, `Source snapshot: ${origin.manifestPath}`, "Compare the current sources with the reviewed version before proposing changes.", ...findings.map((finding, index) => `${index + 1}. ${finding.text}${finding.page ? `\nPDF page: ${finding.page}` : ""}${finding.quote ? `\nEvidence quote: ${finding.quote}` : ""}${finding.severity ? `\nSeverity: ${finding.severity}` : ""}`)].join("\n\n");
}
