import { useCallback, useEffect, useMemo, useState } from "react";
import { ArrowUpRight, BookOpen, ChartNoAxesCombined, ClipboardCheck, FileText, FlaskConical, Image, MessageSquare, NotebookPen, Plus, RefreshCw, Search } from "lucide-react";
import { useUISettings } from "./i18n";
import { Dialog } from "./Dialog";
import { InlineNotice } from "./InlineNotice";
import { StateView } from "./StateView";
import { filterResearchItems, researchEvidenceKey, researchItemLabels, researchItemStatusLabel, type ProjectResearchBridge, type ProjectResearchIndex, type ProjectResearchNote, type ResearchEvidenceRef, type ResearchIndexItem, type ResearchItemKind, type ResearchNoteKind } from "./project-research";
import "./project-research.css";

type Props = { bridge: ProjectResearchBridge; projectId: string; dataRoot: string; onOpenItem: (item: ResearchIndexItem) => void | Promise<void> };
const itemIcons = { paper: BookOpen, reproduction: FlaskConical, run: FlaskConical, analysis: ChartNoAxesCombined, figure: Image, manuscript: FileText, milestone: FileText, review: ClipboardCheck, artifact: FileText, session: MessageSquare };

export default function ProjectResearchView(props: Props) {
  return <ProjectResearchContent key={`${props.dataRoot}:${props.projectId}`} {...props} />;
}

function ProjectResearchContent({ bridge, projectId, onOpenItem }: Props) {
  const { t, language } = useUISettings();
  const [index, setIndex] = useState<ProjectResearchIndex | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [query, setQuery] = useState("");
  const [kind, setKind] = useState<ResearchItemKind | "all" | "research">("research");
  const [editor, setEditor] = useState<{ note?: ProjectResearchNote; kind: ResearchNoteKind } | null>(null);
  const reload = useCallback(async () => {
    setLoading(true); setError("");
    try { setIndex(await bridge.listProjectResearchIndex({ projectId })); }
    catch (reason) { setError(String(reason)); }
    finally { setLoading(false); }
  }, [bridge, projectId]);
  useEffect(() => { void reload(); }, [reload]);
  const filtered = useMemo(() => filterResearchItems(index?.items || [], kind, query), [index?.items, kind, query]);
  const kinds = Object.keys(researchItemLabels) as ResearchItemKind[];
  const counts = new Map(kinds.map(value => [value, index?.items.filter(item => item.kind === value).length || 0]));
  const formatDate = (value: string) => value ? new Date(value).toLocaleDateString(language === "zh" ? "zh-CN" : "en", { month: "short", day: "numeric", year: "numeric" }) : "";
  async function open(item: ResearchIndexItem) {
    setError("");
    try { await onOpenItem(item); } catch (reason) { setError(String(reason)); }
  }
  async function remove(note: ProjectResearchNote) {
    await bridge.deleteProjectResearchNote({ projectId, id: note.id }); await reload();
  }

  return <main className="project-research-view">
    <header className="project-research-header">
      <div><span className="project-research-eyebrow">{t("Project research")}</span><h1>{index?.project.name || t("Loading project…")}</h1><p>{index?.project.description || t("Return to the papers, experiments and drafts behind your work.")}</p></div>
      <button className="secondary-button" disabled={loading} onClick={() => void reload()} aria-label={t("Refresh project research")}><RefreshCw size={14} />{t("Refresh")}</button>
    </header>
    {error && <InlineNotice tone="danger">{error}</InlineNotice>}
    {loading && !index && <StateView tone="loading" title={t("Loading project research…")} />}
    {index && <div className="project-research-layout">
      <section className="project-research-work" aria-labelledby="project-research-work-heading">
        <div className="project-research-section-heading"><div><h2 id="project-research-work-heading">{t("Research work")}</h2><p>{t("Open the original item to continue. Entries stay in their existing tools.")}</p></div><span>{index.items.length}</span></div>
        <div className="project-research-filters">
          <label className="project-research-search"><Search size={15} /><input aria-label={t("Search project research")} placeholder={t("Search papers, results and drafts")} value={query} onChange={event => setQuery(event.target.value)} /></label>
          <select aria-label={t("Research work type")} value={kind} onChange={event => setKind(event.target.value as ResearchItemKind | "all" | "research")}><option value="research">{t("Papers, results & drafts")}</option><option value="all">{t("All research work")}</option>{kinds.filter(value => counts.get(value)).map(value => <option value={value} key={value}>{t(researchItemLabels[value])} · {counts.get(value)}</option>)}</select>
        </div>
        {!filtered.length ? <StateView compact icon={<NotebookPen size={23} />} title={t(index.items.length ? "No matching research work" : "Your research work will appear here")} description={t(index.items.length ? "Try a different search or work type." : "Collect a paper, save an analysis or open a manuscript in this project.")} /> : <div className="project-research-items">{filtered.map(item => {
          const Icon = itemIcons[item.kind];
          return <article className="project-research-item" key={researchEvidenceKey(item)}>
            <span className="project-research-item-icon"><Icon size={19} strokeWidth={1.6} /></span>
            <div className="project-research-item-copy"><div className="project-research-item-meta"><span>{t(researchItemLabels[item.kind])}</span>{item.status && <span>{t(researchItemStatusLabel(item.status))}</span>}<time dateTime={item.updatedAt}>{formatDate(item.updatedAt)}</time></div><button className="project-research-item-title" onClick={() => void open(item)}>{item.title}<ArrowUpRight size={14} /></button>{(item.summary || item.mainPath || item.path) && <p title={item.summary || item.mainPath || item.path}>{item.summary || item.mainPath || item.path}</p>}{item.sourceVersion && <small>{t("Source version")} · {item.sourceVersion.slice(0, 12)}</small>}</div>
          </article>;
        })}</div>}
      </section>
      <aside className="project-research-notes" aria-labelledby="project-research-notes-heading">
        <div className="project-research-section-heading"><div><h2 id="project-research-notes-heading">{t("Conclusions & questions")}</h2><p>{t("Your interpretation, linked to the work you choose.")}</p></div></div>
        {index.canEdit && <div className="project-research-note-actions"><button className="secondary-button" onClick={() => setEditor({ kind: "conclusion" })}><Plus size={13} />{t("Conclusion")}</button><button className="secondary-button" onClick={() => setEditor({ kind: "question" })}><Plus size={13} />{t("Open question")}</button></div>}
        {!index.notes.length && <StateView compact title={t("What have you learned?")} description={t("Keep a current conclusion or the next question to investigate. Add evidence when you have it.")} />}
        <div className="project-research-note-list">{index.notes.map(note => <article className="project-research-note" key={note.id}>
          <div className="project-research-note-label"><span>{t(note.kind === "conclusion" ? "Current conclusion" : "Open question")}</span>{index.canEdit && <button onClick={() => setEditor({ note, kind: note.kind })}>{t("Edit")}</button>}</div>
          <p className="project-research-note-text">{note.text}</p>
          {note.evidenceRefs.length ? <ul className="project-research-evidence">{note.evidenceRefs.map(ref => {
            const item = index.items.find(candidate => researchEvidenceKey(candidate) === researchEvidenceKey(ref));
            return <li key={researchEvidenceKey(ref)}><button disabled={!ref.available || !item} onClick={() => item && void open(item)}>{ref.title}<ArrowUpRight size={12} /></button>{!ref.available && <small>{t("Evidence unavailable in this project")}</small>}</li>;
          })}</ul> : <small className="project-research-no-evidence">{t("No linked evidence")}</small>}
          <time className="project-research-note-date" dateTime={note.updatedAt}>{formatDate(note.updatedAt)}</time>
        </article>)}</div>
      </aside>
    </div>}
    {editor && index && <ResearchNoteEditor key={editor.note?.id || editor.kind} projectId={projectId} editor={editor} items={index.items} onClose={() => setEditor(null)} onSave={async input => { await bridge.saveProjectResearchNote(input); setEditor(null); await reload(); }} onDelete={editor.note ? async () => { await remove(editor.note!); setEditor(null); } : undefined} />}
  </main>;
}

function ResearchNoteEditor({ projectId, editor, items, onClose, onSave, onDelete }: { projectId: string; editor: { note?: ProjectResearchNote; kind: ResearchNoteKind }; items: ResearchIndexItem[]; onClose: () => void; onSave: ProjectResearchBridge["saveProjectResearchNote"] | ((input: Parameters<ProjectResearchBridge["saveProjectResearchNote"]>[0]) => Promise<void>); onDelete?: () => Promise<void> }) {
  const { t } = useUISettings();
  const [kind, setKind] = useState(editor.kind);
  const [text, setText] = useState(editor.note?.text || "");
  const [refs, setRefs] = useState<ResearchEvidenceRef[]>(editor.note?.evidenceRefs || []);
  const [query, setQuery] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const choices = filterResearchItems(items, "all", query);
  const selected = new Set(refs.map(researchEvidenceKey));
  const missing = (editor.note?.evidenceRefs || []).filter(ref => !ref.available && selected.has(researchEvidenceKey(ref)));
  function toggle(ref: ResearchEvidenceRef) { const key = researchEvidenceKey(ref); setRefs(current => selected.has(key) ? current.filter(item => researchEvidenceKey(item) !== key) : [...current, ref]); }
  async function save() {
    setBusy(true); setError("");
    try { await onSave({ projectId, id: editor.note?.id, kind, text, evidenceRefs: refs }); }
    catch (reason) { setError(String(reason)); setBusy(false); }
  }
  return <Dialog open onClose={busy ? () => {} : onClose} size="lg" ariaLabel={t(editor.note ? "Edit research note" : "Add research note")} className="research-note-dialog">
    <header><h2>{t(editor.note ? "Edit research note" : "Add research note")}</h2></header>
    <div className="research-note-fields"><label>{t("Note type")}<select value={kind} disabled={busy} onChange={event => setKind(event.target.value as ResearchNoteKind)}><option value="conclusion">{t("Current conclusion")}</option><option value="question">{t("Open question")}</option></select></label><label>{t("Research note")}<textarea autoFocus rows={4} value={text} disabled={busy} placeholder={t("Write what you currently think or want to investigate.")} onChange={event => setText(event.target.value)} /></label></div>
    <section className="research-note-evidence-picker"><h3>{t("Link existing evidence")}</h3><p>{t("Choose the papers, runs, results or manuscript versions behind this note.")}</p><label className="project-research-search"><Search size={14} /><input value={query} disabled={busy} aria-label={t("Search evidence")} placeholder={t("Search evidence")} onChange={event => setQuery(event.target.value)} /></label><div className="research-note-evidence-choices">{choices.map(item => <label key={researchEvidenceKey(item)}><input type="checkbox" disabled={busy} checked={selected.has(researchEvidenceKey(item))} onChange={() => toggle(item)} /><span><strong>{item.title}</strong><small>{t(researchItemLabels[item.kind])}{item.mainPath ? ` · ${item.mainPath}` : ""}{item.sourceVersion ? ` · ${item.sourceVersion.slice(0, 12)}` : ""}</small></span></label>)}{!choices.length && <p>{t("No matching evidence")}</p>}{missing.map(ref => <label key={researchEvidenceKey(ref)}><input type="checkbox" disabled={busy} checked onChange={() => toggle(ref)} /><span><strong>{ref.title}</strong><small>{t("Evidence unavailable in this project")}</small></span></label>)}</div></section>
    {error && <InlineNotice tone="danger">{error}</InlineNotice>}
    <footer className="research-note-editor-actions">{onDelete && <button className="text-button research-note-delete" disabled={busy} onClick={() => { setBusy(true); void onDelete().catch(reason => { setError(String(reason)); setBusy(false); }); }}>{t("Delete note")}</button>}<button className="secondary-button" disabled={busy} onClick={onClose}>{t("Cancel")}</button><button className="primary-button" disabled={busy || !text.trim()} onClick={() => void save()}>{t(busy ? "Saving…" : "Save research note")}</button></footer>
  </Dialog>;
}
