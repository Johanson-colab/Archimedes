# Project research

Open **Project research** under a project in the sidebar, or from its project
menu. This is the project's overview: papers, reproductions and their recorded
runs, saved analyses and figures, manuscripts, named manuscript versions, and
reviews. Search by title or source path, or select a type. Ordinary conversations
and conversation outputs are available through the type filter so they do not
crowd the initial research list.

Choose an entry to return to the original paper, run, analysis, manuscript or
review. The overview reads those existing objects; it does not make independent
copies of them. A named manuscript version opens that saved version's comparison
and restore view, while a manuscript entry opens its current source.

Use **Conclusion** or **Open question** to keep a short, editable account of your
current understanding. Select the existing papers, runs, results or manuscript
versions that informed it. These notes record your interpretation; saving or
linking a note does not certify a scientific claim. Notes can also be saved
without evidence while a question is still being investigated.

Notes belong to the project and remain available after restarting the app. If
an associated object is removed, its saved reference is marked unavailable; the
note remains editable. Project editors can add, edit and delete notes. Viewers
can read them, and archived projects must be restored before editing.

Project packages include these notes and their evidence references. Imported
references are rebound to the restored project's objects and folders. If a
source category was excluded from the package, its reference remains visible as
unavailable. The **Named manuscript versions** package option carries the saved
historical files as well as their labels; a saved version can be explicitly
restored even when the current manuscript files were not selected for export.
