const test = require("node:test");
const assert = require("node:assert/strict");
const fs = require("node:fs"), path = require("node:path"), os = require("node:os");
const { JSDOM } = require("jsdom");
const store = require("./store.cjs");

test("the project view saves and reopens a linked conclusion, filters work, and returns the actual source locator", async t => {
  const directory = fs.realpathSync(fs.mkdtempSync(path.join(os.tmpdir(), "archimedes-research-view-")));
  const dom = new JSDOM('<div id="root"></div>', { url: "http://localhost" });
  global.window = dom.window; global.document = dom.window.document; global.IS_REACT_ACT_ENVIRONMENT = true;
  const React = require("react"), { createRoot } = require("react-dom/client");
  let root = createRoot(document.getElementById("root")), owner = store.createWorkspaceStore(directory);
  t.after(async () => { await React.act(async () => root.unmount()); store.closeAllWorkspaces(); dom.window.close(); delete global.window; delete global.document; delete global.IS_REACT_ACT_ENVIRONMENT; fs.rmSync(directory, { recursive: true, force: true }); });
  const project = owner.createResearchProject({ name: "Retention study", workspacePath: directory }), other = owner.createResearchProject({ name: "Another study", workspacePath: directory });
  const library = owner.createLibrary({ projectId: project.id, name: "Papers" }), paper = owner.addPaper(library.id, { title: "Source of the retention result", doi: "10.1000/ui-retention" });
  owner.createResearchThread({ projectId: project.id, prompt: "Conversation with intermediate notes", mode: "free-chat" });
  const helpers = await import("../src/project-research.ts"), { transformWithOxc } = await import("vite");
  const source = fs.readFileSync(path.join(__dirname, "../src/ProjectResearchView.tsx"), "utf8").replace(/^import .*;\n/gm, "").replace(/^export default /gm, "");
  const { code } = await transformWithOxc(source, "ProjectResearchView.tsx", { jsx: { runtime: "classic" } });
  const scope = { React, ...React, ...helpers, ...require("lucide-react"), Map, Set, useUISettings: () => ({ t: key => key, language: "en" }), Dialog: ({ open, children, ariaLabel }) => open ? React.createElement("section", { role: "dialog", "aria-label": ariaLabel }, children) : null,
    InlineNotice: ({ children }) => React.createElement("div", { role: "alert" }, children), StateView: ({ title, description }) => React.createElement("div", null, title, description) };
  const View = new Function(...Object.keys(scope), `${code}\nreturn ProjectResearchView;`)(...Object.values(scope));
  const bridge = { listProjectResearchIndex: async input => owner.listProjectResearchIndex(input), saveProjectResearchNote: async input => owner.saveProjectResearchNote(input), deleteProjectResearchNote: async input => owner.deleteProjectResearchNote(input) }, opened = [];
  const props = { bridge, projectId: project.id, dataRoot: directory, onOpenItem: item => opened.push(item) };
  const button = text => [...document.querySelectorAll("button")].find(element => element.textContent.trim() === text);
  async function change(element, value) {
    await React.act(async () => { Object.getOwnPropertyDescriptor(element.tagName === "TEXTAREA" ? dom.window.HTMLTextAreaElement.prototype : element.tagName === "SELECT" ? dom.window.HTMLSelectElement.prototype : dom.window.HTMLInputElement.prototype, "value").set.call(element, value); element.dispatchEvent(new dom.window.Event(element.tagName === "SELECT" ? "change" : "input", { bubbles: true })); });
  }
  await React.act(async () => root.render(React.createElement(View, props)));
  assert.match(document.querySelector("h1").textContent, /Retention study/);
  assert.equal(document.querySelectorAll(".project-research-item").length, 1, "ordinary sessions are available through filters without dominating the initial research list");
  await React.act(async () => button("Conclusion").click());
  await change(document.querySelector("textarea"), "The observed difference needs a larger sample.");
  await React.act(async () => [...document.querySelectorAll('.research-note-evidence-choices label')].find(label => label.textContent.includes(paper.title)).querySelector('input[type="checkbox"]').click());
  await React.act(async () => button("Save research note").click());
  assert.equal(document.querySelector('[role="dialog"]'), null);
  assert.match(document.querySelector(".project-research-note-text").textContent, /larger sample/);
  await React.act(async () => root.unmount());
  owner.close(); owner = store.createWorkspaceStore(directory); root = createRoot(document.getElementById("root"));
  await React.act(async () => root.render(React.createElement(View, props)));
  await React.act(async () => document.querySelector(".project-research-evidence button").click());
  assert.equal(opened[0].id, paper.id); assert.equal(opened[0].libraryId, library.id); assert.equal(opened[0].projectId, project.id);
  await change(document.querySelector('select[aria-label="Research work type"]'), "session");
  assert.equal(document.querySelectorAll(".project-research-item").length, 1); assert.match(document.querySelector(".project-research-item").textContent, /Conversation with intermediate notes/);
  await React.act(async () => button("Edit").click());
  await change(document.querySelector("textarea"), "Does the effect survive a larger sample?");
  await change(document.querySelector(".research-note-fields select"), "question");
  await React.act(async () => button("Save research note").click());
  assert.equal(owner.listProjectResearchIndex({ projectId: project.id }).notes[0].kind, "question");
  await React.act(async () => root.render(React.createElement(View, { ...props, projectId: other.id })));
  assert.match(document.querySelector("h1").textContent, /Another study/); assert.equal(document.querySelector(".project-research-note"), null);
});
