const test = require("node:test");
const assert = require("node:assert/strict");
const fs = require("node:fs"), os = require("node:os"), path = require("node:path");
const { DatabaseSync } = require("node:sqlite");
const store = require("./store.cjs");
const history = require("./paper-writing-history.cjs");
const transfer = require("./project-transfer.cjs");
const results = require("./project-results.cjs");
const vm = require("node:vm");
const { createWorkspaceIpc } = require("./workspace-context.cjs");
const { registerProjectResearchCommands } = require("./project-research-commands.cjs");

function fixture(t) {
  const directory = fs.realpathSync(fs.mkdtempSync(path.join(os.tmpdir(), "archimedes-research-index-")));
  const make = name => { const root = path.join(directory, name); fs.mkdirSync(root); return root; };
  const dataRoot = make("data"), executionRoot = make("execution"), owner = store.createWorkspaceStore(dataRoot);
  const project = owner.createResearchProject({ name: "Retention study", workspacePath: executionRoot }), workspace = owner.defaultProjectWorkspace(project.id);
  const library = owner.createLibrary({ name: "Evidence", projectId: project.id }), paper = owner.addPaper(library.id, { title: "Retention in local workflows", doi: "10.1000/retention" });
  const thread = owner.createResearchThread({ projectId: project.id, workspaceId: workspace.id, title: "Inspect source data", mode: "free-chat" });
  fs.mkdirSync(path.join(executionRoot, "paper")); fs.writeFileSync(path.join(executionRoot, "paper/main.tex"), "\\documentclass{article}\n\\title{Retention study}\n\\begin{document}First result\\end{document}\n");
  const version = history.saveManuscriptVersion({ dataRoot, executionRoot, projectId: project.id, workspaceId: workspace.id, threadId: thread.id, mainPath: "paper/main.tex", name: "Before adviser review" });
  const result = results.savePackage({ id: "analysis-index-fixture", projectId: project.id, workspaceId: workspace.id, executionRoot, threadId: thread.id, kind: "analysis", title: "Retention comparison", manifest: { version: 1, config: { x: 0, y: 1 } }, files: [{ name: "source.csv", role: "source", encoding: "utf8", content: "group,retained\na,8\nb,6\n" }] });
  owner.registerProjectResult(result);
  const reproduction = owner.createReproduction({ projectId: project.id, workspaceId: workspace.id, paperId: paper.id, title: "Reproduce retention", repoUrl: "https://example.invalid/research" });
  const run = owner.createReproductionRun({ reproductionId: reproduction.id, status: "verified", backend: "local" });
  const second = owner.createResearchProject({ name: "Separate project", workspacePath: make("separate") });
  const options = { listManuscriptVersions: history.listProjectManuscriptVersions, listManuscriptVersionOwners: history.listProjectManuscriptVersionOwners };
  t.after(() => { store.closeAllWorkspaces(); fs.rmSync(directory, { recursive: true, force: true }); });
  return { directory, make, dataRoot, executionRoot, owner, project, workspace, library, paper, thread, version, result, reproduction, run, second, options };
}

test("the project index projects existing objects and saves editable evidence notes across a real database reopen", t => {
  const f = fixture(t), index = f.owner.listProjectResearchIndex({ projectId: f.project.id }, f.options);
  for (const [kind, id] of [["paper", f.paper.id], ["analysis", f.result.id], ["reproduction", f.reproduction.id], ["run", f.run.id], ["milestone", f.version.id], ["session", f.thread.id], ["manuscript", "paper/main.tex"]]) assert.ok(index.items.some(item => item.kind === kind && item.id === id), `${kind} opens the existing domain object`);
  assert.equal(index.items.find(item => item.kind === "milestone").threadId, f.thread.id);
  const evidenceRefs = index.items.filter(item => item.kind === "paper" || item.kind === "run");
  const saved = f.owner.saveProjectResearchNote({ projectId: f.project.id, kind: "conclusion", text: "The measured retention differs by group.", evidenceRefs }, f.options);
  assert.equal(saved.evidenceRefs.length, 2); assert.ok(saved.evidenceRefs.every(ref => ref.available));
  f.owner.close();
  const reopened = store.createWorkspaceStore(f.dataRoot), loaded = reopened.listProjectResearchIndex({ projectId: f.project.id }, f.options);
  assert.equal(loaded.notes[0].text, saved.text); assert.deepEqual(loaded.notes[0].evidenceRefs, saved.evidenceRefs);
  const edited = reopened.saveProjectResearchNote({ ...loaded.notes[0], text: "Does the difference survive a larger sample?", kind: "question" }, f.options);
  assert.equal(edited.id, saved.id); assert.equal(edited.kind, "question");
  assert.equal(reopened.listProjectResearchIndex({ projectId: f.second.id }, f.options).notes.length, 0);
  assert.throws(() => reopened.saveProjectResearchNote({ projectId: f.second.id, kind: "conclusion", text: "Wrong owner", evidenceRefs }), /current project/);
  assert.throws(() => reopened.saveProjectResearchNote({ projectId: f.second.id, id: saved.id, kind: "question", text: "Wrong note", evidenceRefs: [] }), /does not belong/);
});

test("a removed source stays an explicitly unavailable reference while the interpretation remains editable", t => {
  const f = fixture(t), paper = f.owner.listProjectResearchIndex({ projectId: f.project.id }, f.options).items.find(item => item.kind === "paper");
  const note = f.owner.saveProjectResearchNote({ projectId: f.project.id, kind: "question", text: "Check this paper's claim", evidenceRefs: [paper] }, f.options);
  f.owner.removePaper(f.library.id, f.paper.id);
  const loaded = f.owner.listProjectResearchIndex({ projectId: f.project.id }, f.options).notes[0];
  assert.equal(loaded.evidenceRefs[0].available, false); assert.equal(loaded.evidenceRefs[0].title, paper.title);
  const saved = f.owner.saveProjectResearchNote({ ...loaded, text: "Revisit the removed source before deciding." }, f.options);
  assert.equal(saved.evidenceRefs[0].available, false);
  assert.equal(f.owner.deleteProjectResearchNote({ projectId: f.project.id, id: note.id }).deleted, true);
});

test("project packages rebind notes, run/result evidence and named manuscript versions to the restored project", t => {
  const f = fixture(t), index = f.owner.listProjectResearchIndex({ projectId: f.project.id }, f.options);
  const refs = index.items.filter(item => ["paper", "analysis", "run", "milestone"].includes(item.kind));
  f.owner.saveProjectResearchNote({ projectId: f.project.id, kind: "conclusion", text: "A bounded result, pending further evidence.", evidenceRefs: refs }, f.options);
  const sourceDb = new DatabaseSync(path.join(f.dataRoot, ".archimedes/archimedes.db")), targetRoot = f.make("target"), target = store.createWorkspaceStore(targetRoot), targetDb = new DatabaseSync(path.join(targetRoot, ".archimedes/archimedes.db"));
  t.after(() => { sourceDb.close(); targetDb.close(); });
  const exported = transfer.exportProject(sourceDb, f.project.id, { dataRoot: f.dataRoot, userId: "local-user", destinationParent: f.make("exported") });
  assert.equal(exported.counts.project_research_notes, 1); assert.equal(exported.counts.manuscript_versions, 1);
  const imported = transfer.importProject(targetDb, exported.path, { dataRoot: targetRoot, userId: "local-user", targetParent: f.make("restored") });
  const restored = target.listProjectResearchIndex({ projectId: imported.projectId }, f.options), note = restored.notes[0];
  assert.equal(note.text, "A bounded result, pending further evidence.");
  assert.ok(note.evidenceRefs.every(ref => ref.projectId === imported.projectId && ref.dataRoot === targetRoot && ref.available));
  for (const ref of note.evidenceRefs) assert.ok(!refs.some(original => original.id === ref.id), "restored evidence uses new domain IDs");
  const milestone = restored.items.find(item => item.kind === "milestone");
  assert.equal(milestone.title, f.version.name); assert.equal(milestone.executionRoot, imported.workspacePath);
  const comparison = history.compareManuscriptVersion({ ...milestone, id: milestone.id });
  assert.ok(comparison.changes.some(change => change.path === "paper/main.tex" && change.status === "removed"));
  history.restoreManuscriptVersion({ ...milestone, expectedSourceVersion: comparison.currentSourceVersion });
  assert.match(fs.readFileSync(path.join(imported.workspacePath, "paper/main.tex"), "utf8"), /First result/);
});

test("the actual preload and IPC save to the window's project store and reopen the same evidence", async t => {
  const f = fixture(t), handlers = new Map();
  let selected = f.dataRoot, bridge;
  const ipcMain = createWorkspaceIpc({ ipcMain: { handle: (channel, callback) => handlers.set(channel, callback) }, store, workspaceForEvent: () => selected });
  registerProjectResearchCommands({ ipcMain, store, listManuscriptVersions: history.listProjectManuscriptVersions });
  vm.runInNewContext(fs.readFileSync(path.join(__dirname, "preload.cjs"), "utf8"), { process, require(name) { assert.equal(name, "electron"); return { contextBridge: { exposeInMainWorld: (_name, value) => { bridge = value; } }, ipcRenderer: { invoke: (channel, input) => Promise.resolve().then(() => handlers.get(channel)({ sender: { id: 1 } }, input)) } }; } });
  const index = await bridge.listProjectResearchIndex({ projectId: f.project.id }), evidence = index.items.find(item => item.kind === "milestone");
  const saved = await bridge.saveProjectResearchNote({ projectId: f.project.id, kind: "question", text: "What changed after this draft?", evidenceRefs: [evidence] });
  assert.equal((await bridge.listProjectResearchIndex({ projectId: f.project.id })).notes[0].evidenceRefs[0].id, f.version.id);
  selected = f.make("other-data"); store.createWorkspaceStore(selected);
  await assert.rejects(bridge.listProjectResearchIndex({ projectId: f.project.id }), /access/);
  selected = f.dataRoot;
  assert.equal((await bridge.deleteProjectResearchNote({ projectId: f.project.id, id: saved.id })).deleted, true);
});

test("a standalone named manuscript remains indexed and migrates after the default folder changes", t => {
  const f = fixture(t), originalRoot = f.make("standalone-original"), currentRoot = f.make("standalone-current");
  const project = f.owner.createResearchProject({ name: "Standalone manuscript", workspacePath: originalRoot }), workspace = f.owner.defaultProjectWorkspace(project.id);
  fs.writeFileSync(path.join(originalRoot, "main.tex"), "\\documentclass{article}\n\\begin{document}A standalone draft\\end{document}\n");
  const version = history.saveManuscriptVersion({ dataRoot: f.dataRoot, projectId: project.id, workspaceId: workspace.id, executionRoot: originalRoot, mainPath: "main.tex", name: "Standalone milestone" });
  f.owner.setResearchProjectWorkspace(project.id, currentRoot);
  const indexed = f.owner.listProjectResearchIndex({ projectId: project.id }, f.options).items.find(item => item.kind === "milestone");
  assert.equal(indexed.id, version.id); assert.equal(indexed.executionRoot, originalRoot); assert.equal(indexed.threadId, null);
  const sourceDb = new DatabaseSync(path.join(f.dataRoot, ".archimedes/archimedes.db")), targetRoot = f.make("standalone-target"), target = store.createWorkspaceStore(targetRoot), targetDb = new DatabaseSync(path.join(targetRoot, ".archimedes/archimedes.db"));
  t.after(() => { sourceDb.close(); targetDb.close(); });
  const exported = transfer.exportProject(sourceDb, project.id, { dataRoot: f.dataRoot, userId: "local-user", destinationParent: f.make("standalone-export") });
  assert.equal(exported.counts.manuscript_versions, 1);
  const imported = transfer.importProject(targetDb, exported.path, { dataRoot: targetRoot, userId: "local-user", targetParent: f.make("standalone-restored") });
  const restored = target.listProjectResearchIndex({ projectId: imported.projectId }, f.options).items.find(item => item.kind === "milestone");
  assert.equal(restored.title, version.name); assert.notEqual(restored.executionRoot, currentRoot);
  assert.ok(restored.executionRoot.startsWith(imported.workspacePath));
});
