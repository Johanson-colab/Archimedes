function registerProjectResearchCommands({ ipcMain, store, reviewDbPath, listManuscriptVersions, listManuscriptVersionOwners }) {
  const options = { reviewDbPath, listManuscriptVersions, listManuscriptVersionOwners };
  ipcMain.handle("project-research:list", (_event, input = {}) => store.listProjectResearchIndex(input, options));
  ipcMain.handle("project-research:save-note", (_event, input = {}) => store.saveProjectResearchNote(input, options));
  ipcMain.handle("project-research:delete-note", (_event, input = {}) => store.deleteProjectResearchNote(input));
}

module.exports = { registerProjectResearchCommands };
