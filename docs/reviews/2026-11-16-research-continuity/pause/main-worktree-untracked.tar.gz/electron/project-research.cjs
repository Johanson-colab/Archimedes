const fs = require("node:fs");
const path = require("node:path");
const { randomUUID } = require("node:crypto");
const { DatabaseSync } = require("node:sqlite");
const { listLatexProjects } = require("./latex-workspace.cjs");

function ensureSchema(db) {
  db.exec(`CREATE TABLE IF NOT EXISTS project_research_notes (
    id TEXT PRIMARY KEY NOT NULL,
    project_id TEXT NOT NULL REFERENCES research_projects(id) ON DELETE CASCADE,
    kind TEXT NOT NULL CHECK(kind IN ('conclusion', 'question')),
    body TEXT NOT NULL,
    evidence_json TEXT NOT NULL DEFAULT '[]',
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL
  ) STRICT;
  CREATE INDEX IF NOT EXISTS project_research_notes_owner ON project_research_notes(project_id, updated_at);`);
}

function evidenceKey(ref) {
  return JSON.stringify([ref.kind, ref.id, ref.workspaceId || "", ref.executionRoot || "", ref.path || ref.mainPath || "", ref.reviewSource || ""]);
}
function parse(text, fallback) { try { return JSON.parse(text); } catch { return fallback; } }
function projectContext(db, projectId, options, role = "viewer") {
  const project = db.prepare("SELECT id, name, description, archived_at FROM research_projects WHERE id=?").get(projectId);
  if (!project || !options.canAccessProject(projectId, role)) throw new Error("You do not have access to this project research.");
  if (role === "editor" && project.archived_at) throw new Error("Restore the project before editing its research notes.");
  return project;
}
function reference(item) {
  const { kind, id, projectId, dataRoot, workspaceId, executionRoot, path: filePath, mainPath, sourceVersion, reproductionId, threadId, paperId, libraryId, reviewSource, title } = item;
  return Object.fromEntries(Object.entries({ kind, id, projectId, dataRoot, workspaceId, executionRoot, path: filePath, mainPath, sourceVersion, reproductionId, threadId, paperId, libraryId, reviewSource, title }).filter(([, value]) => value !== undefined));
}
function visible(row, userId) { return row.visibility !== "private" || row.owner_id === userId; }

function listProjectResearchItems(db, projectId, options) {
  const dataRoot = path.resolve(options.dataRoot), items = [];
  const add = (kind, row, fields) => items.push({ kind, id: row.id, projectId, dataRoot, title: row.title || "", summary: "", updatedAt: row.updated_at || row.created_at || "", available: true, ...fields });
  const papers = db.prepare(`SELECT p.*, MIN(l.id) AS library_id, MAX(lp.added_at) AS selected_at,
    COALESCE(s.reason, '') AS selection_reason FROM papers p
    JOIN library_papers lp ON lp.paper_id=p.id JOIN libraries l ON l.id=lp.library_id
    LEFT JOIN project_paper_selections s ON s.paper_id=p.id AND s.project_id=l.project_id
    WHERE l.project_id=? GROUP BY p.id`).all(projectId);
  for (const paper of papers) add("paper", paper, { paperId: paper.id, libraryId: paper.library_id, summary: paper.selection_reason || [paper.year, paper.venue].filter(Boolean).join(" · "), status: paper.reading_status, updatedAt: paper.selected_at > paper.updated_at ? paper.selected_at : paper.updated_at });
  const workspaces = db.prepare("SELECT id, root FROM project_workspaces WHERE project_id=?").all(projectId);
  const threads = db.prepare("SELECT * FROM research_threads WHERE project_id=? ORDER BY updated_at DESC").all(projectId).filter(row => visible(row, options.userId));
  const threadMap = new Map(threads.map(row => [row.id, row]));
  for (const thread of threads) add("session", thread, { workspaceId: thread.workspace_id, executionRoot: thread.workspace_path || undefined, threadId: thread.id, summary: thread.context_summary || "", status: thread.status });
  for (const result of db.prepare("SELECT * FROM project_results WHERE project_id=?").all(projectId)) add(result.kind, result, { workspaceId: result.workspace_id, executionRoot: result.execution_root, threadId: result.thread_id, path: result.manifest_path });
  const reproductions = db.prepare("SELECT * FROM reproductions WHERE project_id=?").all(projectId);
  for (const reproduction of reproductions) {
    const owner = { workspaceId: reproduction.workspace_id, executionRoot: reproduction.execution_root, paperId: reproduction.paper_id || undefined, reproductionId: reproduction.id };
    add("reproduction", reproduction, { ...owner, summary: reproduction.repo_url, status: reproduction.status });
    for (const run of db.prepare("SELECT id, status, backend, started_at, finished_at, created_at, updated_at FROM reproduction_runs WHERE reproduction_id=?").all(reproduction.id)) {
      add("run", run, { ...owner, title: reproduction.title, summary: run.backend, status: run.status });
    }
  }
  for (const artifact of db.prepare("SELECT * FROM research_artifacts WHERE project_id=?").all(projectId)) {
    const thread = threadMap.get(artifact.thread_id);
    if (!thread || /^project-(analysis|figure)$/.test(artifact.source)) continue;
    add("artifact", artifact, { workspaceId: thread.workspace_id, executionRoot: thread.workspace_path, threadId: thread.id, path: artifact.path, sourceVersion: artifact.sha256 || undefined, status: `v${artifact.version}` });
  }
  for (const review of db.prepare("SELECT * FROM paper_reviews WHERE project_id=?").all(projectId).filter(row => visible(row, options.userId))) {
    const paper = papers.find(row => row.id === review.paper_id);
    if (paper) add("review", review, { title: paper.title, paperId: paper.id, libraryId: paper.library_id, reviewSource: "paper" });
  }
  const roots = new Map();
  for (const workspace of workspaces) roots.set(path.resolve(workspace.root), { workspaceId: workspace.id, executionRoot: workspace.root });
  for (const thread of threads) if (thread.workspace_path) roots.set(path.resolve(thread.workspace_path), { workspaceId: thread.workspace_id, executionRoot: thread.workspace_path, threadId: thread.id });
  for (const result of items.filter(item => item.executionRoot && item.workspaceId)) {
    const key = path.resolve(result.executionRoot), existing = roots.get(key);
    roots.set(key, { workspaceId: result.workspaceId, executionRoot: result.executionRoot, threadId: result.threadId || existing?.threadId });
  }
  if (options.listManuscriptVersionOwners) for (const owner of options.listManuscriptVersionOwners({ dataRoot, projectId })) {
    const key = path.resolve(owner.executionRoot), existing = roots.get(key);
    roots.set(key, { workspaceId: owner.workspaceId, executionRoot: owner.executionRoot, threadId: threadMap.has(owner.threadId) ? owner.threadId : existing?.threadId || null });
  }
  for (const owner of roots.values()) {
    if (!fs.existsSync(owner.executionRoot)) continue;
    for (const document of listLatexProjects(owner.executionRoot).filter(document => document.main)) {
      const stat = fs.statSync(path.join(owner.executionRoot, document.path));
      add("manuscript", { id: document.path, title: document.title }, { ...owner, path: document.path, mainPath: document.path, updatedAt: stat.mtime.toISOString() });
    }
    // The history module supplies the same saved objects shown by Paper writing.
    if (options.listManuscriptVersions) for (const version of options.listManuscriptVersions({ ...owner, projectId, dataRoot })) {
      add("milestone", version, { ...owner, threadId: threadMap.has(version.threadId) ? version.threadId : owner.threadId || null, title: version.name, mainPath: version.mainPath, sourceVersion: version.sourceVersion, updatedAt: version.createdAt });
    }
  }
  if (options.reviewDbPath && fs.existsSync(options.reviewDbPath)) {
    const reviews = new DatabaseSync(options.reviewDbPath, { readOnly: true });
    try {
      for (const review of reviews.prepare("SELECT * FROM paper_review_runs WHERE project_id=? AND owner_data_root=?").all(projectId, dataRoot)) {
        const source = parse(review.manuscript_json, null);
        add("review", review, { title: review.paper_title, reviewSource: "manuscript", summary: review.venue_id, status: review.status, workspaceId: source?.workspaceId, threadId: source?.threadId, executionRoot: source?.workspace, mainPath: source?.mainPath, sourceVersion: source?.sourceVersion });
      }
    } finally { reviews.close(); }
  }
  return items.sort((a, b) => b.updatedAt.localeCompare(a.updatedAt) || a.title.localeCompare(b.title));
}

function hydrateNote(row, items) {
  const current = new Map(items.map(item => [evidenceKey(item), item]));
  return { id: row.id, projectId: row.project_id, kind: row.kind, text: row.body, createdAt: row.created_at, updatedAt: row.updated_at,
    evidenceRefs: parse(row.evidence_json, []).map(ref => {
      const item = current.get(evidenceKey(ref));
      return { ...ref, ...(item ? reference(item) : {}), available: Boolean(item?.available) };
    }) };
}
function listProjectResearchIndex(db, { projectId } = {}, options) {
  const project = projectContext(db, projectId, options), items = listProjectResearchItems(db, projectId, options);
  const notes = db.prepare("SELECT * FROM project_research_notes WHERE project_id=? ORDER BY updated_at DESC").all(projectId).map(row => hydrateNote(row, items));
  return { project: { id: project.id, name: project.name, description: project.description }, dataRoot: path.resolve(options.dataRoot), canEdit: !project.archived_at && options.canAccessProject(projectId, "editor"), items, notes };
}
function saveProjectResearchNote(db, input = {}, options) {
  const { projectId, id, kind } = input;
  projectContext(db, projectId, options, "editor");
  if (!["conclusion", "question"].includes(kind)) throw new Error("Choose a conclusion or an open question.");
  const text = String(input.text || "").trim();
  if (!text) throw new Error("Write a research note before saving.");
  const previous = id ? db.prepare("SELECT * FROM project_research_notes WHERE id=? AND project_id=?").get(id, projectId) : null;
  if (id && !previous) throw new Error("The research note does not belong to this project.");
  const items = listProjectResearchItems(db, projectId, options), available = new Map(items.map(item => [evidenceKey(item), item]));
  const previousRefs = new Map(parse(previous?.evidence_json, []).map(ref => [evidenceKey(ref), ref]));
  const refs = new Map();
  for (const selected of input.evidenceRefs || []) {
    const key = evidenceKey(selected), item = available.get(key);
    if (selected.projectId !== projectId || path.resolve(selected.dataRoot || "") !== path.resolve(options.dataRoot)) throw new Error("Evidence must belong to the current project and data workspace.");
    const ref = item ? reference(item) : previousRefs.get(key);
    if (!ref) throw new Error("This evidence is no longer in the project. Refresh and choose an existing item.");
    refs.set(key, ref);
  }
  const now = new Date().toISOString(), noteId = previous?.id || randomUUID();
  db.prepare(`INSERT INTO project_research_notes(id, project_id, kind, body, evidence_json, created_at, updated_at) VALUES(?,?,?,?,?,?,?)
    ON CONFLICT(id) DO UPDATE SET kind=excluded.kind, body=excluded.body, evidence_json=excluded.evidence_json, updated_at=excluded.updated_at`)
    .run(noteId, projectId, kind, text, JSON.stringify([...refs.values()]), previous?.created_at || now, now);
  return hydrateNote(db.prepare("SELECT * FROM project_research_notes WHERE id=?").get(noteId), items);
}
function deleteProjectResearchNote(db, { projectId, id } = {}, options) {
  projectContext(db, projectId, options, "editor");
  return { deleted: db.prepare("DELETE FROM project_research_notes WHERE id=? AND project_id=?").run(id, projectId).changes > 0 };
}

module.exports = { ensureSchema, evidenceKey, listProjectResearchItems, listProjectResearchIndex, saveProjectResearchNote, deleteProjectResearchNote };
