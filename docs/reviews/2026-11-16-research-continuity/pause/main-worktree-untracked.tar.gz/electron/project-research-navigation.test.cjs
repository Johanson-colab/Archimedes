const assert = require("node:assert/strict");
const fs = require("node:fs");
const path = require("node:path");
const { test } = require("node:test");

async function navigation(bridge = {}) {
  const task = await import("../src/task-selection.ts");
  const { transformWithOxc } = await import("vite");
  const app = fs.readFileSync(path.join(__dirname, "../src/App.tsx"), "utf8");
  const start = app.indexOf("  async function openResearchIndexItem("), end = app.indexOf("\n  function openNewProject(", start);
  assert.ok(start > 0 && end > start);
  const code = (await transformWithOxc(app.slice(start, end), "index-navigation.ts")).code;
  const selection = { dataRoot: "/data/a", projectId: "project", workspaceId: "workspace", threadId: "selected", executionRoot: "/current" };
  const state = { requests: [], drafts: ["UNSENT_PLAN"], selection };
  const scope = { ...task, crypto: global.crypto, t: key => key, dataFolderLoadingRef: { current: false }, taskSelectionRef: { current: selection },
    desktopBridge: bridge, activeProject: { id: "project", workspace_path: "/current" }, workspaces: [{ id: "workspace", project_id: "project", root: "/current", is_default: true }],
    displayThread(thread, dataRoot) { scope.taskSelectionRef.current = task.threadTaskSelection(dataRoot, thread, []); },
    startNewTask(projectId, workspaceId) { scope.taskSelectionRef.current = { ...selection, projectId, workspaceId, threadId: null }; },
    applyTaskSelection(next) { scope.taskSelectionRef.current = next; },
    setPaperOpenRequest(value) { state.requests.push({ type: "manuscript", value, selection: scope.taskSelectionRef.current }); },
    setLibraryOpenRequest(value) { state.requests.push({ type: "paper", value }); },
    setReviewRunOpenRequest(value) { state.requests.push({ type: "review", value }); },
    setReproduceId(value, ownerKey) { state.requests.push({ type: "reproduction", value, ownerKey }); },
    setReproductionRunOpenRequest(value) { state.requests.push({ type: "run", value }); },
    setResearchFileRequest(value) { state.requests.push({ type: "file", value }); },
    setMainSection(value) { state.requests.push({ type: "section", value }); },
    async openResearchApp(value, isCurrent) { if (isCurrent()) state.requests.push({ type: "app", value }); },
    async returnToProjectResult(value) { state.requests.push({ type: "result", value }); },
  };
  const open = new Function(...Object.keys(scope), `${code}; return openResearchIndexItem;`)(...Object.values(scope));
  return { open, state, scope, item: { kind: "milestone", id: "version", dataRoot: selection.dataRoot, projectId: selection.projectId, workspaceId: selection.workspaceId, threadId: "historical", executionRoot: "/historical", mainPath: "paper/main.tex", available: true } };
}

test("project index opens the named manuscript version in its historical session without replacing a draft", async () => {
  const h = await navigation({ getResearchThread: async id => ({ id, project_id: "project", workspace_id: "workspace", workspace_path: "/historical" }) });
  await h.open(h.item);
  const request = h.state.requests.find(item => item.type === "manuscript");
  assert.equal(request.value.path, "paper/main.tex");
  assert.equal(request.value.milestoneId, "version");
  assert.equal(request.selection.threadId, "historical");
  assert.equal(request.selection.executionRoot, "/historical");
  assert.deepEqual(h.state.drafts, ["UNSENT_PLAN"]);
  assert.equal(h.state.requests.at(-1).value, "writing");
});

test("a late source lookup cannot navigate a different data folder with matching project IDs", async () => {
  let finish;
  const h = await navigation({ getResearchThread: () => new Promise(resolve => { finish = resolve; }) });
  const pending = h.open(h.item);
  h.scope.taskSelectionRef.current = { ...h.scope.taskSelectionRef.current, dataRoot: "/data/b" };
  finish({ id: "historical", project_id: "project", workspace_id: "workspace", workspace_path: "/historical" });
  await pending;
  assert.equal(h.scope.taskSelectionRef.current.dataRoot, "/data/b");
  assert.deepEqual(h.state.requests, []);
});

test("paper reviews and historical experiment runs reopen their concrete objects", async () => {
  const h = await navigation();
  await h.open({ ...h.item, kind: "review", id: "paper-review", paperId: "paper", libraryId: "library", reviewSource: "paper", threadId: null });
  const paper = h.state.requests.find(item => item.type === "paper").value;
  assert.equal(paper.paperId, "paper"); assert.equal(paper.libraryId, "library"); assert.equal(paper.review, true);
  h.state.requests.length = 0;
  await h.open({ ...h.item, kind: "run", id: "run", reproductionId: "experiment", threadId: null });
  assert.equal(h.state.requests.find(item => item.type === "reproduction").value, "experiment");
  const renderOwner = h.scope.analysisOwnerKey(h.scope.newTaskSelection(h.scope.taskSelectionRef.current.dataRoot, h.scope.activeProject, h.scope.workspaces, h.scope.taskSelectionRef.current.workspaceId));
  const selections = Object.fromEntries(h.state.requests.filter(item => item.type === "reproduction").map(item => [item.ownerKey, item.value]));
  assert.equal(selections[renderOwner], "experiment", "the rendered current-workspace owner reads the requested historical run");
  assert.notEqual(renderOwner, h.scope.analysisOwnerKey(h.scope.taskSelectionRef.current), "the historical execution folder differs from the current workspace root");
  assert.equal(h.state.requests.find(item => item.type === "run").value.id, "run");
  assert.equal(h.state.requests.at(-1).value, "reproduce");
});
