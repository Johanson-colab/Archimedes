const assert = require("node:assert/strict");
const fs = require("node:fs");
const path = require("node:path");
const { test } = require("node:test");

async function fixture() {
  const task = await import("../src/task-selection.ts");
  const { transformWithOxc } = await import("vite");
  const source = fs.readFileSync(path.join(__dirname, "../src/research-handoffs.ts"), "utf8").replace(/^import .*;$/gm, "").replace(/^export /gm, "");
  const code = (await transformWithOxc(source, "research-handoffs.ts")).code;
  return { ...task, ...new Function(...Object.keys(task), `${code}; return { createResearchHandoffService, manuscriptHandoffOrigin, manuscriptRevisionPrompt };`)(...Object.values(task)) };
}

test("figure insertion prepares the checked result and a delayed reply cannot open a same-ID task in another data folder", async () => {
  const helpers = await fixture(), service = helpers.createResearchHandoffService();
  const original = { dataRoot: "/data/a", projectId: "project", workspaceId: "workspace", threadId: "thread", executionRoot: "/execution" };
  let selection = original, finish;
  const checked = { id: "figure", projectId: "project", title: "Checked title", fileState: "ready", files: [{ name: "figure.png", role: "output", fileState: "ready" }] };
  const context = { bridge: { getProjectResult: () => new Promise(resolve => { finish = resolve; }) }, getSelection: () => selection, isDataFolderLoading: () => false, workspaces: [], t: key => key };
  const pending = service.figureInsertion(checked, "figure.png", context);
  selection = { ...original, dataRoot: "/data/b" };
  finish(checked);
  assert.equal(await pending, null);
  selection = original;
  context.bridge.getProjectResult = async () => ({ ...checked, title: "Verified saved title" });
  const request = await service.figureInsertion(checked, "figure.png", context);
  assert.equal(request.dataRoot, original.dataRoot);
  assert.equal(request.title, "Verified saved title");
  assert.equal(request.resultId, checked.id);
  assert.equal(request.fileName, "figure.png");
});

test("selected review findings retain the reviewed source receipt when preparing a revision", async () => {
  const { manuscriptRevisionPrompt } = await fixture();
  const text = manuscriptRevisionPrompt({ id: "review-1", manuscript: { mainPath: "paper/main.tex", sourceVersion: "source-1", pdfSha256: "pdf-hash", manifestPath: "build/receipt.json" } }, [{ text: "Explain the baseline", page: 3, quote: "Reported comparison", severity: "major" }]);
  for (const content of ["review-1", "source-1", "pdf-hash", "build/receipt.json", "PDF page: 3", "Reported comparison", "Explain the baseline"]) assert.ok(text.includes(content), content);
  assert.match(text, /Preserve the current manuscript until I approve specific edits/);
});
