import { useCallback, useEffect, useId, useMemo, useRef, useState } from "react";
import { AlertTriangle, ArrowDown, ArrowUp, BookOpen, Check, ChevronDown, ChevronRight, CircleDot, Cloud, FileCode2, FileImage, FilePlus2, FileText, Folder, FolderOpen, FolderPlus, FolderUp, History, LoaderCircle, MessageCircle, PanelLeftClose, PanelLeftOpen, Play, RefreshCw, Search, X } from "lucide-react";
import { useUISettings } from "./i18n";
import SharedNoteEditor from "./SharedNoteEditor";
import PaperTemplateLibrary, { paperTemplates } from "./PaperTemplateLibrary";
import { Dialog } from "./Dialog";
import { StateView } from "./StateView";
import { Tab, Tabs } from "./Tabs";
import { fingerprintFor } from "./proactive-engine";
import { emitProactiveSignal } from "./proactive-signals";
import { findSourceMatches, sourceMarksByLine, type SourceMark } from "./paper-source-search";
import { createWritingDocument, createWritingScope, editWritingDocument, saveWritingDocument, readWritingLocation, rememberWritingLocation, type WritingScope } from "./paper-writing-state";
import "./paper-source-search.css";
import "./workflow-continuity.css";
import type { ResultFigureRequest, StageProjectResultFigureReceipt } from "./project-results";
import type { ManuscriptSource, ManuscriptTarget } from "./manuscript-handoff";
import PaperWritingCitations, { type CitationAction } from "./PaperWritingCitations";
import { manuscriptBibliographyPaths, prepareManuscriptCitation } from "./paper-writing-citations";
import type { BibliographyPaper } from "./bibliography";
import PaperWritingVersions from "./PaperWritingVersions";
import type { ManuscriptVersionComparison, ManuscriptVersionOwner } from "./paper-writing-history";


const EDITABLE = new Set(["tex", "bib", "bst", "cls", "sty", "cfg"]);
const ASSETS = new Set([...EDITABLE, "pdf", "png", "jpg", "jpeg", "webp"]);
const ext = (value: string) => value.split(".").at(-1)?.toLowerCase() || "";
const editable = (value: string) => EDITABLE.has(ext(value));
const projectRoot = (value: string) => value.split("/").slice(0, -1).join("/");

const BROWSER_MIN_WIDTH = 160;
const BROWSER_MAX_WIDTH = 360;
const BROWSER_DEFAULT_WIDTH = 220;
const EDITOR_MIN_WIDTH = 280;
const PREVIEW_MIN_WIDTH = 320;
const PREVIEW_SPLIT_MIN = 0.3;
const PREVIEW_SPLIT_MAX = 0.8;
const PREVIEW_SPLIT_DEFAULT = 0.62;

function clampSetting(value: number, min: number, max: number) {
  return Math.min(max, Math.max(min, value));
}

function browserTrackFor(width: number) {
  return Math.max(BROWSER_MIN_WIDTH, Math.min(BROWSER_MAX_WIDTH, width * 0.3, width - EDITOR_MIN_WIDTH - PREVIEW_MIN_WIDTH));
}

function readStoredNumber(key: string, fallback: number, min: number, max: number) {
  if (typeof window === "undefined") return fallback;
  const stored = Number(window.localStorage.getItem(key));
  return Number.isFinite(stored) && stored > 0 ? clampSetting(stored, min, max) : fallback;
}

function readStoredFlag(key: string) {
  if (typeof window === "undefined") return false;
  return window.localStorage.getItem(key) === "true";
}

function lineStart(content: string, line: number) {
  let offset = 0;
  for (let index = 1; index < line; index += 1) {
    const next = content.indexOf("\n", offset);
    if (next < 0) return content.length;
    offset = next + 1;
  }
  return offset;
}

function replaceChildren(entries: WorkspaceFileEntry[], directory: string, children: WorkspaceFileEntry[]): WorkspaceFileEntry[] {
  return entries.map((entry) => {
    if (entry.type !== "directory") return entry;
    if (entry.path === directory) return { ...entry, children };
    return directory.startsWith(`${entry.path}/`) && entry.children ? { ...entry, children: replaceChildren(entry.children, directory, children) } : entry;
  });
}

function FileIcon({ entry }: { entry: WorkspaceFileEntry }) {
  if (entry.type === "directory") return <Folder size={14} />;
  if (["png", "jpg", "jpeg", "webp"].includes(ext(entry.path))) return <FileImage size={14} />;
  return ext(entry.path) === "pdf" ? <FileText size={14} /> : <FileCode2 size={14} />;
}

function TreeNode({ entry, depth, selected, activeDirectory, expanded, loading, onToggle, onLoad, onOpen }: {
  entry: WorkspaceFileEntry; depth: number; selected: string; activeDirectory: string; expanded: Set<string>; loading: Set<string>;
  onToggle: (path: string) => void; onLoad: (path: string) => void; onOpen: (path: string) => void;
}) {
  const directory = entry.type === "directory";
  const open = directory && expanded.has(entry.path);
  const pending = loading.has(entry.path);
  useEffect(() => { if (open && entry.children === undefined && !pending) onLoad(entry.path); }, [entry.children, entry.path, onLoad, open, pending]);
  if (!directory && !ASSETS.has(ext(entry.path))) return null;
  return <div className="paper-tree-node">
    <button className={entry.path === selected || (directory && entry.path === activeDirectory) ? "paper-tree-row active" : "paper-tree-row"} style={{ paddingLeft: `${8 + depth * 14}px` }} onClick={() => directory ? onToggle(entry.path) : onOpen(entry.path)} title={entry.path}>
      <span>{pending ? <RefreshCw className="spin" size={11} /> : directory ? open ? <ChevronDown size={13} /> : <ChevronRight size={13} /> : null}</span><FileIcon entry={entry} /><strong>{entry.name}</strong>
    </button>
    {open && entry.children?.map((child) => <TreeNode key={child.path} entry={child} depth={depth + 1} selected={selected} activeDirectory={activeDirectory} expanded={expanded} loading={loading} onToggle={onToggle} onLoad={onLoad} onOpen={onOpen} />)}
  </div>;
}

function HighlightLine({ text, problem, marks, activeMatch }: { text: string; problem: boolean; marks?: SourceMark[]; activeMatch: number }) {
  let commentIndex = -1;
  for (let index = 0; index < text.length; index += 1) if (text[index] === "%" && text[index - 1] !== "\\") { commentIndex = index; break; }
  const code = commentIndex < 0 ? text : text.slice(0, commentIndex);
  const comment = commentIndex < 0 ? "" : text.slice(commentIndex);
  const tokens: Array<{ value: string; className?: string }> = [];
  const pattern = /(\\[a-zA-Z@]+|\\[^a-zA-Z@]|\$\$?|[{}\[\]]|\b\d+(?:\.\d+)?\b)/g;
  let cursor = 0;
  for (const match of code.matchAll(pattern)) {
    const index = match.index ?? 0;
    if (index > cursor) tokens.push({ value: code.slice(cursor, index) });
    const value = match[0];
    tokens.push({ value, className: value.startsWith("\\") ? "latex-token-command" : value.startsWith("$") ? "latex-token-math" : /^[{}\[\]]$/.test(value) ? "latex-token-punctuation" : "latex-token-number" });
    cursor = index + value.length;
  }
  if (cursor < code.length) tokens.push({ value: code.slice(cursor) });
  if (comment) tokens.push({ value: comment, className: "latex-token-comment" });
  let tokenStart = 0;
  let markIndex = 0;
  return <span className={problem ? "latex-highlight-line diagnostic" : "latex-highlight-line"}>{tokens.length ? tokens.map((token, index) => {
    const start = tokenStart;
    const end = start + token.value.length;
    tokenStart = end;
    const parts: React.ReactNode[] = [];
    let position = start;
    while (marks && position < end && markIndex < marks.length && marks[markIndex].start < end) {
      const mark = marks[markIndex];
      if (mark.end <= position) { markIndex += 1; continue; }
      const from = Math.max(position, mark.start);
      const to = Math.min(end, mark.end);
      if (from > position) parts.push(token.value.slice(position - start, from - start));
      parts.push(<mark key={mark.index} className={mark.index === activeMatch ? "latex-search-match active" : "latex-search-match"}>{token.value.slice(from - start, to - start)}</mark>);
      position = to;
      if (mark.end <= end) markIndex += 1;
    }
    if (position < end) parts.push(token.value.slice(position - start));
    return <span className={token.className} key={index}>{parts}</span>;
  }) : " "}</span>;
}

export type PaperOpenRequest = { path: string; token: number; milestoneId?: string } | null;

export default function PaperWritingView({ bridge, workspace, projectId, openRequest, onRefresh, onAskAI, onHandoff, figureRequest, onReturnToResult, workspaceId, threadId, dataRoot, active = true }: {
  bridge: ResearchDeskBridge; workspace: string; projectId?: string | null; openRequest: PaperOpenRequest; onRefresh: () => Promise<void> | void; onAskAI: (path: string, manuscript?: { workspace: string; projectId: string | null; mainPath: string; selectedPath: string }) => void | Promise<void>; onHandoff?: (target: ManuscriptTarget, source: ManuscriptSource) => Promise<void>; dataRoot?: string; workspaceId?: string | null; threadId?: string | null; figureRequest?: ResultFigureRequest; onReturnToResult?: (id: string) => void | Promise<void>; active?: boolean;
}) {
  const { t } = useUISettings();
  const scopesRef = useRef(new Map<string, WritingScope>());
  const mountedRef = useRef(true);
  const [, renderScope] = useState(0);
  const refreshScope = useCallback(() => { if (mountedRef.current) renderScope((value) => value + 1); }, []);
  let scope = scopesRef.current.get(workspace);
  if (!scope) { scope = createWritingScope(workspace); scopesRef.current.set(workspace, scope); }
  const owner = scope;
  function scoped<K extends keyof WritingScope>(key: K): [WritingScope[K], React.Dispatch<React.SetStateAction<WritingScope[K]>>] {
    return [owner[key], (action) => { owner[key] = typeof action === "function" ? (action as (current: WritingScope[K]) => WritingScope[K])(owner[key]) : action; refreshScope(); }];
  }
  const [activeProject, setActiveProject] = scoped("activeProject");
  const projects = owner.projects;
  const [chooserTab, setChooserTab] = scoped("chooserTab");
  const [tree] = scoped("tree");
  const [loading] = scoped("loading");
  const [mainPath, setMainPath] = scoped("mainPath");
  const currentDocument = owner.documents.get(owner.selectedPath);
  const file = currentDocument?.file || null;
  const draft = currentDocument?.draft || "";
  const savedDraft = currentDocument?.savedDraft || "";
  const saveState = currentDocument?.saveState || "saved";
  const setDraft = (content: string) => { if (currentDocument && !owner.fileOperationBusy) { editWritingDocument(currentDocument, content); refreshScope(); } };
  const [expanded, setExpanded] = scoped("expanded");
  const [activeDirectory, setActiveDirectory] = scoped("activeDirectory");
  const [searchOpen, setSearchOpen] = scoped("searchOpen");
  const [searchQuery, setSearchQuery] = scoped("searchQuery");
  const [searchOffset, setSearchOffset] = scoped("searchOffset");
  const searchInputRef = useRef<HTMLInputElement | null>(null);
  const searchId = useId();
  const searchMatches = useMemo(() => searchOpen ? findSourceMatches(draft, searchQuery) : [], [draft, searchOpen, searchQuery]);
  const searchMarks = useMemo(() => sourceMarksByLine(draft, searchMatches), [draft, searchMatches]);
  const nextMatchIndex = searchMatches.findIndex((match) => match.start >= searchOffset);
  const activeMatchIndex = searchMatches.length ? Math.max(0, nextMatchIndex) : -1;
  const [buildLogOpen, setBuildLogOpen] = scoped("buildLogOpen");
  const buildLogId = useId();
  const [compileLog, setCompileLog] = scoped("compileLog");
  const [compileElapsed, setCompileElapsed] = scoped("compileElapsed");
  const [compilePhase, setCompilePhase] = scoped("compilePhase");
  const [compileState, setCompileState] = scoped("compileState");
  const [compileResult, setCompileResult] = scoped("compileResult");
  const [handoffBusy, setHandoffBusy] = scoped("handoffBusy");
  const [activeProblem, setActiveProblem] = scoped("activeProblem");
  const [workspaceError, setError] = scoped("error");
  const error = workspaceError || currentDocument?.error || "";
  const [autoCompile, setAutoCompile] = useState(true);
  const [coedit, setCoedit] = scoped("coedit");
  const [chooserOpen, setChooserOpen] = scoped("chooserOpen");
  const [projectName, setProjectName] = useState("paper");
  const [creating, setCreating] = scoped("creating");
  const [templateId, setTemplateId] = useState(paperTemplates[0]?.id ?? "");
  const [browserWidth, setBrowserWidth] = useState(() => readStoredNumber("archimedes-paper-browser-width", BROWSER_DEFAULT_WIDTH, BROWSER_MIN_WIDTH, BROWSER_MAX_WIDTH));
  const [previewSplit, setPreviewSplit] = useState(() => readStoredNumber("archimedes-paper-split", PREVIEW_SPLIT_DEFAULT, PREVIEW_SPLIT_MIN, PREVIEW_SPLIT_MAX));
  const [browserCollapsed, setBrowserCollapsed] = useState(() => readStoredFlag("archimedes-paper-browser-collapsed"));
  const [widePanes, setWidePanes] = useState(() => typeof window === "undefined" || window.matchMedia("(min-width: 861px)").matches);
  const [paneWidth, setPaneWidth] = useState(0);
  const [importing, setImporting] = scoped("importing");
  const [createKind, setCreateKind] = scoped("createKind");
  const dialogOpen = chooserOpen && active;
  const createOpen = Boolean(createKind) && active;
  const [createName, setCreateName] = scoped("createName");
  const editorRef = useRef<HTMLTextAreaElement | null>(null);
  const [citationOwner, setCitationOwner] = useState<{ owner: WritingScope; projectId: string; mainPath: string; path: string; start: number; end: number } | null>(null);
  const [versionOwner, setVersionOwner] = useState<{ owner: WritingScope; context: ManuscriptVersionOwner; initialId?: string } | null>(null);
  const lineNumbersRef = useRef<HTMLDivElement | null>(null);
  const highlightRef = useRef<HTMLPreElement | null>(null);
  const workspaceRef = useRef<HTMLDivElement | null>(null);
  const paneDragRef = useRef<{ kind: "browser" | "preview"; startX: number; startBrowser: number; startSplit: number } | null>(null);
  const consumedOpenRequest = useRef<string | null>(null);
  type FigureInsertion = { request: ResultFigureRequest; busy: boolean; receipt?: StageProjectResultFigureReceipt; mainPath?: string; selectedPath?: string; error?: string; inserted?: boolean };
  const figureInsertions = useRef(new Map<string, FigureInsertion>());
  const consumedFigureRequests = useRef(new Set<string>());
  const liveWritingOwner = useRef({ owner, active }); liveWritingOwner.current = { owner, active };
  const insertionKey = JSON.stringify([dataRoot ?? "", projectId ?? null, workspace]);
  const pendingFigure = figureInsertions.current.get(insertionKey);
  useEffect(() => {
    if (!active || !figureRequest || figureRequest.projectId !== projectId || consumedFigureRequests.current.has(figureRequest.token)) return;
    consumedFigureRequests.current.add(figureRequest.token);
    figureInsertions.current.set(insertionKey, { request: figureRequest, busy: false }); refreshScope();
  }, [active, figureRequest, projectId, workspace, insertionKey, refreshScope]);
  function insertPreparedFigure(pending: FigureInsertion, document: NonNullable<typeof currentDocument>, position?: { start: number; end: number }) {
    if (!pending.receipt || owner.selectedPath !== document.file.path) return;
    const base = projectRoot(owner.mainPath), path = base && pending.receipt.path.startsWith(base + "/") ? pending.receipt.path.slice(base.length + 1) : pending.receipt.path;
    const snippet = `
\\begin{figure}[htbp]
\\centering
\\includegraphics[width=\\linewidth]{${path}}
\\caption{}
\\end{figure}
`;
    const editor = editorRef.current;
    const start = position?.start ?? editor?.selectionStart ?? document.draft.length, end = position?.end ?? editor?.selectionEnd ?? start;
    editWritingDocument(document, document.draft.slice(0, start) + snippet + document.draft.slice(end));
    pending.inserted = true; pending.receipt = undefined; pending.error = t("Figure inserted. Its source receipt is saved beside the image. Use the graphicx package to compile it."); refreshScope();
    window.requestAnimationFrame(() => { editor?.focus(); editor?.setSelectionRange(start + snippet.length, start + snippet.length); });
  }
  async function addFigurePackage() {
    const pending = figureInsertions.current.get(insertionKey), main = owner.mainPath;
    if (!pending || !main) return;
    try {
      let document = owner.documents.get(main);
      if (!document) {
        const file = await bridge.readWorkspaceFile(owner.workspace, main);
        document = owner.documents.get(main);
        if (!document) { document = createWritingDocument(owner.workspace, file); owner.documents.set(main, document); }
      }
      if (/\\(?:usepackage|RequirePackage)(?:\[[^\]]*\])?\{[^}]*\bgraphicx\b[^}]*\}/.test(document.draft)) { pending.error = t("The main manuscript already loads graphicx."); refreshScope(); return; }
      const position = document.draft.indexOf("\\begin{document}");
      if (position < 0) throw new Error(t("Open the main .tex file and add \\usepackage{graphicx} in its preamble."));
      editWritingDocument(document, document.draft.slice(0, position) + "\\usepackage{graphicx}\n" + document.draft.slice(position));
      pending.error = t("Added graphicx to the main manuscript draft. Recompile to save and preview it."); refreshScope();
    } catch (reason) { pending.error = String(reason); refreshScope(); }
  }
  async function insertResultFigure() {
    const pending = figureInsertions.current.get(insertionKey), document = owner.documents.get(owner.selectedPath);
    if (!pending || !document || !owner.mainPath || !projectId || !workspaceId || !editable(document.file.path) || ext(document.file.path) !== "tex" || pending.busy) return;
    if (pending.receipt && pending.mainPath === owner.mainPath) { insertPreparedFigure(pending, document); return; }
    if (!bridge.stageProjectResultFigure) { pending.error = t("Restart the desktop app to insert project figures."); refreshScope(); return; }
    pending.busy = true; pending.error = ""; refreshScope();
    const main = owner.mainPath, version = document.version, activation = owner.activationSequence;
    const editor = editorRef.current, position = { start: editor?.selectionStart ?? document.draft.length, end: editor?.selectionEnd ?? document.draft.length };
    try {
      const receipt = await bridge.stageProjectResultFigure({ resultId: pending.request.resultId, fileName: pending.request.fileName, target: { projectId, workspaceId, threadId: threadId ?? null, workspace: owner.workspace, mainPath: main } });
      if (figureInsertions.current.get(insertionKey) !== pending) return;
      pending.receipt = receipt; pending.mainPath = main; pending.selectedPath = document.file.path;
      if (liveWritingOwner.current.owner === owner && liveWritingOwner.current.active && owner.activationSequence === activation && owner.mainPath === main && owner.selectedPath === document.file.path && document.version === version) insertPreparedFigure(pending, document, position);
      else pending.error = t("Figure prepared. Your newer text was kept. Return to this manuscript and insert at the current cursor.");
    } catch (reason) { pending.error = reason instanceof Error ? reason.message : String(reason); }
    finally { pending.busy = false; refreshScope(); }
  }

  const compileRequestPrefix = useId();
  const compileRequestSequence = useRef(0);

  const loadDirectory = useCallback(async (directory: string, root = false) => {
    const request = (owner.directoryRequests.get(directory) || 0) + 1;
    owner.directoryRequests.set(directory, request);
    owner.loading.add(directory);
    const project = owner.activeProject;
    refreshScope();
    try {
      const listing = await bridge.listWorkspaceFiles(owner.workspace, directory);
      if (owner.directoryRequests.get(directory) !== request || owner.activeProject !== project) return;
      owner.tree = root ? listing : { ...owner.tree, entries: replaceChildren(owner.tree.entries, directory, listing.entries) };
    } catch (nextError) {
      if (owner.directoryRequests.get(directory) === request && owner.activeProject === project) owner.error = nextError instanceof Error ? nextError.message : String(nextError);
    } finally {
      if (owner.directoryRequests.get(directory) === request) owner.loading.delete(directory);
      refreshScope();
    }
  }, [bridge, owner, refreshScope]);

  const openFile = useCallback(async (path: string) => {
    if (!editable(path)) return;
    const request = ++owner.openSequence;
    owner.compileTarget = "";
    ++owner.compileSequence;
    owner.compileResult = null; owner.compileLog = ""; owner.compileState = "idle";
    const previous = owner.documents.get(owner.selectedPath);
    if (previous && previous.draft !== previous.savedDraft) void saveWritingDocument(previous, bridge.writeWorkspaceFile, refreshScope).catch(() => {});
    const cached = owner.documents.get(path);
    const version = cached?.version;
    if (cached) owner.selectedPath = path;
    refreshScope();
    try {
      const next = cached && cached.draft !== cached.savedDraft ? cached.file : await bridge.readWorkspaceFile(owner.workspace, path);
      if (request !== owner.openSequence) return;
      let opened = owner.documents.get(path);
      if (!opened) { opened = createWritingDocument(owner.workspace, next); owner.documents.set(path, opened); }
      else if (opened.version === version && opened.draft === opened.savedDraft) {
        opened.file = next; opened.draft = next.content || ""; opened.savedDraft = opened.draft; opened.version += 1;
      }
      owner.selectedPath = path;
      owner.activeProblem = null; owner.error = ""; owner.activeDirectory = projectRoot(path);
      if (ext(path) === "tex" && /\\documentclass(?:\[[^\]]*\])?\s*\{/s.test(opened.draft)) owner.mainPath = path;
      setSearchOffset(0);
      refreshScope();
    } catch (nextError) {
      if (request === owner.openSequence) { owner.error = nextError instanceof Error ? nextError.message : String(nextError); refreshScope(); }
    }
  }, [bridge, owner, refreshScope]);

  const activateProject = useCallback(async (path: string) => {
    const root = projectRoot(path) || ".";
    const request = ++owner.activationSequence;
    owner.compileTarget = "";
    ++owner.compileSequence;
    setCompileResult(null); setCompileLog(""); setCompileState("idle");
    owner.mainPath = path;
    setActiveProject(root); setActiveDirectory(root); setExpanded(new Set([root])); setChooserOpen(false); setError("");
    await loadDirectory(root, true);
    if (request !== owner.activationSequence) return;
    await openFile(path);
  }, [loadDirectory, openFile, owner]);

  function openCitations() {
    if (!projectId || !currentDocument || ext(currentDocument.file.path) !== "tex" || !mainPath) return;
    const editor = editorRef.current;
    setCitationOwner({ owner, projectId, mainPath, path: currentDocument.file.path, start: editor?.selectionStart ?? draft.length, end: editor?.selectionEnd ?? draft.length });
  }
  async function applyCitation(paper: BibliographyPaper, bibPath: string, action: CitationAction) {
    const selected = citationOwner;
    if (!selected || selected.owner.fileOperationBusy) throw new Error(t("The manuscript is busy. Try again after saving."));
    const targetOwner = selected.owner, directory = projectRoot(selected.mainPath);
    if (!bibPath.endsWith(".bib") || bibPath.startsWith("/") || bibPath.split(/[\\/]/).some(part => part === ".." || part.startsWith(".")) || directory && !bibPath.startsWith(`${directory}/`)) throw new Error(t("Choose a .bib file inside this manuscript folder."));
    targetOwner.fileOperationBusy = true; refreshScope();
    try {
      let bibliography = targetOwner.documents.get(bibPath);
      if (!bibliography) {
        let content: WorkspaceFilePreview;
        try { content = await bridge.readWorkspaceFile(targetOwner.workspace, bibPath); }
        catch (reason) {
          if (!String(reason).includes("ENOENT")) throw reason;
          content = { path: bibPath, name: bibPath.split("/").at(-1) || bibPath, kind: "text", content: "", size: 0, modifiedAt: "" };
        }
        bibliography = createWritingDocument(targetOwner.workspace, content); targetOwner.documents.set(bibPath, bibliography);
      }
      const prepared = prepareManuscriptCitation(bibliography.draft, paper, action !== "insert");
      if (!paper.citekey) await bridge.setPaperBibliography(paper.id, { citekey: prepared.citekey, entryType: paper.entry_type || "article" });
      if (action !== "insert") {
        editWritingDocument(bibliography, prepared.content);
        await saveWritingDocument(bibliography, bridge.writeWorkspaceFile, refreshScope);
      }
      if (action !== "update") {
        const document = targetOwner.documents.get(selected.path);
        if (!document) throw new Error(t("Open the manuscript source before inserting a citation."));
        const snippet = `\\cite{${prepared.citekey}}`;
        const position = Math.min(selected.start, document.draft.length), end = Math.min(selected.end, document.draft.length);
        editWritingDocument(document, document.draft.slice(0, position) + snippet + document.draft.slice(end));
        selected.start = selected.end = position + snippet.length;
        await saveWritingDocument(document, bridge.writeWorkspaceFile, refreshScope);
      }
      targetOwner.compileResult = null; targetOwner.compileState = "idle"; targetOwner.compileSequence++;
      if (owner === targetOwner) await loadDirectory(directory || ".", true);
      return action === "insert" ? t("Citation inserted. The .bib file was kept as written.") : action === "update" ? t("Bibliography entry updated. Its citation key was preserved.") : t("Citation inserted and bibliography entry saved.");
    } finally { targetOwner.fileOperationBusy = false; refreshScope(); }
  }

  function openVersions(initialId?: string) {
    if (!projectId || !workspaceId || !owner.mainPath) return;
    setVersionOwner({ owner, context: { dataRoot, projectId, workspaceId, executionRoot: owner.workspace, mainPath: owner.mainPath, threadId }, initialId });
  }
  async function withSavedManuscript<T>(operation: (selection: NonNullable<typeof versionOwner>) => Promise<T>) {
    const selected = versionOwner;
    if (!selected || selected.owner.fileOperationBusy) throw new Error(t("The manuscript is busy. Try again after saving."));
    const target = selected.owner;
    if (target.compileState === "compiling") throw new Error(t("Wait for the current compilation before changing key versions."));
    target.fileOperationBusy = true; refreshScope();
    try {
      await Promise.all([...target.documents.values()].map(document => saveWritingDocument(document, bridge.writeWorkspaceFile, refreshScope)));
      return await operation(selected);
    } finally { target.fileOperationBusy = false; refreshScope(); }
  }
  async function restoreVersion(comparison: ManuscriptVersionComparison) {
    await withSavedManuscript(async selected => {
      if (!bridge.restoreManuscriptVersion) throw new Error(t("Key versions are available in the desktop app."));
      const receipt = await bridge.restoreManuscriptVersion({ ...selected.context, id: comparison.version.id, expectedSourceVersion: comparison.currentSourceVersion });
      const paths = new Set([...receipt.restoredPaths, ...receipt.removedPaths]);
      for (const name of paths) selected.owner.documents.delete(name);
      selected.owner.compileSequence++; selected.owner.compileResult = null; selected.owner.compileState = "idle"; selected.owner.compileLog = ""; selected.owner.coedit = false;
      if (liveWritingOwner.current.owner === selected.owner) await activateProject(selected.context.mainPath);
      await onRefresh();
    });
  }

  const refreshProjects = useCallback(async () => {
    const request = ++owner.projectListSequence;
    owner.projectsLoading = true;
    refreshScope();
    try {
      const found = await bridge.listLatexProjects(owner.workspace);
      if (request !== owner.projectListSequence) return;
      owner.projects = found;
      if (!owner.restorationAttempted && !owner.selectedPath && !owner.activationSequence) {
        owner.restorationAttempted = true;
        const saved = readWritingLocation(window.localStorage, owner.workspace, projectId);
        if (saved && found.some((item) => item.path === saved.mainPath)) {
          await activateProject(saved.mainPath);
          if (request !== owner.projectListSequence || owner.mainPath !== saved.mainPath) return;
          const activation = owner.activationSequence;
          if (saved.selectedPath !== saved.mainPath && (saved.projectPath === "." || saved.selectedPath.startsWith(`${saved.projectPath}/`))) {
            const nextOpen = owner.openSequence + 1;
            await openFile(saved.selectedPath);
            if (owner.activationSequence !== activation || owner.openSequence !== nextOpen) return;
          }
          owner.mainPath = saved.mainPath;
        }
      }
    } catch (error) {
      if (request === owner.projectListSequence) owner.error = error instanceof Error ? error.message : String(error);
    } finally {
      if (request === owner.projectListSequence) owner.projectsLoading = false;
      refreshScope();
    }
  }, [activateProject, bridge, openFile, owner, projectId, refreshScope]);

  useEffect(() => { if (active) void refreshProjects(); }, [active, refreshProjects]);
  useEffect(() => {
    if (!activeProject || !mainPath || !file?.path) return;
    rememberWritingLocation(window.localStorage, owner.workspace, projectId, { projectPath: activeProject, mainPath, selectedPath: file.path });
  }, [activeProject, file?.path, mainPath, owner.workspace, projectId]);

  async function handoffManuscript(target: ManuscriptTarget) {
    if (!onHandoff || !projectId || handoffBusy) return;
    setHandoffBusy(true); setError("");
    try {
      const result = owner.compileResult, main = owner.mainPath, sequence = owner.compileSequence;
      if (owner.compileState === "compiling" || !result?.ok || !result.source_snapshot?.manifest_path || !bridge.readManuscriptSnapshot) throw new Error(t("Compile the current manuscript before sending it to review or slides."));
      const documents = [...owner.documents.values()];
      if (documents.some((document) => document.draft !== document.savedDraft || document.saveState !== "saved")) throw new Error(t("Save and recompile the manuscript before handing off these edits."));
      await Promise.all(documents.map((document) => document.saveQueue));
      const versions = documents.map((document) => document.version);
      const verified = await bridge.readManuscriptSnapshot(owner.workspace, result.source_snapshot.manifest_path);
      if (owner.mainPath !== main || owner.compileSequence !== sequence || documents.some((document, index) => document.version !== versions[index] || document.draft !== document.savedDraft || document.saveState !== "saved")) throw new Error(t("The manuscript changed while preparing the handoff. Save and compile again."));
      if (verified.status === "unverified") throw new Error(t("This build cannot verify these source inputs: {paths}. Use files inside the manuscript folder before handing it off.", { paths: verified.requested_source.untracked_inputs.map((input) => input.path).join(", ") }));
      if (!verified.current || !verified.pdf || verified.source_path !== main) throw new Error(t("This PDF no longer matches a verified current manuscript. Compile again before continuing."));
      await onHandoff(target, { workspace: verified.workspace, projectId, mainPath: main, selectedPath: owner.selectedPath || main, manifestPath: verified.manifest_path, sourceVersion: verified.requested_source.source_version, pdfPath: verified.pdf.path, pdfSha256: verified.pdf.sha256, buildId: verified.build_id });
    } catch (reason) { setError(reason instanceof Error ? reason.message : String(reason)); }
    finally { setHandoffBusy(false); }
  }

  const compile = useCallback(async (target = mainPath) => {
    if (!target || owner.fileOperationBusy) return;
    owner.compileTarget = target;
    const requestId = `${compileRequestPrefix}:${++compileRequestSequence.current}`;
    owner.compileRequestId = requestId;
    setCompilePhase("Preparing compiler"); setCompileLog(""); setCompileElapsed(0);
    const sequence = ++owner.compileSequence;
    setCompileState("compiling"); setCompileResult(null); setError("");
    try {
      const documents = [...owner.documents.values()];
      await Promise.all(documents.map((document) => saveWritingDocument(document, bridge.writeWorkspaceFile, refreshScope)));
      if (sequence !== owner.compileSequence) return;
      if (documents.some((document) => document.draft !== document.savedDraft)) throw new Error(t("The sources changed while saving. Compile again to use the latest edits."));
      const result = await bridge.compileLatexDocument(owner.workspace, target, requestId);
      if (sequence !== owner.compileSequence) return;
      setCompileResult({ ...result, preview_url: result.ok ? result.preview_url : undefined }); setCompileState(result.ok ? "success" : "error"); setActiveProblem(result.ok ? null : result.diagnostics.find((item) => item.line)?.line ?? null);
      if (!result.ok && result.diagnostics.length) {
        const diagnostic = result.diagnostics.find((item) => item.line) ?? result.diagnostics[0];
        const output = result.diagnostics.slice(0, 3).map((item) => `${item.line ? `line ${item.line}: ` : ""}${item.message}`).join("\n");
        emitProactiveSignal({
          source: "latex",
          title: `Build failed: ${diagnostic.message.slice(0, 90)}`,
          whyNow: `The last LaTeX build of ${target}${diagnostic.line ? ` failed on line ${diagnostic.line}` : " failed"}.`,
          evidence: [{
            kind: "terminal",
            command: "latexmk",
            exitCode: 1,
            output: output || (result.log ?? "").slice(0, 1200),
            filePath: target,
            line: diagnostic.line ?? undefined,
          }],
          action: {
            kind: "insert",
            label: "Ask AI to fix",
            text: `The LaTeX build failed. Help me fix it without changing the argument.\n\nFile: ${target}${diagnostic.line ? `\nLine: ${diagnostic.line}` : ""}\nProblem: ${diagnostic.message}\n\nBuild log:\n${(result.log ?? output).slice(0, 1600)}`,
          },
          confidence: 0.9,
          fingerprint: fingerprintFor("latex", `${target}:${diagnostic.line ?? 0}:${diagnostic.message}:${result.diagnostics.length}`),
        });
      }
    } catch (nextError) {
      if (sequence !== owner.compileSequence) return;
      setCompileState("error"); setError(nextError instanceof Error ? nextError.message : String(nextError));
    }
  }, [bridge, compileRequestPrefix, mainPath, owner, refreshScope, t]);

  useEffect(() => bridge.onLatexCompileProgress?.((input) => {
    const target = scopesRef.current.get(input.workspace || "");
    if (!target || target.compileState !== "compiling" || target.compileTarget !== input.path || !input.requestId || target.compileRequestId !== input.requestId) return;
    target.compilePhase = input.stage;
    if (input.log) target.compileLog = (target.compileLog + input.log).slice(-16000);
    refreshScope();
  }), [bridge, refreshScope]);

  useEffect(() => {
    if (compileState !== "compiling") return;
    const started = Date.now();
    const timer = window.setInterval(() => setCompileElapsed(Math.floor((Date.now() - started) / 1000)), 1000);
    return () => window.clearInterval(timer);
  }, [compileState, owner]);

  useEffect(() => {
    if (!openRequest?.path) return;
    const request = JSON.stringify([openRequest.token, openRequest.path]);
    if (consumedOpenRequest.current === request) return;
    consumedOpenRequest.current = request;
    void activateProject(openRequest.path).then(() => {
      if (openRequest.milestoneId && projectId && workspaceId) setVersionOwner({ owner, context: { dataRoot, projectId, workspaceId, executionRoot: owner.workspace, mainPath: openRequest.path, threadId }, initialId: openRequest.milestoneId });
    });
  }, [activateProject, openRequest?.path, openRequest?.token, openRequest?.milestoneId]);
  useEffect(() => { mountedRef.current = true; return () => { mountedRef.current = false; }; }, []);
  useEffect(() => () => {
    // Writing autosaves on departure as well as on its debounce. Do not park an
    // unsaved buffer indefinitely just because another root becomes visible.
    for (const item of owner.documents.values()) if (item.draft !== item.savedDraft) void saveWritingDocument(item, bridge.writeWorkspaceFile, refreshScope).catch(() => {});
  }, [bridge, owner, refreshScope]);
  useEffect(() => { window.localStorage.setItem("archimedes-paper-browser-width", String(browserWidth)); }, [browserWidth]);
  useEffect(() => { window.localStorage.setItem("archimedes-paper-split", String(previewSplit)); }, [previewSplit]);
  useEffect(() => { window.localStorage.setItem("archimedes-paper-browser-collapsed", String(browserCollapsed)); }, [browserCollapsed]);
  useEffect(() => () => document.body.classList.remove("paper-pane-resizing"), []);
  useEffect(() => {
    const query = window.matchMedia("(min-width: 861px)");
    const update = () => setWidePanes(query.matches);
    update();
    query.addEventListener("change", update);
    return () => query.removeEventListener("change", update);
  }, []);
  useEffect(() => {
    const element = workspaceRef.current;
    if (!element) return;
    const observer = new ResizeObserver((entries) => setPaneWidth(Math.round(entries[0]?.contentRect.width || 0)));
    observer.observe(element);
    setPaneWidth(element.clientWidth);
    return () => observer.disconnect();
  }, []);
  useEffect(() => {
    if (!currentDocument || draft === savedDraft || owner.fileOperationBusy) return;
    const timer = window.setTimeout(async () => {
      try {
        await saveWritingDocument(currentDocument, bridge.writeWorkspaceFile, refreshScope);
        if (autoCompile && mainPath && owner.selectedPath === currentDocument.file.path && owner.mainPath === mainPath) void compile(mainPath);
      } catch { /* The owner's buffer retains its unsaved text and save error. */ }
    }, 750);
    return () => {
      window.clearTimeout(timer);
      if (owner.selectedPath !== currentDocument.file.path && currentDocument.draft !== currentDocument.savedDraft) void saveWritingDocument(currentDocument, bridge.writeWorkspaceFile, refreshScope).catch(() => {});
    };
  }, [autoCompile, bridge, compile, currentDocument, draft, mainPath, owner, owner.fileOperationBusy, refreshScope, savedDraft]);

  async function createProject() {
    if (creating) return;
    setCreating(true); setError("");
    try {
      const created = await bridge.createLatexProject(workspace, projectName.trim() || "paper", templateId);
      await onRefresh(); await activateProject(created.path); void compile(created.path);
    } catch (nextError) { setError(nextError instanceof Error ? nextError.message : String(nextError)); } finally { setCreating(false); }
  }
  async function importFolder() {
    setImporting(true); setError("");
    try {
      const imported = await bridge.importLatexFolder(workspace);
      if (imported.canceled) return;
      await onRefresh();
      if (imported.main_path) await activateProject(imported.main_path);
      else setError("The imported folder has no .tex document. Add one, then open the project again.");
    } catch (nextError) { setError(nextError instanceof Error ? nextError.message : String(nextError)); } finally { setImporting(false); }
  }
  async function createEntry(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const name = createName.trim().replaceAll("\\", "/").replace(/^\/+/, "");
    if (!name || !createKind || !activeProject) return;
    const parent = activeDirectory || activeProject;
    try {
      if (createKind === "file") {
        const created = await bridge.createLatexFile(workspace, `${parent}/${name}`);
        setCreateKind(null); await loadDirectory(parent, parent === activeProject); await openFile(created.path);
      } else {
        const created = await bridge.createLatexDirectory(workspace, `${parent}/${name}`);
        setCreateKind(null); setActiveDirectory(created.path); setExpanded((current) => new Set(current).add(created.path)); await loadDirectory(parent, parent === activeProject);
      }
      await onRefresh();
    } catch (nextError) { setError(nextError instanceof Error ? nextError.message : String(nextError)); }
  }
  function toggleDirectory(path: string) {
    setActiveDirectory(path);
    setExpanded((current) => { const next = new Set(current); next.has(path) ? next.delete(path) : next.add(path); return next; });
  }
  function paneLimits() {
    const element = workspaceRef.current;
    const width = element?.clientWidth || paneWidth || 0;
    const browser = browserCollapsed ? 0 : Math.min(browserWidth, browserTrackFor(width));
    const available = Math.max(1, width - browser);
    const minSplit = Math.min(PREVIEW_SPLIT_MAX, PREVIEW_MIN_WIDTH / available);
    const maxSplit = Math.max(PREVIEW_SPLIT_MIN, (available - EDITOR_MIN_WIDTH) / available);
    return { rect: element?.getBoundingClientRect(), width, available, browserMax: browserTrackFor(width), minSplit, maxSplit };
  }
  function beginPaneResize(kind: "browser" | "preview", event: React.PointerEvent<HTMLDivElement>) {
    if (event.button !== 0) return;
    event.preventDefault();
    paneDragRef.current = { kind, startX: event.clientX, startBrowser: browserWidth, startSplit: previewSplit };
    event.currentTarget.setPointerCapture(event.pointerId);
    document.body.classList.add("paper-pane-resizing");
  }
  function movePaneResize(event: React.PointerEvent<HTMLDivElement>) {
    const drag = paneDragRef.current;
    if (!drag) return;
    const { rect, available, minSplit, maxSplit, browserMax } = paneLimits();
    if (!rect) return;
    if (drag.kind === "browser") {
      setBrowserWidth(clampSetting(drag.startBrowser + event.clientX - drag.startX, BROWSER_MIN_WIDTH, browserMax));
      return;
    }
    setPreviewSplit(clampSetting((rect.right - event.clientX) / available, Math.min(minSplit, maxSplit), maxSplit));
  }
  function endPaneResize(event: React.PointerEvent<HTMLDivElement>) {
    if (!paneDragRef.current) return;
    paneDragRef.current = null;
    if (event.currentTarget.hasPointerCapture(event.pointerId)) event.currentTarget.releasePointerCapture(event.pointerId);
    document.body.classList.remove("paper-pane-resizing");
  }
  function handlePaneResizeKey(kind: "browser" | "preview", event: React.KeyboardEvent<HTMLDivElement>) {
    const { minSplit, maxSplit, browserMax } = paneLimits();
    const direction = event.key === "ArrowLeft" ? -1 : event.key === "ArrowRight" ? 1 : 0;
    if (kind === "browser") {
      if (direction) { event.preventDefault(); setBrowserWidth((width) => clampSetting(width + direction * 8, BROWSER_MIN_WIDTH, browserMax)); return; }
      if (event.key === "Home") { event.preventDefault(); setBrowserWidth(BROWSER_MIN_WIDTH); }
      else if (event.key === "End") { event.preventDefault(); setBrowserWidth(browserMax); }
      return;
    }
    if (direction) { event.preventDefault(); setPreviewSplit((split) => clampSetting(split - direction * 0.02, Math.min(minSplit, maxSplit), maxSplit)); return; }
    if (event.key === "Home") { event.preventDefault(); setPreviewSplit(maxSplit); }
    else if (event.key === "End") { event.preventDefault(); setPreviewSplit(minSplit); }
  }
  function syncScroll(element: HTMLTextAreaElement) {
    if (lineNumbersRef.current) lineNumbersRef.current.scrollTop = element.scrollTop;
    if (highlightRef.current) { highlightRef.current.scrollTop = element.scrollTop; highlightRef.current.scrollLeft = element.scrollLeft; }
  }
  function revealSearchMatch(start: number, end: number) {
    const editor = editorRef.current;
    if (!editor) return;
    editor.setSelectionRange(start, end);
    const before = draft.slice(0, start);
    const line = before.split("\n").length - 1;
    const column = start - before.lastIndexOf("\n") - 1;
    const style = getComputedStyle(editor);
    const height = Number.parseFloat(style.lineHeight) || 20;
    editor.scrollTop = Math.max(0, (line - 3) * height);
    // Measure the prefix so tabs and wide Unicode characters scroll correctly.
    const canvas = document.createElement("canvas");
    const context = canvas.getContext("2d");
    if (context) {
      context.font = `${style.fontSize} ${style.fontFamily}`;
      const prefix = draft.slice(start - column, start).replace(/\t/g, "  ");
      const width = context.measureText(prefix).width;
      editor.scrollLeft = Math.max(0, width - editor.clientWidth / 2);
    }
    syncScroll(editor);
  }
  function openSearch() {
    const editor = editorRef.current;
    if (!editor) return;
    const selected = draft.slice(editor.selectionStart, editor.selectionEnd);
    const query = selected && !selected.includes("\n") ? selected : searchQuery;
    setCoedit(false);
    setSearchQuery(query);
    setSearchOpen(true);
    const matches = findSourceMatches(draft, query);
    const match = matches.find((item) => item.start >= editor.selectionStart) ?? matches[0];
    setSearchOffset(match?.start ?? 0);
    window.requestAnimationFrame(() => {
      searchInputRef.current?.focus();
      searchInputRef.current?.select();
      if (match) revealSearchMatch(match.start, match.end);
    });
  }
  function closeSearch() {
    setSearchOpen(false);
    editorRef.current?.focus();
  }
  function changeSearch(query: string) {
    setSearchQuery(query);
    setSearchOffset(0);
    const first = findSourceMatches(draft, query)[0];
    if (first) revealSearchMatch(first.start, first.end);
  }
  function navigateSearch(direction: number) {
    if (!searchMatches.length) return;
    const index = (activeMatchIndex + direction + searchMatches.length) % searchMatches.length;
    const match = searchMatches[index];
    setSearchOffset(match.start);
    revealSearchMatch(match.start, match.end);
  }
  function handleSourceKey(event: React.KeyboardEvent<HTMLElement>) {
    if ((event.metaKey || event.ctrlKey) && event.key.toLowerCase() === "f" && file) {
      event.preventDefault();
      event.stopPropagation();
      openSearch();
    } else if (searchOpen && event.key === "Escape") {
      event.preventDefault();
      event.stopPropagation();
      closeSearch();
    }
  }
  function jumpToProblem(diagnostic: LatexCompileDiagnostic) {
    if (!diagnostic.line || !editorRef.current) return;
    const offset = lineStart(draft, diagnostic.line);
    setActiveProblem(diagnostic.line); editorRef.current.focus(); editorRef.current.setSelectionRange(offset, offset);
    const height = Number.parseFloat(getComputedStyle(editorRef.current).lineHeight) || 20;
    editorRef.current.scrollTop = Math.max(0, (diagnostic.line - 3) * height); syncScroll(editorRef.current);
  }

  const lines = useMemo(() => draft.split("\n"), [draft]);
  const problemLines = useMemo(() => new Set(compileResult?.diagnostics.flatMap((item) => item.line ? [item.line] : []) ?? []), [compileResult]);
  const projectLabel = activeProject === "." ? t("Project folder") : activeProject.split("/").at(-1) || t("New project");
  const availableProjects = projects.some((project) => project.main) ? projects.filter((project) => project.main) : projects;
  const projectDocuments = projects.filter((project) => activeProject === "." || project.path.startsWith(`${activeProject}/`));
  const mainDocuments = projectDocuments.some((project) => project.main) ? projectDocuments.filter((project) => project.main) : projectDocuments;
  const mainChoices = mainPath && !mainDocuments.some((project) => project.path === mainPath) ? [{ path: mainPath, title: mainPath, main: true }, ...mainDocuments] : mainDocuments;
  const browserTrack = browserCollapsed ? 0 : Math.min(browserWidth, browserTrackFor(paneWidth));
  const availableTrack = Math.max(1, paneWidth - browserTrack);
  const minPreviewSplit = paneWidth ? Math.min(PREVIEW_SPLIT_MAX, PREVIEW_MIN_WIDTH / availableTrack) : PREVIEW_SPLIT_MIN;
  const maxPreviewSplit = paneWidth ? Math.max(PREVIEW_SPLIT_MIN, (availableTrack - EDITOR_MIN_WIDTH) / availableTrack) : PREVIEW_SPLIT_MAX;
  const effectivePreviewSplit = clampSetting(previewSplit, Math.min(minPreviewSplit, maxPreviewSplit), maxPreviewSplit);
  const paneStyle = widePanes ? {
    gridTemplateColumns: paneWidth
      ? `${Math.round(browserTrack)}px ${Math.round(Math.max(EDITOR_MIN_WIDTH, availableTrack * (1 - effectivePreviewSplit)))}px ${Math.round(Math.max(PREVIEW_MIN_WIDTH, availableTrack * effectivePreviewSplit))}px`
      : `${browserWidth}px calc((100% - ${browserWidth}px) * ${1 - previewSplit}) calc((100% - ${browserWidth}px) * ${previewSplit})`,
  } as React.CSSProperties : undefined;

  return <div className="paper-writing-page" data-surface="writing">
    {citationOwner && active && citationOwner.owner === owner && citationOwner.projectId === projectId && citationOwner.mainPath === mainPath && <PaperWritingCitations key={`${projectId}:${citationOwner.mainPath}`} bridge={bridge} projectId={citationOwner.projectId} mainPath={citationOwner.mainPath} bibliographyPaths={[...new Set([...manuscriptBibliographyPaths(owner.documents.get(mainPath)?.draft || "", mainPath), ...[...owner.documents.keys()].filter(name => ext(name) === "bib")])]} onClose={() => setCitationOwner(null)} onApply={applyCitation} />}
    {versionOwner && active && versionOwner.owner === owner && versionOwner.context.projectId === projectId && versionOwner.context.mainPath === mainPath && <PaperWritingVersions key={`${versionOwner.context.projectId}:${versionOwner.context.mainPath}:${versionOwner.initialId || ""}`} initialId={versionOwner.initialId} onClose={() => setVersionOwner(null)} onList={async () => bridge.listManuscriptVersions ? bridge.listManuscriptVersions(versionOwner.context) : []} onSave={name => withSavedManuscript(async selected => { if (!bridge.saveManuscriptVersion) throw new Error(t("Key versions are available in the desktop app.")); return bridge.saveManuscriptVersion({ ...selected.context, name }); })} onCompare={id => withSavedManuscript(async selected => { if (!bridge.compareManuscriptVersion) throw new Error(t("Key versions are available in the desktop app.")); return bridge.compareManuscriptVersion({ ...selected.context, id }); })} onRestore={restoreVersion} />}
    {pendingFigure && <div className="manuscript-source-receipt" role="status"><strong>{t("Add project figure")}: {pendingFigure.request.title}</strong><span>{t("Choose an existing manuscript, then insert the saved figure at the cursor. Existing text is kept.")}</span><div>{!pendingFigure.inserted && <button disabled={pendingFigure.busy || !currentDocument || ext(currentDocument.file.path) !== "tex" || !mainPath || !workspaceId} onClick={() => void insertResultFigure()}>{pendingFigure.busy ? t("Preparing figure…") : pendingFigure.receipt ? t("Insert at current cursor") : t("Insert figure")}</button>}<button disabled={pendingFigure.busy || !mainPath} onClick={() => void addFigurePackage()}>{t("Add graphicx to main")}</button>{onReturnToResult && <button onClick={() => void onReturnToResult(pendingFigure.request.resultId)}>{t("Open source result")}</button>}<button onClick={() => { figureInsertions.current.delete(insertionKey); refreshScope(); }}>{t("Dismiss")}</button></div>{pendingFigure.error && <span>{pendingFigure.error}</span>}</div>}
    <div className={browserCollapsed && widePanes ? "paper-writing-workspace browser-collapsed" : "paper-writing-workspace"} ref={workspaceRef} style={paneStyle}>
      <aside className="paper-source-browser"><div className="paper-browser-title"><FolderOpen size={14} /><strong>{projectLabel}</strong>{activeProject && <div className="paper-browser-actions"><button onClick={() => { setCreateKind("file"); setCreateName("section.tex"); }} aria-label="New LaTeX file"><FilePlus2 size={14} /></button><button onClick={() => { setCreateKind("folder"); setCreateName("figures"); }} aria-label="New folder"><FolderPlus size={14} /></button></div>}</div><label className="paper-main-document">Main document<select value={mainPath} disabled={!activeProject} onChange={(event) => { setMainPath(event.target.value); void openFile(event.target.value); }}>{!activeProject && <option value="">Choose a project first</option>}{mainChoices.map((project) => <option key={project.path} value={project.path}>{project.path}</option>)}</select></label><div className="paper-tree-scroll">{activeProject ? tree.entries.map((entry) => <TreeNode key={entry.path} entry={entry} depth={0} selected={file?.path || ""} activeDirectory={activeDirectory} expanded={expanded} loading={loading} onToggle={toggleDirectory} onLoad={(path) => void loadDirectory(path)} onOpen={(path) => void openFile(path)} />) : <StateView compact className="paper-project-placeholder" icon={<FolderOpen size={20} />} title={t("No project selected")} description={t("Choose an existing manuscript or start a new one.")} />}</div><div className="paper-pane-resizer" role="separator" aria-orientation="vertical" aria-label="Resize file browser" title="Drag to resize · double-click to reset" aria-valuemin={BROWSER_MIN_WIDTH} aria-valuemax={BROWSER_MAX_WIDTH} aria-valuenow={Math.round(browserWidth)} tabIndex={0} onPointerDown={(event) => beginPaneResize("browser", event)} onPointerMove={movePaneResize} onPointerUp={endPaneResize} onPointerCancel={endPaneResize} onDoubleClick={() => setBrowserWidth(BROWSER_DEFAULT_WIDTH)} onKeyDown={(event) => handlePaneResizeKey("browser", event)} /></aside>
      <section className="latex-editor-pane" onKeyDown={handleSourceKey}><div className="paper-pane-toolbar"><button className="paper-browser-toggle" onClick={() => setBrowserCollapsed((collapsed) => !collapsed)} title={browserCollapsed ? "Show file browser" : "Hide file browser"} aria-label={browserCollapsed ? "Show file browser" : "Hide file browser"} aria-pressed={!browserCollapsed}>{browserCollapsed ? <PanelLeftOpen size={13} /> : <PanelLeftClose size={13} />}</button><FileCode2 size={14} /><strong>{file?.name || "No source selected"}</strong><button className={searchOpen ? "paper-pane-action icon active" : "paper-pane-action icon"} disabled={!file} onClick={() => searchOpen ? closeSearch() : openSearch()} title={`${t("Search source")} (Ctrl/Cmd+F)`} aria-label={t("Search source")} aria-expanded={searchOpen} aria-controls={searchId}><Search size={14} /></button><span className={`paper-save-state ${saveState}`}>{saveState === "saving" ? <LoaderCircle className="spin" size={11} /> : saveState === "saved" ? <Check size={11} /> : <CircleDot size={11} />}{saveState === "saving" ? "Saving" : saveState === "saved" ? "Saved" : "Unsaved"}</span><span className="paper-continuity-tools"><button className="paper-pane-action icon" disabled={!file || !projectId || ext(file.path) !== "tex" || owner.fileOperationBusy} onClick={openCitations} title={t("Insert citation")} aria-label={t("Insert citation")}><BookOpen size={14} /></button><button className="paper-pane-action icon" disabled={!mainPath || !projectId || !workspaceId || !bridge.saveManuscriptVersion || owner.fileOperationBusy || compileState === "compiling"} onClick={() => openVersions()} title={t("Key versions")} aria-label={t("Key versions")}><History size={14} /></button></span><button className={coedit ? "paper-pane-action active" : "paper-pane-action"} disabled={!file || !projectId} onClick={() => { setCoedit((value) => !value); setSearchOpen(false); }} title="Co-edit this source with project members"><Cloud size={13} /><span>{coedit ? "Co-editing" : "Co-edit"}</span></button></div>
        {searchOpen && file && <div className="latex-source-search" id={searchId} role="search" aria-label={t("Search source")}>
          <Search size={14} aria-hidden="true" />
          <input ref={searchInputRef} type="text" value={searchQuery} onChange={(event) => changeSearch(event.target.value)} onKeyDown={(event) => {
            if (event.key === "Enter" && !event.nativeEvent.isComposing) { event.preventDefault(); navigateSearch(event.shiftKey ? -1 : 1); }
          }} placeholder={t("Find in source…")} aria-label={t("Find in source")} aria-describedby={`${searchId}-count`} spellCheck={false} />
          <span id={`${searchId}-count`} className="latex-search-count" role="status" aria-live="polite">{searchQuery ? searchMatches.length ? `${activeMatchIndex + 1} / ${searchMatches.length}` : t("No matches") : ""}</span>
          <button type="button" disabled={!searchMatches.length} onClick={() => navigateSearch(-1)} title={`${t("Previous match")} (Shift+Enter)`} aria-label={t("Previous match")}><ArrowUp size={14} /></button>
          <button type="button" disabled={!searchMatches.length} onClick={() => navigateSearch(1)} title={`${t("Next match")} (Enter)`} aria-label={t("Next match")}><ArrowDown size={14} /></button>
          <button type="button" onClick={closeSearch} title={`${t("Close search")} (Esc)`} aria-label={t("Close search")}><X size={14} /></button>
        </div>}
        {file ? <>{coedit && projectId && <div className="latex-coedit-pane"><SharedNoteEditor bridge={bridge} projectId={projectId} docKey={`latex:${file.path}`} initialText={draft} title={`Co-editing ${file.name}`} onTextChange={(text) => { setDraft(text); }} /></div>}<div className={coedit ? "latex-editor-body coediting" : "latex-editor-body"}><div className="latex-line-numbers" ref={lineNumbersRef}>{lines.map((_, index) => <span key={index} className={problemLines.has(index + 1) ? "diagnostic" : ""}>{problemLines.has(index + 1) ? <AlertTriangle size={10} /> : index + 1}</span>)}</div><div className="latex-editor-layer"><pre className="latex-highlight" ref={highlightRef} aria-hidden="true">{lines.map((line, index) => <HighlightLine key={index} text={line} marks={searchMarks.get(index)} activeMatch={activeMatchIndex} problem={problemLines.has(index + 1) || activeProblem === index + 1} />)}</pre><textarea className="latex-editor-textarea" ref={editorRef} value={draft} readOnly={owner.fileOperationBusy} onChange={(event) => { setDraft(event.target.value); }} onKeyDown={(event) => { if (event.key === "Tab") { event.preventDefault(); const target = event.currentTarget; const next = `${draft.slice(0, target.selectionStart)}  ${draft.slice(target.selectionEnd)}`; const start = target.selectionStart; setDraft(next); window.requestAnimationFrame(() => target.setSelectionRange(start + 2, start + 2)); } if ((event.metaKey || event.ctrlKey) && event.key.toLowerCase() === "s") { event.preventDefault(); void compile(); } }} onScroll={(event) => syncScroll(event.currentTarget)} spellCheck={false} aria-label={`Edit ${file.path}`} /></div></div></> : <StateView className="paper-writing-empty" icon={<FileText size={25} />} title="No LaTeX project open" description={t("Open an existing manuscript, or create a new paper from a template.")} action={<button className="primary-button" onClick={() => { setChooserTab("existing"); setChooserOpen(true); void refreshProjects(); }}><FolderOpen size={14} />Open project</button>} />}{buildLogOpen && <section id={buildLogId} className="latex-live-log" aria-label={t("Build log")}><strong>{t("Build log")}</strong><pre tabIndex={0}>{compileState === "compiling" ? compileLog || t("Waiting for compiler output…") : compileResult?.log || compileLog || t("No build log yet.")}</pre></section>}{(error || compileResult?.diagnostics.length || (compileResult && !compileResult.ok)) && <div className="latex-diagnostics"><header><AlertTriangle size={13} /><strong>{error ? "Workspace error" : `Problems · ${compileResult?.diagnostics.length || 1}`}</strong><span>{error ? "Resolve this before compiling again." : "Select a problem to jump to the source line."}</span></header>{error && <p>{error}</p>}{compileResult?.diagnostics.map((diagnostic, index) => <button key={`${diagnostic.line}-${index}`} className={diagnostic.line === activeProblem ? "active" : ""} onClick={() => jumpToProblem(diagnostic)}><b>{diagnostic.line ? `Line ${diagnostic.line}` : "LaTeX"}</b><span>{t(diagnostic.message)}{diagnostic.help && <small className="latex-diagnostic-help">{t(diagnostic.help)}</small>}</span></button>)}{compileResult && !compileResult.ok && compileResult.log && <details><summary>Show full build log</summary><pre>{compileResult.log}</pre></details>}</div>}<div className="paper-pane-resizer" role="separator" aria-orientation="vertical" aria-label="Resize PDF preview" title="Drag to resize · double-click to reset" aria-valuemin={Math.round(PREVIEW_SPLIT_MIN * 100)} aria-valuemax={Math.round(PREVIEW_SPLIT_MAX * 100)} aria-valuenow={Math.round(effectivePreviewSplit * 100)} tabIndex={0} onPointerDown={(event) => beginPaneResize("preview", event)} onPointerMove={movePaneResize} onPointerUp={endPaneResize} onPointerCancel={endPaneResize} onDoubleClick={() => setPreviewSplit(PREVIEW_SPLIT_DEFAULT)} onKeyDown={(event) => handlePaneResizeKey("preview", event)} /></section>
      <section className="paper-pdf-pane"><div className="paper-pane-toolbar"><FileText size={14} /><strong>PDF preview</strong><label className="paper-auto-compile"><input type="checkbox" checked={autoCompile} onChange={(event) => setAutoCompile(event.target.checked)} />Auto compile</label><span className={`paper-compile-state ${compileState}`}>{compileState === "compiling" ? <LoaderCircle className="spin" size={11} /> : compileState === "success" ? <Check size={11} /> : compileState === "error" ? <AlertTriangle size={11} /> : null}{compileState === "success" ? `${compileResult?.duration_ms ?? 0} ms` : compileState === "error" ? "Build failed" : compileState === "compiling" ? `${t(compilePhase)} · ${compileElapsed}s` : "Not built"}</span><div className="paper-pane-actions">{onHandoff && <><button className="paper-pane-action" disabled={handoffBusy || !mainPath || compileState === "compiling"} onClick={() => void handoffManuscript("paper-review")} title={t("Review current PDF")}>{t("Review current PDF")}</button><button className="paper-pane-action" disabled={handoffBusy || !mainPath || compileState === "compiling"} onClick={() => void handoffManuscript("paper-to-slides")} title={t("Slides from current PDF")}>{t("Slides from current PDF")}</button></>}<button className={buildLogOpen ? "paper-pane-action active" : "paper-pane-action"} onClick={() => setBuildLogOpen((open) => !open)} title={t("Build log")} aria-label={t("Build log")} aria-expanded={buildLogOpen} aria-controls={buildLogId}><FileText size={13} /><span>{t("Build log")}</span></button>{file && <button className="paper-pane-action" onClick={() => void Promise.resolve(onAskAI(file.path, { workspace: owner.workspace, projectId: projectId || null, mainPath: owner.mainPath || file.path, selectedPath: file.path })).catch((reason) => setError(String(reason)))} title="Ask AI about this file"><MessageCircle size={13} /><span>Ask AI</span></button>}<button className="paper-pane-action icon" onClick={() => { setChooserTab("existing"); setChooserOpen(true); void refreshProjects(); }} title="Projects" aria-label="Projects"><FolderOpen size={13} /></button>{activeProject && <><button className="paper-pane-action icon" disabled={importing} onClick={() => void importFolder()} title="Import folder" aria-label="Import folder">{importing ? <LoaderCircle className="spin" size={13} /> : <FolderUp size={13} />}</button><button className="paper-pane-action primary" disabled={!mainPath || compileState === "compiling"} onClick={() => void compile()} title="Recompile">{compileState === "compiling" ? <LoaderCircle className="spin" size={13} /> : <Play size={13} />}<span>{compileState === "compiling" ? "Compiling…" : "Recompile"}</span></button></>}</div></div>{compileResult?.ok && compileResult.preview_url ? <iframe key={compileResult.preview_url} src={compileResult.preview_url} title="Compiled paper PDF" /> : <StateView className="paper-writing-empty" icon={<FileText size={27} />} title="Compile to preview" description="The generated PDF appears here. Any build problem is listed beside the source with its line number." action={mainPath ? <button className="primary-button" disabled={compileState === "compiling"} onClick={() => void compile()}><Play size={14} />Compile paper</button> : undefined} />}</section>
    </div>
    <Dialog open={dialogOpen} onClose={() => setChooserOpen(false)} size="gallery" className="paper-project-dialog" overlayClassName="paper-create-backdrop app-dialog-overlay" ariaLabelledBy="paper-project-title">
        <header className="app-dialog-header"><div><h2 id="paper-project-title">{t("Continue writing")}</h2><p>{t("Open a manuscript in this project folder. Source files stay in place.")}</p></div><button className="app-dialog-close" onClick={() => setChooserOpen(false)} aria-label={t("Close project chooser")}><X size={16} /></button></header>
        <div className="app-dialog-body paper-project-body">
          <Tabs label={t("Writing project options")} value={chooserTab} onChange={(value) => setChooserTab(value as "existing" | "new")}><Tab value="existing">{t("Existing manuscripts")}</Tab><Tab value="new">{t("New manuscript")}</Tab></Tabs>
          {chooserTab === "existing" ? <div className="paper-existing-projects">
            <div className="paper-existing-project-heading"><h3>{t("Existing manuscripts")}</h3><button className="secondary-button" onClick={() => void refreshProjects()} disabled={owner.projectsLoading}><RefreshCw size={14} className={owner.projectsLoading ? "spin" : ""} />{t("Refresh")}</button></div>
            <p>{t("Choose the main document to continue editing. No compiler is needed to open a source file.")}</p>
            {owner.projectsLoading && <p role="status">{t("Looking for manuscripts…")}</p>}
            {!owner.projectsLoading && !availableProjects.length && <StateView compact icon={<FileText size={22} />} title={t("No manuscripts found")} description={t("Create a new manuscript or import an existing folder.")} action={<button className="primary-button" onClick={() => setChooserTab("new")}>{t("New manuscript")}</button>} />}
            {availableProjects.map((project) => <button key={project.path} onClick={() => void activateProject(project.path)}><FileCode2 size={14} /><span><strong>{project.title}</strong><small>{project.path}</small></span><ChevronRight size={15} /></button>)}
            {error && <p role="alert">{error}</p>}
          </div> : <PaperTemplateLibrary selected={templateId} onSelect={setTemplateId} projectName={projectName} onNameChange={setProjectName} creating={creating} importing={importing} error={error}
            onCreate={() => void createProject()} onImport={() => void importFolder()} onSource={(url) => void bridge.openExternalUrl(url)} />}
        </div>
    </Dialog>
    <Dialog open={createOpen} onClose={() => setCreateKind(null)} size="compact" className="paper-create-dialog" overlayClassName="paper-create-backdrop app-dialog-overlay" as="form" onSubmit={(event) => void createEntry(event)}><span className="page-kicker">{projectLabel}</span><h2>{createKind === "file" ? "New LaTeX file" : "New folder"}</h2><p>Creating in <strong>{activeDirectory || activeProject}</strong></p><label>{createKind === "file" ? "File name" : "Folder name"}<input autoFocus value={createName} onChange={(event) => setCreateName(event.target.value)} placeholder={createKind === "file" ? "section.tex" : "figures"} /></label><div><button type="button" className="secondary-button" onClick={() => setCreateKind(null)}>Cancel</button><button type="submit" className="primary-button" disabled={!createName.trim()}>Create</button></div></Dialog>
  </div>;
}
