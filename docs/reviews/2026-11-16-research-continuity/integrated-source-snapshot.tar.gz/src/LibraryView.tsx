import { memo, useCallback, useEffect, useMemo, useRef, useState, type KeyboardEvent as ReactKeyboardEvent, type MouseEvent as ReactMouseEvent, type PointerEvent as ReactPointerEvent, type WheelEvent as ReactWheelEvent } from "react";
import ReactMarkdown from "react-markdown";
import remarkGfm from "remark-gfm";
import remarkMath from "remark-math";
import rehypeKatex from "rehype-katex";
import { shouldSubmitPaperChatKey } from "./paperChatKeyboard";
import { visit } from "unist-util-visit";
import SyntaxHighlighter from "react-syntax-highlighter/dist/esm/prism-light";
import bash from "react-syntax-highlighter/dist/esm/languages/prism/bash";
import c from "react-syntax-highlighter/dist/esm/languages/prism/c";
import cpp from "react-syntax-highlighter/dist/esm/languages/prism/cpp";
import css from "react-syntax-highlighter/dist/esm/languages/prism/css";
import go from "react-syntax-highlighter/dist/esm/languages/prism/go";
import java from "react-syntax-highlighter/dist/esm/languages/prism/java";
import javascript from "react-syntax-highlighter/dist/esm/languages/prism/javascript";
import json from "react-syntax-highlighter/dist/esm/languages/prism/json";
import jsx from "react-syntax-highlighter/dist/esm/languages/prism/jsx";
import latex from "react-syntax-highlighter/dist/esm/languages/prism/latex";
import markdown from "react-syntax-highlighter/dist/esm/languages/prism/markdown";
import markup from "react-syntax-highlighter/dist/esm/languages/prism/markup";
import python from "react-syntax-highlighter/dist/esm/languages/prism/python";
import rust from "react-syntax-highlighter/dist/esm/languages/prism/rust";
import sql from "react-syntax-highlighter/dist/esm/languages/prism/sql";
import tsx from "react-syntax-highlighter/dist/esm/languages/prism/tsx";
import typescript from "react-syntax-highlighter/dist/esm/languages/prism/typescript";
import yaml from "react-syntax-highlighter/dist/esm/languages/prism/yaml";
import { forgetDailyFigure, peekDailyFigure, subscribeDailyFigure } from "./daily-figures";
import ConferenceDiscovery from "./ConferenceDiscovery";
import { discoveryPaperKey, discoveryStorageKey, readDiscoverySnapshot, writeDiscoverySnapshot, discoveryProvenance, type SelectionBridge } from "./discovery-state";
import ProjectPaperContext from "./ProjectPaperContext";
import PaperReviewWorkbench from "./PaperReviewWorkbench";
import PaperCanvas, { type PaperCanvasInsert, type PaperCanvasSource } from "./PaperCanvas";
import { equationTokens, findEquationRects } from "./pdf-equations";
import { applyPdfSearchHighlights } from "./pdf-search-highlights";
import { findPdfHorizontalRules, findRuledTableRect, findTextTableRect } from "./pdf-table-regions";
import { isDensePdfProse, mergePdfVisualRegions, pdfCaptionKind } from "./pdf-visual-regions";
import { buildPdfHighlightSegments, PDF_HIGHLIGHT_COLORS } from "./pdf-highlight-segments";
import { useUISettings, type Language } from "./i18n";
import { MenuItem, MenuSurface } from "./Menu";
import { Tabs, Tab, FilterGroup, FilterButton } from "./Tabs";
import { fingerprintFor } from "./proactive-engine";
import { emitProactiveSignal } from "./proactive-signals";
import {
  ArrowLeft,
  ArrowUp,
  Bookmark,
  BookOpen,
  Bot,
  Calendar,
  Check,
  ChevronDown,
  ChevronLeft,
  ChevronRight,
  ChevronUp,
  Clock3,
  Cloud,
  Code2,
  ExternalLink,
  FileCode2,
  FileText,
  Flame,
  FlaskConical,
  Folder,
  FolderOpen,
  Frame,
  GitBranch,
  GraduationCap,
  Highlighter,
  Languages,
  Library,
  ListTree,
  LoaderCircle,
  MessageCircleReply,
  Minus,
  PanelRightClose,
  PanelRightOpen,
  Pencil,
  Plus,
  RefreshCw,
  Save,
  Search,
  Shield,
  Sparkle,
  Square,
  Star,
  StickyNote,
  Trash,
  X,
} from "lucide-react";
import { StateView } from "./StateView";
import { Dialog } from "./Dialog";
import { InlineNotice } from "./InlineNotice";
import LibraryWorkspace from "./LibraryWorkspace";
import { LibraryPaperNotes, type LibraryNoteDrafts } from "./LibraryPaperNotes";
import type { PaperReaderSession } from "./library-workspace-state";

const LIBRARY_COLORS = ["#3973c8", "#2d8a68", "#a8652e", "#7a5bb5", "#b34f58"];
const PAPER_CHAT_DEFAULT_WIDTH = 354;
const PAPER_CHAT_MIN_WIDTH = 280;
const PAPER_CHAT_MAX_WIDTH = 640;
const PDF_VIEWPORT_WIDTH_STEP = 16;

function clampPaperChatWidth(value: number) {
  return Math.min(PAPER_CHAT_MAX_WIDTH, Math.max(PAPER_CHAT_MIN_WIDTH, Math.round(value)));
}

function readPaperChatWidth() {
  if (typeof window === "undefined") return PAPER_CHAT_DEFAULT_WIDTH;
  const stored = Number(window.localStorage.getItem("archimedes-paper-chat-width"));
  return Number.isFinite(stored) && stored > 0 ? clampPaperChatWidth(stored) : PAPER_CHAT_DEFAULT_WIDTH;
}
for (const [name, grammar] of Object.entries({ bash, c, cpp, css, go, java, javascript, json, jsx, latex, markdown, markup, python, rust, sql, tsx, typescript, yaml })) {
  SyntaxHighlighter.registerLanguage(name, grammar);
}

function codebaseLanguage(filePath: string) {
  const fileName = filePath.split("/").at(-1)?.toLowerCase() || "";
  if (["dockerfile", "makefile"].includes(fileName)) return "bash";
  const extension = fileName.split(".").at(-1) || "";
  return ({
    bash: "bash", c: "c", cc: "cpp", cjs: "javascript", cpp: "cpp", css: "css", go: "go",
    h: "c", hpp: "cpp", htm: "markup", html: "markup", java: "java", js: "javascript",
    json: "json", jsonl: "json", jsx: "jsx", md: "markdown", mdx: "markdown", mjs: "javascript",
    py: "python", rs: "rust", sh: "bash", sql: "sql", tex: "latex", toml: "yaml",
    ts: "typescript", tsx: "tsx", xml: "markup", yaml: "yaml", yml: "yaml", zsh: "bash",
  } as Record<string, string>)[extension];
}
const DAILY_TOPICS: Array<{ id: DailyDiscoveryTopic; label: string; description: string }> = [
  { id: "all", label: "All", description: "Recent AI, machine learning, and language-model papers" },
  { id: "ai4ai_rsi", label: "AI4AI/RSI", description: "AI systems improving AI and recursive self-improvement" },
  { id: "gui_compute_use", label: "GUI/Compute Use", description: "Agents operating graphical and computer interfaces" },
  { id: "coding_agents", label: "Coding Agents", description: "Agentic coding and software engineering" },
  { id: "reinforcement_learning", label: "Reinforcement Learning", description: "Learning policies through interaction and feedback" },
  { id: "on_policy_distillation", label: "On-Policy Distillation", description: "Distilling policies from on-policy or online trajectories" },
  { id: "robotics_vla", label: "Robotics/VLA", description: "Robotics and vision-language-action models" },
  { id: "world_models", label: "World Models", description: "Learned environment dynamics and simulation" },
  { id: "reasoning_test_time", label: "Reasoning / Test-Time Scaling", description: "Reasoning and inference-time computation" },
  { id: "interpretability", label: "Interpretability", description: "Understanding and explaining model behavior" },
  { id: "rag", label: "RAG & Long Context", description: "Retrieval, memory, and long-context models" },
  { id: "multimodal", label: "Multimodal", description: "Vision-language and multimodal models" },
  { id: "safety", label: "AI Safety", description: "Alignment, robustness, and red teaming" },
  { id: "science", label: "AI for Science", description: "Scientific discovery and research automation" },
  { id: "efficient_inference", label: "Efficient Inference", description: "Serving, quantization, and inference-time efficiency" },
  { id: "generative_models", label: "Generative Models", description: "Diffusion, flow, and generative modelling" },
  { id: "vision_3d", label: "Vision & 3D", description: "3D reconstruction, Gaussian splatting, and geometry" },
  { id: "speech_audio", label: "Speech & Audio", description: "Speech recognition, synthesis, and audio models" },
];

const DAILY_RANGES: Array<{ id: DailyDiscoveryRange; label: string }> = [
  { id: "7d", label: "7 days" },
  { id: "30d", label: "30 days" },
  { id: "90d", label: "90 days" },
  { id: "all", label: "All" },
];

function publicPaperRecordUrl(paper: Pick<LibraryPaper, "url" | "conference">) {
  return paper.conference?.presentation_source_url || paper.url;
}

function isGithubRepositoryLink(value: string) {
  return /^https:\/\/github\.com\/[^/]+\/[^/]+/i.test(value);
}

function linkedProjectLabel(value: string) {
  try {
    const host = new URL(value).hostname.replace(/^www\./, "");
    return host === "github.com" ? "GitHub project" : "Project website";
  } catch {
    return "Linked project";
  }
}

function linkedProjectHost(value: string) {
  try { return new URL(value).hostname.replace(/^www\./, ""); }
  catch { return "Linked project"; }
}

type LibraryViewProps = {
  bridge: ResearchDeskBridge;
  mode: "library" | "daily";
  initialDailyMode?: DailyDiscoveryMode | "conference";
  workspace?: string;
  dataRoot?: string;
  active?: boolean;
  projectId?: string | null;
  workspaceId?: string | null;
  libraryRefreshVersion?: number;
  openRequest?: { paperId: string; libraryId?: string; token: string; review?: boolean };
  onLibraryImported?: () => void;
  onInternalReviewThreadsDeleted?: (threadIds: string[]) => void;
  onReproduceOpened?: (reproductionId: string) => void;
  onOpenProject?: (projectId: string) => void;
};

export default function LibraryView(props: LibraryViewProps) {
  const { bridge, mode, initialDailyMode, workspace = "", dataRoot = workspace, active = true, projectId, workspaceId, libraryRefreshVersion = 0, onLibraryImported, onInternalReviewThreadsDeleted, onReproduceOpened, onOpenProject } = props;
  if (mode === "library") return <LibraryWorkspace
    key={`${workspace}:${projectId || "local"}`}
    bridge={bridge} projectId={projectId} active={active} refreshVersion={libraryRefreshVersion}
    openRequest={props.openRequest}
    onLibraryImported={onLibraryImported} onOpenProject={onOpenProject}
    renderReader={(readerProps) => <PaperReadingWorkbench {...readerProps} bridge={bridge} workspace={workspace} projectId={projectId} workspaceId={workspaceId} onInternalReviewThreadsDeleted={onInternalReviewThreadsDeleted} onReproduceOpened={onReproduceOpened} />}
    renderInspector={(inspectorProps) => <PaperInspector {...inspectorProps} bridge={bridge} projectId={projectId} />}
    renderEditor={(editorProps) => <LibraryEditor {...editorProps} active={active} />}
    renderImport={(importProps) => <PaperImportModal {...importProps} bridge={bridge} workspace={workspace} />}
  />;
  return <DailyLibraryView key={discoveryStorageKey(dataRoot, projectId)} dataRoot={dataRoot} bridge={bridge} projectId={projectId} initialMode={initialDailyMode} refreshVersion={libraryRefreshVersion} onLibraryImported={onLibraryImported} />;
}

function DailyLibraryView({ bridge, dataRoot, projectId, initialMode, refreshVersion, onLibraryImported }: {
  dataRoot: string; bridge: ResearchDeskBridge; projectId?: string | null; initialMode?: DailyDiscoveryMode | "conference"; refreshVersion: number; onLibraryImported?: () => void;
}) {
  const [libraries, setLibraries] = useState<ResearchLibrary[]>([]);
  const [loading, setLoading] = useState(true);
  const alive = useRef(true);
  const loadLibraries = useCallback(async () => {
    try {
      const next = await bridge.listLibraries(projectId ?? undefined);
      if (alive.current) setLibraries(next);
    } finally { if (alive.current) setLoading(false); }
  }, [bridge, projectId]);
  useEffect(() => {
    alive.current = true;
    void loadLibraries().catch(() => {});
    return () => { alive.current = false; };
  }, [loadLibraries, refreshVersion]);
  return <DailyDiscovery storageKey={discoveryStorageKey(dataRoot, projectId)} projectId={projectId} initialMode={initialMode} bridge={bridge} libraries={libraries} loadingLibraries={loading} onImported={async () => { await loadLibraries(); onLibraryImported?.(); }} />;
}

function PaperInspector({ bridge, projectId, paper, onUpdate, onRemove, onRead, noteDrafts }: { bridge: ResearchDeskBridge; projectId?: string | null; paper: LibraryPaper | null; onUpdate: (patch: Parameters<ResearchDeskBridge["updateLibraryPaper"]>[1]) => Promise<void>; onRemove: () => Promise<void>; onRead: () => void; noteDrafts: LibraryNoteDrafts }) {
  const { t } = useUISettings();
  const [authorsExpanded, setAuthorsExpanded] = useState(false);
  const [error, setError] = useState("");
  useEffect(() => { setAuthorsExpanded(false); setError(""); }, [paper?.id]);
  async function update(patch: Parameters<ResearchDeskBridge["updateLibraryPaper"]>[1]) {
    try { await onUpdate(patch); setError(""); }
    catch (cause) { setError(cause instanceof Error ? cause.message : String(cause)); }
  }
  if (!paper) return null;
  const authors = authorsExpanded ? paper.authors : paper.authors.slice(0, 3);
  return <article className="paper-inspector">
    {error && <InlineNotice tone="danger">{error}</InlineNotice>}
    <div className="paper-inspector-kicker"><span>{paper.venue || t("Research paper")}</span><span>{paper.year ?? t("Year unknown")}</span></div>
    <div className="paper-inspector-title"><h2>{paper.title}</h2><button className={paper.starred ? "icon-button starred" : "icon-button"} onClick={() => void update({ starred: !paper.starred })} aria-label={t(paper.starred ? "Unstar paper" : "Star paper")}><Star size={17} fill={paper.starred ? "currentColor" : "none"} /></button></div>
    <p className="paper-authors">{authors.join(", ") || t("Unknown authors")}{paper.authors.length > 3 && <button className="library-expand-authors" aria-expanded={authorsExpanded} onClick={() => setAuthorsExpanded((open) => !open)}>{t(authorsExpanded ? "Show fewer authors" : "Show all {count} authors", { count: paper.authors.length })}</button>}</p>
    {paper.conference && <div className="conference-saved-metadata"><span>{paper.conference.presentation === "unknown" ? "Unclassified" : paper.conference.presentation === "oral" ? "Oral" : paper.conference.presentation === "spotlight" ? "Spotlight" : "Poster"}</span><a href={paper.conference.presentation_source_url || paper.conference.source_url} target="_blank" rel="noreferrer">{t("Official conference record")}</a></div>}
    <p className="paper-abstract">{paper.abstract || t("No abstract available.")}</p>
    <div className="paper-record-row"><label>{t("Reading status")}<select value={paper.reading_status} onChange={(event) => void update({ reading_status: event.target.value as ReadingStatus })}><option value="unread">{t("Unread")}</option><option value="reading">{t("Reading")}</option><option value="read">{t("Already read")}</option></select></label>{publicPaperRecordUrl(paper) && <a className="outline-button" href={publicPaperRecordUrl(paper)} target="_blank" rel="noreferrer"><ExternalLink size={14} />{t("Open source")}</a>}</div>
    <button className="paper-reader-launch" onClick={onRead}><BookOpen size={15} /><span><strong>{t("Open reading workspace")}</strong><small>{t("Notes, evidence, and paper structure")}</small></span><ChevronRight size={16} /></button>
    <ProjectPaperContext key={`${projectId}:${paper.id}`} bridge={bridge} paperId={paper.id} projectId={projectId} />
    <LibraryPaperNotes key={paper.id} paper={paper} drafts={noteDrafts} compact onSave={(notes) => onUpdate({ notes })} />
    <button className="secondary-button danger-text library-remove-paper" onClick={() => void onRemove()}><Trash size={14} />{t("Remove")}</button>
  </article>;
}

type PaperChatMessage = { role: "assistant" | "user"; text: string };
type CodeChatAttachment = { path: string; startLine: number; endLine: number; snippet: string };
type PaperVisualKind = "figure" | "table" | "equation";
type PaperFigureCapture = { pageNumber: number; nearbyText: string; kind: PaperVisualKind; image: ContextAttachment };
type PaperAiMode = "brief" | "audit";
type PaperChatComposerCommand = { id: number; draft?: string };
type SelectionAnchor = { x: number; y: number };
type TranslationPopover = { source: string; translation: string; anchor: SelectionAnchor; error?: string };
type ReaderLibraryPaper = LibraryPaper & { github_url?: string; github_stars?: number };
type CodePathLocation = { path: string; startLine: number; endLine: number };
type CodeNavigationTarget = CodePathLocation & { nonce: number };

const CODE_PATH_EXTENSIONS = "py|pyi|ts|tsx|js|jsx|mjs|cjs|json|jsonl|yaml|yml|toml|md|mdx|sh|bash|zsh|r|cpp|cc|cxx|c|h|hpp|ipynb|txt|csv";
const CODE_PATH_TOKEN = new RegExp(`(?<![A-Za-z0-9_./:-])((?:[A-Za-z0-9._-]+/)+[A-Za-z0-9._-]+\\.(?:${CODE_PATH_EXTENSIONS}))(?::(\\d+)(?:\\s*[-–]\\s*(\\d+))?)?`, "gi");
const CODE_PATH_EXACT = new RegExp(`^((?:[A-Za-z0-9._-]+/)+[A-Za-z0-9._-]+\\.(?:${CODE_PATH_EXTENSIONS}))(?::(\\d+)(?:\\s*[-–]\\s*(\\d+))?)?$`, "i");

function parseCodePath(value: string): CodePathLocation | null {
  const match = String(value || "").trim().match(CODE_PATH_EXACT);
  if (!match) return null;
  const startLine = Math.max(1, Number(match[2]) || 1);
  return {
    path: match[1].replace(/\\/g, "/"),
    startLine,
    endLine: Math.max(startLine, Number(match[3]) || startLine),
  };
}

/**
 * Turn bare repository paths in prose into inline-code nodes, so the same
 * renderer can make them clickable without touching fenced code or URLs.
 */
function remarkCodePaths() {
  return (tree: unknown) => {
    visit(tree as never, "text", ((node: { value?: string }, index: number | undefined, parent: { type?: string; children?: unknown[] } | undefined) => {
      if (!parent?.children || index == null || parent.type === "link" || parent.type === "linkReference") return;
      const text = String(node.value || "");
      const matches = [...text.matchAll(CODE_PATH_TOKEN)];
      if (!matches.length) return;
      const children: Array<{ type: string; value: string }> = [];
      let cursor = 0;
      for (const match of matches) {
        const offset = match.index ?? 0;
        if (offset > cursor) children.push({ type: "text", value: text.slice(cursor, offset) });
        children.push({ type: "inlineCode", value: match[0] });
        cursor = offset + match[0].length;
      }
      if (cursor < text.length) children.push({ type: "text", value: text.slice(cursor) });
      parent.children.splice(index, 1, ...children);
      return index + children.length;
    }) as never);
  };
}
const PAPER_CHAT_INITIAL_VISIBLE_MESSAGE_COUNT = 60;
const PAPER_CHAT_HISTORY_PAGE_SIZE = 40;
const PAPER_BRIEFING_REQUEST_EN = "Create the initial full-paper reading briefing before answering any follow-up question. First call read_attached_paper_pdf repeatedly for the attached paper, in consecutive page ranges of at most 24 pages, until every available PDF page has been read. Do not substitute the abstract for full text. Then return concise English Markdown in this chat, with exactly these sections:\n\n## Key terms\nList 4-8 essential terms, each with a one-line explanation.\n\n## Three-sentence summary\nGive exactly three numbered sentences covering the problem, method, and main evidence/result.\n\n## Paper map\nUse bullets for research question, method, experiments/evaluation, and main findings. Cite PDF page numbers.\n\n## Limitations and open questions\nState limitations explicitly reported by the authors and open questions that need closer reading. Cite page numbers where possible.\n\nBe evidence-aware: distinguish what the paper states from your inference.";
const PAPER_BRIEFING_REQUEST_ZH = "Create the initial full-paper reading briefing before answering any follow-up question. First call read_attached_paper_pdf repeatedly for the attached paper, in consecutive page ranges of at most 24 pages, until every available PDF page has been read. Do not substitute the abstract for full text. Then return concise Chinese Markdown in this chat, with exactly these sections:\n\n## 关键词词典\nList 4-8 essential terms, each with a one-line explanation.\n\n## 三行摘要\nGive exactly three numbered sentences covering the problem, method, and main evidence/result.\n\n## 论文地图\nUse bullets for research question, method, experiments/evaluation, and main findings. Cite PDF page numbers.\n\n## 局限与待核查\nState limitations explicitly reported by the authors and open questions that need closer reading. Cite page numbers where possible.\n\nBe evidence-aware: distinguish what the paper states from your inference.";
const PAPER_BRIEFING_INSTRUCTION_PREFIX = "You are preparing a durable research reading guide for the paper ";

function paperBriefingRequest(language: Language) {
  return language === "zh" ? PAPER_BRIEFING_REQUEST_ZH : PAPER_BRIEFING_REQUEST_EN;
}

function isHiddenPaperBriefingInstruction(message: PaperChatMessage) {
  return message.role === "user" && (
    message.text === PAPER_BRIEFING_REQUEST_EN ||
    message.text === PAPER_BRIEFING_REQUEST_ZH ||
    message.text.startsWith(PAPER_BRIEFING_INSTRUCTION_PREFIX)
  );
}
const HIGHLIGHT_COLORS: Array<{ value: PaperHighlightInput["color"]; label: string }> = [
  { value: "yellow", label: "Yellow" },
  { value: "red", label: "Red" },
  { value: "blue", label: "Blue" },
  { value: "green", label: "Green" },
];

const PaperChatMarkdown = memo(function PaperChatMarkdown({ text, onOpenCodePath }: { text: string; onOpenCodePath: (target: CodePathLocation) => void }) {
  return <div className="message-markdown paper-ai-code-markdown"><ReactMarkdown
    remarkPlugins={[remarkGfm, remarkMath, remarkCodePaths]}
    rehypePlugins={[rehypeKatex]}
    components={{
      table: ({ children, ...props }) => <div className="paper-ai-table-scroll" tabIndex={0} role="region" aria-label="Scrollable table"><table {...props}>{children}</table></div>,
      code: (({ className, children }: { className?: string; children?: React.ReactNode }) => {
        const value = String(children ?? "").replace(/\n$/, "");
        const target = !className && !value.includes("\n") ? parseCodePath(value) : null;
        if (!target) return <code className={className}>{children}</code>;
        return <button
          type="button"
          className="paper-code-path"
          title={`Open ${target.path}${target.startLine > 1 ? `:${target.startLine}${target.endLine > target.startLine ? `-${target.endLine}` : ""}` : ""} in Codebase`}
          onClick={() => onOpenCodePath(target)}
        >{value}</button>;
      }) as never,
    }}
  >{normalizePaperMathDelimiters(text)}</ReactMarkdown></div>;
});

const PaperChatMessageRow = memo(function PaperChatMessageRow({ message, streaming = false, onOpenCodePath }: { message: PaperChatMessage; streaming?: boolean; onOpenCodePath: (target: CodePathLocation) => void }) {
  const { t } = useUISettings();
  const assistant = message.role === "assistant";
  return <article className={`conversation-message paper-ai-message ${message.role}${streaming ? " streaming" : ""}`}>
    <div className="conversation-message-copy">
      {assistant && <div className="conversation-message-role">{t("Archimedes")}</div>}
      {assistant ? <PaperChatMarkdown text={message.text || "…"} onOpenCodePath={onOpenCodePath} /> : <p>{message.text}</p>}
      {streaming && <i className="paper-ai-stream-cursor" aria-label={t("Generating response")} />}
    </div>
  </article>;
});

const PaperChatThread = memo(function PaperChatThread({ messages, busy, aiMode, streamingText, onAsk, onOpenCodePath }: {
  messages: PaperChatMessage[]; busy: boolean; aiMode: PaperAiMode; streamingText: string | null; onAsk: (prompt: string) => void; onOpenCodePath: (target: CodePathLocation) => void;
}) {
  const { language, t } = useUISettings();
  const [historyStart, setHistoryStart] = useState(() => Math.max(0, messages.length - PAPER_CHAT_INITIAL_VISIBLE_MESSAGE_COUNT));
  const historyInitializedRef = useRef(messages.length > 0);
  const threadRef = useRef<HTMLDivElement>(null);
  const followLatestRef = useRef(true);
  const visibleMessages = messages.slice(historyStart);
  const hiddenMessageCount = historyStart;
  const hasAssistantMessage = useMemo(() => messages.some((message) => message.role === "assistant"), [messages]);
  useEffect(() => {
    if (!messages.length) {
      historyInitializedRef.current = false;
      setHistoryStart(0);
      return;
    }
    if (!historyInitializedRef.current) {
      historyInitializedRef.current = true;
      setHistoryStart(Math.max(0, messages.length - PAPER_CHAT_INITIAL_VISIBLE_MESSAGE_COUNT));
      return;
    }
    setHistoryStart((current) => Math.min(current, Math.max(0, messages.length - PAPER_CHAT_INITIAL_VISIBLE_MESSAGE_COUNT)));
  }, [messages.length]);
  useEffect(() => {
    const thread = threadRef.current;
    if (!thread || !followLatestRef.current) return;
    thread.scrollTop = thread.scrollHeight;
  }, [busy, messages.length, streamingText]);
  const prompt = (audit: string, brief: string) => () => onAsk(aiMode === "audit" ? audit : brief);
  const zh = language === "zh";

  return <div className="paper-ai-conversation" ref={threadRef} onScroll={(event) => {
    const node = event.currentTarget;
    followLatestRef.current = node.scrollHeight - node.scrollTop - node.clientHeight < 72;
  }}>
    {messages.length ? <>
      {hiddenMessageCount > 0 && <button className="conversation-load-history paper-ai-load-history" onClick={() => setHistoryStart((current) => Math.max(0, current - PAPER_CHAT_HISTORY_PAGE_SIZE))}>Show {Math.min(PAPER_CHAT_HISTORY_PAGE_SIZE, hiddenMessageCount)} earlier messages</button>}
      {visibleMessages.map((message, index) => <PaperChatMessageRow key={`${message.role}-${index + historyStart}`} message={message} onOpenCodePath={onOpenCodePath} />)}
    </> : streamingText === null && <div className="paper-ai-empty"><strong>{aiMode === "audit" ? "Ready for a strict code audit" : t("Ask about this paper")}</strong><p>{aiMode === "audit" ? "Ask about a method, configuration, or selected code. Archimedes will trace it to paper and repository evidence." : "Archimedes answers with page-level evidence from the full paper."}</p></div>}
    {streamingText !== null && <PaperChatMessageRow message={{ role: "assistant", text: streamingText }} streaming onOpenCodePath={onOpenCodePath} />}
    {busy && <div className="paper-ai-working"><LoaderCircle className="spin" size={14} />{messages.length ? "Archimedes is reading…" : aiMode === "audit" ? "Tracing paper and code evidence…" : "Reading PDF pages and building the guide…"}</div>}
    {hasAssistantMessage && !busy && <div className="paper-ai-suggestions">
      <button onClick={prompt(zh ? "请核验论文的核心方法在代码中由哪些文件和函数实现，并建立证据链。" : "Verify which files and functions implement the paper's core method, and build an evidence chain.", zh ? "这篇论文最核心的贡献是什么？请结合全文说明。" : "What is the paper's core contribution? Explain it using the full text.")}>{aiMode === "audit" ? t("Verify method") : t("Core contribution")}</button>
      <button onClick={prompt(zh ? "请检查训练与评估配置是否支持论文中的实验主张。" : "Check whether the training and evaluation setup supports the paper's experimental claims.", zh ? "请细讲方法部分：输入、关键机制、训练或推理流程分别是什么？" : "Explain the method in detail: inputs, key mechanisms, and training or inference flow.")}>{aiMode === "audit" ? t("Verify experiments") : t("Explain method")}</button>
      <button onClick={prompt(zh ? "请列出论文中的哪些关键主张在代码中无法确认或尚未实现。" : "List the key claims that cannot be confirmed in the code or are not implemented.", zh ? "实验设置、数据集、基线、指标和主要结果分别是什么？" : "What are the experimental setup, datasets, baselines, metrics, and main results?")}>{aiMode === "audit" ? t("Gap analysis") : t("View experiments")}</button>
      <button onClick={prompt(zh ? "请给出最短的复现实验路径：入口、配置、数据和评估步骤。" : "Give the shortest reproduction path: entry point, configuration, data, and evaluation steps.", zh ? "论文有哪些局限、威胁或尚未验证的主张？" : "What limitations, threats, or unverified claims does the paper have?")}>{aiMode === "audit" ? t("Reproduction path") : t("Analyze limitations")}</button>
    </div>}
  </div>;
});

const PaperChatComposer = memo(function PaperChatComposer({ busy, cancelling, canInterrupt, attachments, droppedAttachments, command, onAsk, onInterrupt, onRemoveAttachment, onRemoveDropped, onDropFiles, initialDraft = "", onDraftChange }: {
  busy: boolean; cancelling: boolean; canInterrupt: boolean; attachments: CodeChatAttachment[]; droppedAttachments: ContextAttachment[]; command: PaperChatComposerCommand;
  onAsk: (prompt: string) => boolean; onInterrupt: () => void; onRemoveAttachment: (index: number) => void;
  onRemoveDropped: (id: string) => void; onDropFiles: (files: File[], repositoryPath: string) => void;
  initialDraft?: string; onDraftChange?: (draft: string) => void;
}) {
  const { t } = useUISettings();
  const [draft, setDraft] = useState(initialDraft);
  useEffect(() => { onDraftChange?.(draft); }, [draft, onDraftChange]);
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const resizeFrameRef = useRef<number | null>(null);
  const resize = useCallback(() => {
    // Modern Chromium sizes the composer in CSS without forcing layout on
    // every keystroke. Keep the old measurement only for older runtimes.
    if (typeof CSS !== "undefined" && CSS.supports("field-sizing", "content")) return;
    if (resizeFrameRef.current !== null) return;
    resizeFrameRef.current = requestAnimationFrame(() => {
      resizeFrameRef.current = null;
      const textarea = textareaRef.current;
      if (!textarea) return;
      textarea.style.height = "0px";
      textarea.style.height = `${Math.min(textarea.scrollHeight, 132)}px`;
      textarea.style.overflowY = textarea.scrollHeight > 132 ? "auto" : "hidden";
    });
  }, []);
  useEffect(() => () => { if (resizeFrameRef.current !== null) cancelAnimationFrame(resizeFrameRef.current); }, []);
  useEffect(() => { resize(); }, [draft, resize]);
  useEffect(() => {
    if (!command.id) return;
    if (command.draft !== undefined) setDraft(command.draft);
    requestAnimationFrame(() => textareaRef.current?.focus());
  }, [command]);
  function submit() {
    if (!draft.trim() || busy) return;
    if (onAsk(draft)) setDraft("");
  }
  return <div className="paper-ai-composer-wrap" onDragOver={(event) => { if (event.dataTransfer.types.includes("Files") || event.dataTransfer.types.includes("application/x-archimedes-repository-path")) { event.preventDefault(); event.dataTransfer.dropEffect = "copy"; } }} onDrop={(event) => { const files = Array.from(event.dataTransfer.files); const repositoryPath = event.dataTransfer.getData("application/x-archimedes-repository-path"); if (!files.length && !repositoryPath) return; event.preventDefault(); event.stopPropagation(); onDropFiles(files, repositoryPath); }}>
    <div className="conversation-composer paper-ai-composer">
      {(attachments.length > 0 || droppedAttachments.length > 0) && <div className="paper-ai-code-attachments">
        {attachments.map((attachment, index) => <div className="paper-ai-code-attachment" key={attachment.path + ":" + attachment.startLine + ":" + index} title={attachment.path + ":" + attachment.startLine + "-" + attachment.endLine}>
          <FileCode2 size={13} /><span>{attachment.path}:{attachment.startLine}{attachment.endLine !== attachment.startLine ? "-" + attachment.endLine : ""}</span><button type="button" onClick={() => onRemoveAttachment(index)} title={t("Remove code attachment")} aria-label={t("Remove {path} code attachment", { path: attachment.path })}><X size={12} /></button>
        </div>)}
        {droppedAttachments.map((item) => <div className="paper-ai-code-attachment" key={item.id} title={item.path}>{item.type === "folder" ? <Folder size={13} /> : <FileCode2 size={13} />}<span>{item.name}</span><button type="button" onClick={() => onRemoveDropped(item.id)} title={t("Remove attachment")} aria-label={`${t("Remove attachment")}: ${item.name}`}><X size={12} /></button></div>)}
      </div>}
      <textarea ref={textareaRef} value={draft} onChange={(event) => setDraft(event.target.value)} onKeyDown={(event) => { if (shouldSubmitPaperChatKey(event)) { event.preventDefault(); submit(); } }} placeholder={attachments.length ? t("Ask about the selected code…") : t("Ask about the paper…")} rows={2} />
      <div className="conversation-composer-footer paper-ai-composer-footer">
        <span className="paper-ai-composer-context"><FileText size={12} />{t("Full paper")}</span>
        <button className="conversation-send paper-ai-send" disabled={busy ? !canInterrupt || cancelling : !draft.trim()} onClick={busy ? onInterrupt : submit} title={busy ? (cancelling ? t("Stopping") : t("Stop")) : t("Send")} aria-label={busy ? (cancelling ? t("Stopping") : t("Stop")) : t("Send")}>{busy ? <Square size={13} fill="currentColor" /> : <ArrowUp size={16} strokeWidth={2.4} />}</button>
      </div>
    </div>
  </div>;
});

function PaperReadingWorkbench({ paper, library, onBack, onUpdate, bridge, workspace, projectId, workspaceId, onInternalReviewThreadsDeleted, onReproduceOpened, session, onSessionSave, onActivityChange, noteDrafts, openRequest }: {
  paper: ReaderLibraryPaper; library: ResearchLibrary; onBack: () => void;
  session?: PaperReaderSession; onSessionSave: (session: PaperReaderSession) => void; onActivityChange: (busy: boolean) => void; noteDrafts: LibraryNoteDrafts;
  openRequest?: { paperId: string; token: string; review?: boolean };
  onUpdate: (patch: Parameters<ResearchDeskBridge["updateLibraryPaper"]>[1]) => Promise<void>;
  bridge: ResearchDeskBridge; workspace: string; projectId?: string | null; workspaceId?: string | null; onInternalReviewThreadsDeleted?: (threadIds: string[]) => void; onReproduceOpened?: (reproductionId: string) => void;
}) {
  const { language, t } = useUISettings();
  const [reader, setReader] = useState<PaperReaderState | null>(null);
  const [busy, setBusy] = useState<"remote" | "local" | null>(null);
  const [reproducing, setReproducing] = useState(false);
  const reproductionAlive = useRef(true);
  useEffect(() => { reproductionAlive.current = true; return () => { reproductionAlive.current = false; }; }, []);
  const [error, setError] = useState("");

  async function startReproduction() {
    setReproducing(true);
    setError("");
    try {
      const created = await bridge.createReproduction({
        projectId: projectId || library.project_id || undefined,
        workspaceId: workspaceId || undefined,
        paperId: paper.id,
        repoUrl: projectUrl || paper.url || "",
        title: paper.title,
      });
      if (reproductionAlive.current) onReproduceOpened?.(created.id);
    } catch (reproductionError) {
      setError(reproductionError instanceof Error ? reproductionError.message : "Could not start a reproduction.");
    } finally {
      setReproducing(false);
    }
  }
  const [pageNumber, setPageNumber] = useState(session?.pageNumber || 1);
  const [pdfZoom, setPdfZoom] = useState(session?.pdfZoom || 1);
  const [query, setQuery] = useState("");
  const [passages, setPassages] = useState<PaperPassage[]>([]);
  const [activeSearchQuery, setActiveSearchQuery] = useState("");
  const searchRequestRef = useRef(0);
  const selectionHistoryRef = useRef<{ key: string; at: number; count: number } | null>(null);
  const [selection, setSelection] = useState("");
  const [selectionAnchor, setSelectionAnchor] = useState<SelectionAnchor | null>(null);
  const [figureCapture, setFigureCapture] = useState<PaperFigureCapture | null>(null);
  const [translationPopover, setTranslationPopover] = useState<TranslationPopover | null>(null);
  const [translating, setTranslating] = useState(false);
  const [highlightPickerOpen, setHighlightPickerOpen] = useState(false);
  const highlightTriggerRef = useRef<HTMLButtonElement>(null);
  const [commentOpen, setCommentOpen] = useState(false);
  const [comment, setComment] = useState("");
  const [highlightListOpen, setHighlightListOpen] = useState(false);
  const [chatOpen, setChatOpen] = useState(session?.chatOpen ?? false);
  const [sideTab, setSideTab] = useState<"chat" | "notes">(session?.sideTab || "chat");
  const [chatWidth, setChatWidth] = useState(readPaperChatWidth);
  const chatResizeRef = useRef<{ startX: number; startWidth: number } | null>(null);
  const [detectedProjectUrl, setDetectedProjectUrl] = useState("");
  const [readerView, setReaderView] = useState<"paper" | "canvas" | "review" | "project" | "codebase">(session?.readerView === "canvas" || session?.readerView === "review" ? session.readerView : "paper");
  const [reviewVisited, setReviewVisited] = useState(session?.readerView === "review");
  useEffect(() => {
    if (openRequest?.paperId !== paper.id) return;
    setReaderView(openRequest.review ? "review" : "paper");
    if (openRequest.review) { setReviewVisited(true); setChatOpen(false); }
  }, [openRequest?.token]);
  const [returnToReading, setReturnToReading] = useState(false);
  const [canvasInsert, setCanvasInsert] = useState<PaperCanvasInsert | null>(null);
  const [canvasFocusHighlight, setCanvasFocusHighlight] = useState<PaperHighlight | null>(null);
  const [readerChromeOpen, setReaderChromeOpen] = useState(session?.readerChromeOpen ?? true);
  const [codebaseVisited, setCodebaseVisited] = useState(false);
  const [codeNavigationTarget, setCodeNavigationTarget] = useState<CodeNavigationTarget | null>(null);
  const [repository, setRepository] = useState<PaperRepositorySnapshot | null>(null);
  const [checkout, setCheckout] = useState<RepositoryCheckout | null>(null);
  const [checkoutLoading, setCheckoutLoading] = useState(false);
  const [checkoutError, setCheckoutError] = useState("");
  const [aiMode, setAiMode] = useState<PaperAiMode>("brief");
  const [codeAttachments, setCodeAttachments] = useState<CodeChatAttachment[]>([]);
  const [droppedAttachments, setDroppedAttachments] = useState<ContextAttachment[]>([]);
  const [composerCommand, setComposerCommand] = useState<PaperChatComposerCommand>({ id: 0 });
  const [chatBusy, setChatBusy] = useState(false);
  const [chatCancelling, setChatCancelling] = useState(false);
  const [chatThreadId, setChatThreadId] = useState<string | undefined>();
  const [chatMessages, setChatMessages] = useState<PaperChatMessage[]>([]);
  const [streamingChatText, setStreamingChatText] = useState<string | null>(null);
  // Token deltas arrive far faster than the markdown tree can re-render. Buffer
  // them and flush on a short interval so one answer costs ~10 parses instead of
  // one per token.
  const streamBufferRef = useRef("");
  const streamFlushRef = useRef<number | null>(null);
  const flushStream = useCallback(() => {
    streamFlushRef.current = null;
    setStreamingChatText(streamBufferRef.current);
  }, []);
  const stopStreamTimer = useCallback(() => {
    if (streamFlushRef.current !== null) {
      window.clearTimeout(streamFlushRef.current);
      streamFlushRef.current = null;
    }
  }, []);
  const [chatHistoryLoaded, setChatHistoryLoaded] = useState(false);
  const [briefingVersion, setBriefingVersion] = useState(0);
  const briefingStartedRef = useRef(false);
  const activePaperRunIdRef = useRef<string | null>(null);
  const ready = reader?.asset?.status === "ready" && reader.pages.length > 0 && Boolean(reader.asset.preview_url);
  const currentPage = reader?.pages.find((page) => page.page_number === pageNumber) ?? reader?.pages[0] ?? null;
  const lastPage = reader?.asset?.page_count ?? reader?.pages.at(-1)?.page_number ?? 1;
  const projectUrl = paper.github_url || detectedProjectUrl;
  const sessionSnapshot = useRef({ pageNumber, pdfZoom, readerView, chatOpen, readerChromeOpen, sideTab });
  const sessionSaveRef = useRef(onSessionSave);
  const composerDraftRef = useRef(session?.composerDraft || "");
  const rememberComposerDraft = useCallback((draft: string) => { composerDraftRef.current = draft; }, []);
  sessionSnapshot.current = { pageNumber, pdfZoom, readerView, chatOpen, readerChromeOpen, sideTab };
  sessionSaveRef.current = onSessionSave;
  useEffect(() => () => sessionSaveRef.current({ ...sessionSnapshot.current, composerDraft: composerDraftRef.current }), []);
  useEffect(() => { onActivityChange(chatBusy || Boolean(busy) || reproducing); }, [busy, chatBusy, onActivityChange, reproducing]);
  useEffect(() => () => onActivityChange(false), [onActivityChange]);


  useEffect(() => {
    window.localStorage.setItem("archimedes-paper-chat-width", String(chatWidth));
  }, [chatWidth]);
  useEffect(() => () => document.body.classList.remove("paper-chat-resizing"), []);

  const loadReader = useCallback(async () => {
    try {
      const next = await bridge.getLibraryPaperReader(paper.id, workspace, projectId);
      setReader(next);
      if (next.pages[0]) setPageNumber((current) => Math.min(Math.max(1, current), next.pages.at(-1)?.page_number ?? 1));
    } catch (loadError) { setError(readableError(loadError, "Could not load the paper reader.")); }
  }, [bridge, paper.id, projectId, workspace]);
  useEffect(() => { void loadReader(); }, [loadReader]);
  useEffect(() => {
    let active = true;
    briefingStartedRef.current = false;
    setChatHistoryLoaded(false);
    setChatThreadId(undefined);
    setChatMessages([]);
    setStreamingChatText(null);
    activePaperRunIdRef.current = null;
    void bridge.getLibraryPaperChatThread(paper.id, workspace, projectId).then((thread) => {
      if (!active) return;
      if (thread) {
        const messages = thread.messages
          .filter((message) => !isHiddenPaperBriefingInstruction(message))
          .map((message) => ({ role: message.role, text: message.text }));
        setChatThreadId(thread.id);
        setChatMessages(messages);
        briefingStartedRef.current = messages.some((message) => message.role === "assistant");
      }
    }).catch((loadError) => {
      if (active) setError(readableError(loadError, "Could not restore the paper conversation."));
    }).finally(() => {
      if (active) setChatHistoryLoaded(true);
    });
    return () => { active = false; };
  }, [bridge, paper.id, workspace]);

  useEffect(() => bridge.onAgentEvent((event) => {
    if (event.type !== "assistant_delta" || !event.delta || event.clientRunId !== activePaperRunIdRef.current) return;
    streamBufferRef.current += event.delta;
    if (streamFlushRef.current !== null) return;
    streamFlushRef.current = window.setTimeout(flushStream, 100);
  }), [bridge, flushStream]);
  useEffect(() => stopStreamTimer, [stopStreamTimer]);

  const selectedHighlight = reader?.highlights.find((highlight) => highlight.page_number === pageNumber &&
    (highlight.quote === selection || highlight.quote.includes(selection) || selection.includes(highlight.quote))) ?? null;

  function clearSelection() { setSelection(""); setSelectionAnchor(null); setHighlightPickerOpen(false); setCommentOpen(false); setComment(""); }
  function closeSelection() { clearSelection(); setTranslationPopover(null); }
  function openCanvasSource(source: PaperCanvasSource) {
    setReaderView("paper");
    setChatOpen(false);
    setPageNumber(Math.max(1, source.page));
    if (source.quote) {
      const focus: PaperHighlight = {
        id: `canvas-focus-${Date.now()}`,
        paper_id: paper.id,
        page_number: source.page,
        quote: source.quote,
        start_offset: null,
        end_offset: null,
        note: "Source from Canvas",
        color: "yellow",
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString(),
      };
      setCanvasFocusHighlight(focus);
      window.setTimeout(() => setCanvasFocusHighlight((current) => current?.id === focus.id ? null : current), 5_000);
    } else {
      setCanvasFocusHighlight(null);
    }
  }
  function addSelectionToCanvas() {
    if (!selection) return;
    setCanvasInsert({ nonce: Date.now(), type: "quote", page: pageNumber, quote: selection, highlightId: selectedHighlight?.id });
    setReaderView("canvas");
    setChatOpen(false);
    clearSelection();
  }
  function addHighlightToCanvas(highlight: PaperHighlight) {
    setCanvasInsert({ nonce: Date.now(), type: "quote", page: highlight.page_number, quote: highlight.quote, highlightId: highlight.id, caption: highlight.note || undefined });
    setReaderView("canvas");
    setChatOpen(false);
    setHighlightListOpen(false);
  }
  function addFigureToCanvas() {
    if (!figureCapture?.image.image) return;
    setCanvasInsert({ nonce: Date.now(), type: "figure", page: figureCapture.pageNumber, image: figureCapture.image.image, caption: figureCapture.nearbyText || undefined });
    setFigureCapture(null);
    setReaderView("canvas");
    setChatOpen(false);
  }
  function receiveFigureCapture(capture: PaperFigureCapture) {
    setFigureCapture(capture);
    setSideTab("chat");
    setChatOpen(true);
    const objectName = capture.kind === "table" ? t("Table") : capture.kind === "equation" ? t("Equation") : t("Image");
    setComposerCommand((current) => ({ id: current.id + 1, draft: language === "zh" ? `请解释论文第 ${capture.pageNumber} 页所选${objectName}` : `Explain the selected ${objectName.toLowerCase()} from page ${capture.pageNumber} of the paper.` }));
  }
  function receiveSelection(text: string, anchor: SelectionAnchor) {
    const next = text.replace(/\s+/g, " ").trim();
    if (!next) return;
    setSelection(next.slice(0, 5000));
    setSelectionAnchor(anchor);
    setTranslationPopover(null);
    setHighlightPickerOpen(false);
    setCommentOpen(false);

    // L0 signal: the same passage selected deliberately more than once. A
    // rapid mousemove can fire the selection callback repeatedly, so ignore
    // duplicates inside 1.5s instead of counting them as a new decision.
    const now = Date.now();
    const key = `${paper.id}:${pageNumber}:${next.slice(0, 180)}`;
    const previous = selectionHistoryRef.current;
    const count = previous?.key === key && now - previous.at < 90_000 && now - previous.at > 1_500
      ? previous.count + 1
      : previous?.key === key && now - previous.at <= 1_500
        ? previous.count
        : 1;
    selectionHistoryRef.current = { key, at: now, count };
    if (count >= 2) {
      emitProactiveSignal({
        source: "selection",
        title: `Revisit this passage from “${paper.title}”`,
        whyNow: `You selected the same passage ${count} times in the last 90 seconds.`,
        evidence: [{
          kind: "selection",
          paperId: paper.id,
          paperTitle: paper.title,
          page: pageNumber,
          text: next.slice(0, 700),
          libraryName: library.name,
        }],
        action: {
          kind: "insert",
          label: "Explain passage",
          text: `Explain this passage from “${paper.title}” (p. ${pageNumber}) in context, and note its limitations:\n\n“${next.slice(0, 1200)}”`,
        },
        confidence: 0.65,
        fingerprint: fingerprintFor("selection", key),
      });
    }
  }
  async function prepare(kind: "remote" | "local") {
    setBusy(kind); setError("");
    try {
      const next = kind === "remote"
        ? await bridge.prepareLibraryPaperReader(paper.id, workspace, projectId)
        : await bridge.attachLibraryPaperPdf(paper.id, workspace, projectId);
      setReader(next);
      setPageNumber(next.pages[0]?.page_number ?? 1);
    } catch (prepareError) { setError(readableError(prepareError, "Could not prepare the original PDF.")); }
    finally { setBusy(null); }
  }
  async function find() {
    if (!query.trim() || !reader) return;
    const searchRequest = ++searchRequestRef.current;
    setError("");
    try {
      const next = await bridge.findLibraryPaperPassages(paper.id, query.trim(), workspace);
      // Searches can finish out of order when someone edits the phrase and
      // presses Enter again. An old empty response must not overwrite a newer
      // successful search with the misleading "no match" banner.
      if (searchRequest !== searchRequestRef.current) return;
      setPassages(next);
      if (next[0]) {
        setPageNumber(next[0].page_number);
        setActiveSearchQuery(query.trim());
        setError("");
      } else {
        setActiveSearchQuery("");
        setError(`No match found in the ${reader.pages.length} indexed PDF pages for “${query.trim()}”.`);
        const normalizedQuery = query.trim();
        emitProactiveSignal({
          source: "search",
          title: `No match for “${normalizedQuery}”`,
          whyNow: `You searched ${reader.pages.length} indexed pages in “${paper.title}” and got 0 hits.`,
          evidence: [{
            kind: "search",
            query: normalizedQuery,
            resultCount: 0,
            paperId: paper.id,
            paperTitle: paper.title,
            libraryName: library.name,
          }],
          action: {
            kind: "insert",
            label: "Suggest the right term",
            text: `I searched “${normalizedQuery}” in “${paper.title}” and got 0 results. Suggest the term the authors likely use, and show the closest passages in this paper.`,
          },
          confidence: 0.8,
          fingerprint: fingerprintFor("search", `${paper.id}:${normalizedQuery.toLowerCase()}`),
        });
      }
    } catch (findError) {
      if (searchRequest === searchRequestRef.current) setError(readableError(findError, "Could not search this paper."));
    }
  }
  async function saveHighlight(note = "", color: PaperHighlightInput["color"] = "yellow") {
    if (!currentPage || !selection) return;
    const start = currentPage.text.indexOf(selection);
    try {
      const item = await bridge.createLibraryPaperHighlight(paper.id, {
        page_number: currentPage.page_number, quote: selection, note, color,
        start_offset: start >= 0 ? start : undefined,
        end_offset: start >= 0 ? start + selection.length : undefined,
      }, workspace, projectId);
      setReader((current) => current ? { ...current, highlights: [...current.highlights, item] } : current);
      if (note.trim()) setHighlightListOpen(true);
      closeSelection();
    } catch (highlightError) { setError(readableError(highlightError, "Could not save this highlight.")); }
  }
  async function deleteHighlight(id: string) {
    try {
      await bridge.deleteLibraryPaperHighlight(id, workspace, projectId);
      setReader((current) => current ? { ...current, highlights: current.highlights.filter((highlight) => highlight.id !== id) } : current);
      closeSelection();
    } catch (deleteError) { setError(readableError(deleteError, "Could not remove this highlight.")); }
  }
  async function deleteSelectedHighlight() {
    if (selectedHighlight) await deleteHighlight(selectedHighlight.id);
  }
  const paperContext: ContextAttachment[] = [{ id: `paper:${paper.id}`, type: "paper", name: paper.title, detail: `${paper.year ?? "n.d."} · ${paper.venue || "Paper"}`, paper: { title: paper.title, authors: paper.authors, year: paper.year, abstract: paper.abstract, url: paper.url, pdfUrl: paper.pdf_url } }];
  const repositoryForContext: PaperRepositorySnapshot | null = repository || (checkout ? {
    url: checkout.url, owner: checkout.owner, repo: checkout.repo, branch: checkout.branch, description: "", homepage: "", language: "", stars: 0, license: "", updated_at: "", retrieved_at: "", tree: [], data_paths: [], readme: "", files: [], audit: true,
  } : null);
  const researchContext: ContextAttachment[] = repositoryForContext
    ? [...paperContext, { id: `repository:${repositoryForContext.url}`, type: "repository", name: `${repositoryForContext.owner}/${repositoryForContext.repo}`, detail: checkout ? `Git checkout · ${checkout.file_count} files · ${checkout.commit.slice(0, 8)}` : `GitHub · ${repositoryForContext.files.length} evidence files · ${repositoryForContext.data_paths.length} data or benchmark paths`, repository: checkout ? { ...repositoryForContext, audit: true } : repositoryForContext }]
    : paperContext;
  const ensureRepositorySnapshot = useCallback((url: string) => {
    if (!isGithubRepositoryLink(url) || repository?.url === url || typeof bridge.loadLibraryGithubRepository !== "function") return;
    void bridge.loadLibraryGithubRepository(url).then(setRepository).catch(() => {
      // A project may still be opened in the embedded browser if GitHub's API is unavailable.
    });
  }, [bridge, repository?.url]);
  const openProject = useCallback((url: string) => {
    setDetectedProjectUrl(url);
    setReaderView("project");
    ensureRepositorySnapshot(url);
  }, [ensureRepositorySnapshot]);
  const openCodebase = useCallback((url: string) => {
    setDetectedProjectUrl(url);
    setCodebaseVisited(true);
    setReaderView("codebase");
    ensureRepositorySnapshot(url);
  }, [ensureRepositorySnapshot]);
  const openCodePath = useCallback((target: CodePathLocation) => {
    if (!projectUrl || !isGithubRepositoryLink(projectUrl)) return;
    openCodebase(projectUrl);
    setCodeNavigationTarget({ ...target, nonce: Date.now() });
  }, [openCodebase, projectUrl]);
  useEffect(() => {
    if (!projectUrl || !isGithubRepositoryLink(projectUrl) || !workspace) { setCheckout(null); return; }
    let active = true;
    void bridge.getLibraryGithubRepositoryCheckout(projectUrl, workspace).then((next) => {
      if (active) setCheckout(next);
    }).catch(() => {
      if (active) setCheckout(null);
    });
    return () => { active = false; };
  }, [bridge, projectUrl, workspace]);
  const cloneForAudit = useCallback(async () => {
    if (!projectUrl || !workspace || checkoutLoading) return;
    setCheckoutLoading(true);
    setCheckoutError("");
    try {
      const next = await bridge.cloneLibraryGithubRepository(projectUrl, workspace);
      setCheckout(next);
      setAiMode("audit");
      setChatOpen(true);
      ensureRepositorySnapshot(projectUrl);
    } catch (cloneError) { setCheckoutError(readableError(cloneError, "Could not clone this repository for code audit.")); }
    finally { setCheckoutLoading(false); }
  }, [bridge, checkoutLoading, ensureRepositorySnapshot, projectUrl, workspace]);
  async function askAI(question: string, options: { initialBriefing?: boolean } = {}) {
    const userPrompt = question.trim();
    if (!userPrompt || chatBusy) return;
    setSideTab("chat");
    if (!workspace) { setError("Choose a workspace before starting a paper conversation."); return; }
    const quotedPassage = options.initialBriefing || !selection ? "" : `\n\nSelected passage from page ${pageNumber}:\n> ${selection}`;
    const attachedCode = options.initialBriefing ? "" : codeAttachments.map((attachment) =>
      "\n\nSelected code from " + attachment.path + ":" + attachment.startLine + "-" + attachment.endLine +
      ":\n```\n" + attachment.snippet + "\n```"
    ).join("");
    const attachedFigure = options.initialBriefing ? null : figureCapture;
    const figureEvidence = attachedFigure
      ? `\n\nA ${attachedFigure.kind} from PDF page ${attachedFigure.pageNumber} is attached as an image. Inspect the actual pixels before answering. Nearby extracted PDF text follows; it may include a caption or surrounding prose, but do not treat it as a substitute for the image:\n${attachedFigure.nearbyText || "No nearby text was recovered."}`
      : "";
    const prompt = userPrompt + attachedCode + figureEvidence;
    const repositoryInstruction = repositoryForContext
      ? checkout && aiMode === "audit"
        ? ` A full local Git checkout is attached for a strict code audit at commit ${checkout.commit.slice(0, 12)}. Before making an implementation claim, search the checkout, then read the exact source file. Build an explicit evidence chain with Paper: p. N and Code: path:L-N. Separate confirmed implementation, paper-only claim, and inference. Do not infer implementation details from a README or file name.`
        : ` A public GitHub snapshot is attached alongside the paper. Inspect its README, selected source/configuration files, and listed data or benchmark paths when relevant. Clearly distinguish paper claims from repository evidence and from your inference; a listed data path does not prove the data itself was read.`
      : "";
    const instruction = options.initialBriefing
      ? `You are preparing a durable research reading guide for the paper \"${paper.title}\" (${lastPage} PDF pages available). ${prompt}${repositoryInstruction}`
      : aiMode === "audit" && checkout
        ? `You are conducting a strict paper-to-code audit for \"${paper.title}\". ${prompt}${quotedPassage}\n\nRead relevant PDF pages and the cloned repository before answering. Report an evidence chain in this order when applicable: paper claim and page, code path and line range, then conclusion. Mark each conclusion as confirmed, contradicted, incomplete, or not implemented. Do not fill gaps with speculation.${repositoryInstruction}`
        : `You are helping a researcher read the paper \"${paper.title}\". ${prompt}${quotedPassage}\n\nUse the existing full-paper briefing as continuity, but read attached PDF pages again when the answer depends on details absent from it. Ground your answer in the selected passage and the attached paper. State when the passage alone is insufficient, and cite page numbers when available.${repositoryInstruction}`;
    setChatOpen(true);
    if (!options.initialBriefing) {
      setCodeAttachments([]);
      setDroppedAttachments([]);
      setFigureCapture(null);
      setChatMessages((current) => [...current, { role: "user", text: userPrompt }]);
    }
    setChatBusy(true);
    setChatCancelling(false);
    stopStreamTimer();
    streamBufferRef.current = "";
    const clientRunId = `paper-chat:${crypto.randomUUID()}`;
    activePaperRunIdRef.current = clientRunId;
    setStreamingChatText("");
    try {
      const result = await bridge.runAgent({
        prompt: instruction,
        workspace,
        threadId: chatThreadId,
        projectId: projectId || undefined,
        mode: options.initialBriefing || aiMode === "audit" ? "deep-research" : "free-chat",
        contextItems: [...researchContext, ...(options.initialBriefing ? [] : droppedAttachments), ...(attachedFigure ? [attachedFigure.image] : [])],
        // Paper chat produces chat output only. It has no approval surface, so
        // asking for workspace writes can only strand the turn on a prompt
        // nobody can answer.
        capabilities: { write: "deny", command: "deny" },
        // Paper chats live under their paper, not in the workspace sidebar.
        origin: "paper",
        title: paper.title,
        clientRunId,
      });
      setChatThreadId(result.threadId);
      setChatMessages((current) => [...current, { role: "assistant", text: result.response }]);
      try { await bridge.setLibraryPaperChatThread(paper.id, result.threadId, workspace, projectId); }
      catch (saveError) { setError(readableError(saveError, "The paper conversation completed but could not be saved.")); }
    } catch (askError) {
      setChatMessages((current) => [...current, { role: "assistant", text: `I could not answer that yet: ${readableError(askError, "Agent request failed.")}` }]);
    } finally {
      if (activePaperRunIdRef.current === clientRunId) {
        activePaperRunIdRef.current = null;
        stopStreamTimer();
        streamBufferRef.current = "";
        setStreamingChatText(null);
      }
      setChatBusy(false);
      setChatCancelling(false);
    }
  }
  const askAIRef = useRef(askAI);
  askAIRef.current = askAI;
  const askPaperSuggestion = useCallback((prompt: string) => { void askAIRef.current(prompt); }, []);
  useEffect(() => {
    if (aiMode !== "brief" || sideTab !== "chat" || !chatOpen || !ready || !chatHistoryLoaded || chatBusy || briefingStartedRef.current) return;
    briefingStartedRef.current = true;
    void askAI(paperBriefingRequest(language), { initialBriefing: true });
  }, [briefingVersion, chatBusy, chatHistoryLoaded, chatOpen, language, ready, sideTab]);
  async function translateSelection() {
    if (!selection || !selectionAnchor || translating) return;
    const source = selection;
    const anchor = selectionAnchor;
    setTranslating(true);
    setError("");
    setTranslationPopover({ source, translation: "", anchor });
    setSelection("");
    setSelectionAnchor(null);
    setHighlightPickerOpen(false);
    setCommentOpen(false);
    try {
      const result = await bridge.translateLibraryPaperSelection(source);
      setTranslationPopover((current) => current?.source === source ? { ...current, translation: result.translation } : current);
    } catch (translateError) {
      const message = readableError(translateError, "Could not translate the selected passage.");
      setTranslationPopover((current) => current?.source === source ? { ...current, error: message } : current);
    } finally { setTranslating(false); }
  }
  function commandComposer(draft?: string) {
    setComposerCommand((current) => ({ id: current.id + 1, ...(draft === undefined ? {} : { draft }) }));
  }
  function openAskForSelection() { setChatOpen(true); commandComposer(language === "zh" ? `请解释论文第 ${pageNumber} 页所选这段话的含义、上下文和可能的局限。` : `Explain the meaning, context, and possible limitations of the passage selected on page ${pageNumber}.`); }
  const addCodeSelectionToChat = useCallback((file: RepositoryCheckoutFile, snippet: string, startLine: number) => {
    const cleanSnippet = snippet.slice(0, 12_000);
    if (!cleanSnippet.trim()) return;
    setAiMode("audit");
    setChatOpen(true);
    setCodeAttachments((current) => [...current, {
      path: file.path,
      startLine,
      endLine: startLine + (cleanSnippet.match(/\n/g)?.length ?? 0) - (cleanSnippet.endsWith("\n") ? 1 : 0),
      snippet: cleanSnippet,
    }]);
    commandComposer();
  }, []);
  function submitPaperChat(draft: string) {
    if (chatBusy || !workspace || !draft.trim()) return false;
    void askAI(draft);
    return true;
  }
  async function attachPaperChatDrop(files: File[], repositoryPath: string) {
    try {
      const items = files.length ? await bridge.attachDroppedFiles(files) : repositoryPath && projectUrl ? [await bridge.attachRepositoryPath(projectUrl, workspace, repositoryPath)] : [];
      setDroppedAttachments((current) => {
        const combined = [...current, ...items.filter((item) => !current.some((existing) => existing.id === item.id))];
        return combined.slice(0, 9);
      });
      if (items.length + droppedAttachments.length > 9) setError("A paper chat can attach up to 9 files or folders at once.");
      else setError("");
    } catch (dropError) { setError(readableError(dropError, "Could not attach the dropped files or folders.")); }
  }
  async function interruptPaperChat() {
    if (!chatThreadId || chatCancelling) return;
    setChatCancelling(true);
    try {
      const result = await bridge.interruptAgent(chatThreadId);
      if (!result.interrupted) {
        setChatCancelling(false);
        setError("This paper conversation no longer has an active task to stop.");
      }
    } catch (interruptError) {
      setChatCancelling(false);
      setError(readableError(interruptError, "Could not stop the paper conversation."));
    }
  }
  function restartBriefing() {
    if (chatBusy) return;
    briefingStartedRef.current = false;
    setChatThreadId(undefined);
    setChatMessages([]);
    setBriefingVersion((current) => current + 1);
  }
  function beginChatResize(event: ReactPointerEvent<HTMLDivElement>) {
    if (event.button !== 0) return;
    event.preventDefault();
    // On narrow windows the panel may be visually clamped below its saved
    // width. Start from its actual width so dragging responds immediately.
    const panel = event.currentTarget.nextElementSibling;
    const startWidth = panel instanceof HTMLElement ? panel.getBoundingClientRect().width : chatWidth;
    chatResizeRef.current = { startX: event.clientX, startWidth };
    event.currentTarget.setPointerCapture(event.pointerId);
    document.body.classList.add("paper-chat-resizing");
  }
  function moveChatResize(event: ReactPointerEvent<HTMLDivElement>) {
    const drag = chatResizeRef.current;
    if (!drag) return;
    // The handle sits to the left of the panel, so moving it left grows the chat.
    setChatWidth(clampPaperChatWidth(drag.startWidth + drag.startX - event.clientX));
  }
  function endChatResize(event: ReactPointerEvent<HTMLDivElement>) {
    if (!chatResizeRef.current) return;
    chatResizeRef.current = null;
    if (event.currentTarget.hasPointerCapture(event.pointerId)) event.currentTarget.releasePointerCapture(event.pointerId);
    document.body.classList.remove("paper-chat-resizing");
  }
  function handleChatResizeKey(event: ReactKeyboardEvent<HTMLDivElement>) {
    const step = event.key === "ArrowLeft" ? 16 : event.key === "ArrowRight" ? -16 : 0;
    if (step) {
      event.preventDefault();
      setChatWidth((width) => clampPaperChatWidth(width + step));
      return;
    }
    if (event.key === "Home") {
      event.preventDefault();
      setChatWidth(PAPER_CHAT_MIN_WIDTH);
    } else if (event.key === "End") {
      event.preventDefault();
      setChatWidth(PAPER_CHAT_MAX_WIDTH);
    }
  }

  return <section
    className={`${chatOpen ? "paper-workbench-page paper-chat-open" : "paper-workbench-page"}${readerChromeOpen ? " chrome-open" : ""}`}
    data-surface="reader"
  >
    <button type="button" className="paper-reader-chrome-toggle" onClick={() => setReaderChromeOpen((open) => !open)} aria-expanded={readerChromeOpen} aria-controls="paper-reader-bar" aria-label={t(readerChromeOpen ? "Hide reader controls" : "Show reader controls")} title={t(readerChromeOpen ? "Hide reader controls" : "Show reader controls")}>
      {readerChromeOpen ? <ChevronUp size={16} /> : <ChevronDown size={16} />}
    </button>
    <header id="paper-reader-bar" className="paper-reader-bar" title={`${library.name} · ${paper.title}`} inert={!readerChromeOpen}>
      <button className="reader-back-button" onClick={onBack} title={`${t("Library")} · ${library.name}`} aria-label={t("Library")}><ChevronLeft size={15} /></button>
      <div className="paper-reader-tabs">
        <Tabs value={readerView} onChange={(value) => { setReaderView(value as "paper" | "canvas" | "review"); if (value === "review") setReviewVisited(true); if (value !== "paper") setReturnToReading(false); if (value === "review" || value === "canvas") setChatOpen(false); }} label={t("Paper reader views")} className="paper-reader-tablist">
          <Tab value="paper" icon={<FileText size={14} />}>{t("Original paper")}</Tab>
          <Tab value="canvas" icon={<Frame size={14} />}>{t("Canvas")}</Tab>
          <Tab value="review" icon={<BookOpen size={14} />}>{t("Interactive paper")}</Tab>
        </Tabs>
        {projectUrl && <button className="paper-reader-action" title={t("Open this paper's linked project")} onClick={() => openProject(projectUrl)}><Code2 size={14} />Project</button>}
        {projectUrl && isGithubRepositoryLink(projectUrl) && <button className="paper-reader-action" title={t("Open the local code audit workspace")} onClick={() => openCodebase(projectUrl)}><FileCode2 size={14} />Codebase</button>}
        <button className="paper-reader-action reproduce-tab" title={t("Reproduce this paper in the background")} disabled={reproducing} onClick={() => void startReproduction()}>{reproducing ? <LoaderCircle className="spin" size={14} /> : <FlaskConical size={14} />}{t("Reproduce")}</button>
      </div>
      <div className="reader-header-actions">
        {publicPaperRecordUrl(paper) && <a className="reader-icon-button" href={publicPaperRecordUrl(paper)} target="_blank" rel="noreferrer" title={t("Open source")}><ExternalLink size={15} /></a>}
        <button className="reader-icon-button" title={paper.starred ? t("Unstar paper") : t("Star paper")} onClick={() => void onUpdate({ starred: !paper.starred })}><Star size={15} fill={paper.starred ? "currentColor" : "none"} /></button>
        {readerView !== "review" && readerView !== "canvas" && <button className={chatOpen ? "reader-ask-button active" : "reader-ask-button"} title={t("Ask Archimedes")} onClick={() => setChatOpen((value) => !value)}>{chatOpen ? <PanelRightClose size={15} /> : <PanelRightOpen size={15} />}<span>{t("Ask AI")}</span></button>}
      </div>
    </header>
    <div className="paper-reader-layout" style={chatOpen ? { "--paper-chat-width": `${chatWidth}px` } as React.CSSProperties : undefined}>
      {reviewVisited && <div className="paper-review-retained" hidden={readerView !== "review"} aria-hidden={readerView !== "review"} inert={readerView !== "review"}>
        <PaperReviewWorkbench bridge={bridge} workspace={workspace} projectId={projectId} paper={paper} pageCount={lastPage} ready={ready} pdfUrl={reader?.asset?.preview_url || ""} onOpenSource={(page) => { setPageNumber(page); setReturnToReading(true); setReaderView("paper"); }} onInternalReviewThreadsDeleted={onInternalReviewThreadsDeleted} />
      </div>}
      {readerView === "paper" && returnToReading && <button type="button" className="paper-return-reading" onClick={() => { setReturnToReading(false); setReaderView("review"); }}><ArrowLeft size={15} />{t("Back to reading")}</button>}
      {readerView !== "review" && readerView !== "codebase" && readerView !== "canvas" && <main className={readerView === "project" ? "project-browser-reader" : "original-paper-reader"}>
        {readerView === "project" && projectUrl ? <LinkedProjectView url={projectUrl} /> : <>
        {ready ? <>
          <div className="paper-reader-toolbar" inert={!readerChromeOpen}>
            <div className="paper-reader-navigation">
              <div className="paper-page-controls"><button onClick={() => setPageNumber((value) => Math.max(1, value - 1))} disabled={pageNumber <= 1} title={t("Previous page")}><ChevronLeft size={17} /></button><strong>{pageNumber} / {lastPage}</strong><button onClick={() => setPageNumber((value) => Math.min(lastPage, value + 1))} disabled={pageNumber >= lastPage} title={t("Next page")}><ChevronRight size={17} /></button></div>
              <div className="paper-zoom-control" aria-label={t("PDF zoom")}>
                <button onClick={() => setPdfZoom((value) => Math.max(.55, Math.round((value - .1) * 100) / 100))} disabled={pdfZoom <= .55} title={t("Zoom out 10%")}><Minus size={16} /></button>
                <button className="paper-zoom-readout" onClick={() => setPdfZoom(1)} title={t("Reset zoom to 100%")}><span>{Math.round(pdfZoom * 100)}%</span><ChevronDown size={14} /></button>
                <button onClick={() => setPdfZoom((value) => Math.min(3.2, Math.round((value + .1) * 100) / 100))} disabled={pdfZoom >= 3.2} title={t("Zoom in 10%")}><Plus size={16} /></button>
              </div>
            </div>
            <div className="paper-search-control"><Search size={15} /><input value={query} onChange={(event) => { searchRequestRef.current += 1; setQuery(event.target.value); setActiveSearchQuery(""); setPassages([]); setError(""); }} onKeyDown={(event) => event.key === "Enter" && void find()} placeholder={t("Find in paper")} />{query && <button className="paper-search-clear" onClick={() => { searchRequestRef.current += 1; setQuery(""); setActiveSearchQuery(""); setPassages([]); setError(""); }} title={t("Clear paper search")} aria-label={t("Clear paper search")}><X size={13} /></button>}<button onClick={() => void find()} disabled={!query.trim()}>{t("Find")}</button></div>
            <div className="paper-reader-evidence-actions"><button className={highlightListOpen ? "paper-reader-evidence active" : "paper-reader-evidence"} onClick={() => setHighlightListOpen((value) => !value)} aria-expanded={highlightListOpen} title={t("Highlights & notes")}><Highlighter size={14} />{reader?.highlights.length ?? 0}</button></div>
          </div>
          {highlightListOpen && <aside className="paper-highlight-list" aria-label={t("Highlights & notes")}>
            <header><div><StickyNote size={15} /><strong>{t("Highlights & notes")}</strong></div><button onClick={() => setHighlightListOpen(false)} title={t("Close")}><X size={14} /></button></header>
            <div>{reader?.highlights.length ? reader.highlights.map((highlight) => <article key={highlight.id}>
              <button className="paper-highlight-entry" onClick={() => { setPageNumber(highlight.page_number); setHighlightListOpen(false); }}><span><i className={`paper-highlight-dot ${highlight.color}`} />{t("Page {page}", { page: highlight.page_number })}</span><p>{highlight.quote}</p>{highlight.note && <small>{highlight.note}</small>}</button>
              <button className="paper-highlight-canvas" onClick={() => addHighlightToCanvas(highlight)} title={t("Add to canvas")} aria-label={t("Add to canvas")}><Frame size={13} /></button>
              <button className="paper-highlight-delete" onClick={() => void deleteHighlight(highlight.id)} title={t("Delete this highlight or note")}><Trash size={13} /></button>
            </article>) : <p className="paper-highlight-empty">{t("No highlights or notes yet.")}</p>}</div>
          </aside>}
          {passages.length > 0 && <div className="paper-search-results">{passages.slice(0, 5).map((passage) => <button key={`${passage.page_number}-${passage.start_offset}`} onClick={() => setPageNumber(passage.page_number)}><b>p. {passage.page_number}</b>{passage.excerpt}</button>)}</div>}
          <PdfPaperCanvas url={reader?.asset?.preview_url || ""} pageNumber={pageNumber} highlights={canvasFocusHighlight ? [...(reader?.highlights ?? []), canvasFocusHighlight] : (reader?.highlights ?? [])} searchQuery={activeSearchQuery} zoom={pdfZoom} activeSelection={selection} figureCaptureActive={Boolean(figureCapture)} onZoomChange={setPdfZoom} onSelection={receiveSelection} onFigureCapture={receiveFigureCapture} onClearSelection={clearSelection} onProjectLink={openProject} onProjectDetected={setDetectedProjectUrl} />
        </> : <div className="paper-reader-empty">
          <span className="paper-reader-empty-icon"><FileText size={24} /></span><h2>{t("Open the original paper")}</h2><p>{paper.pdf_url ? t("The public PDF can be cached locally and opened in the reader.") : t("Attach a local PDF to open the original paper here.")}</p>
          <div><button className="primary-button" disabled={Boolean(busy) || !paper.pdf_url} onClick={() => void prepare("remote")}>{busy === "remote" ? <LoaderCircle className="spin" size={14} /> : <RefreshCw size={14} />}{busy === "remote" ? t("Preparing…") : t("Prepare PDF")}</button><button className="secondary-button" disabled={Boolean(busy)} onClick={() => void prepare("local")}>{busy === "local" ? <LoaderCircle className="spin" size={14} /> : <Plus size={14} />}{t("Attach PDF")}</button></div>
        </div>}
        {(error || reader?.asset?.error) && <InlineNotice tone="danger" className="reader-runtime-error">{error || reader?.asset?.error}</InlineNotice>}
        </>}
      </main>}
      {codebaseVisited && projectUrl && isGithubRepositoryLink(projectUrl) && <main key={projectUrl} className={readerView === "codebase" ? "codebase-reader" : "codebase-reader codebase-reader-inactive"} aria-hidden={readerView !== "codebase"}>
        <RepositoryCodebaseView bridge={bridge} url={projectUrl} workspace={workspace} checkout={checkout} loading={checkoutLoading} error={checkoutError} onClone={cloneForAudit} onAddToChat={addCodeSelectionToChat} navigationTarget={codeNavigationTarget} />
      </main>}
      <main key={`canvas-${paper.id}`} className={readerView === "canvas" ? "paper-canvas-reader" : "paper-canvas-reader paper-canvas-reader-inactive"} aria-hidden={readerView !== "canvas"}>
        <PaperCanvas
          bridge={bridge}
          workspace={workspace}
          projectId={projectId}
          paperId={paper.id}
          paperTitle={paper.title}
          currentPage={pageNumber}
          active={readerView === "canvas"}
          insertRequest={canvasInsert}
          onInsertHandled={(nonce) => setCanvasInsert((current) => current?.nonce === nonce ? null : current)}
          onOpenSource={openCanvasSource}
        />
      </main>
      {chatOpen && readerView !== "canvas" && <><div className="paper-chat-resizer" role="separator" aria-orientation="vertical" aria-label="Resize paper chat panel" aria-valuemin={PAPER_CHAT_MIN_WIDTH} aria-valuemax={PAPER_CHAT_MAX_WIDTH} aria-valuenow={chatWidth} tabIndex={0} onPointerDown={beginChatResize} onPointerMove={moveChatResize} onPointerUp={endChatResize} onPointerCancel={endChatResize} onDoubleClick={() => setChatWidth(PAPER_CHAT_DEFAULT_WIDTH)} onKeyDown={handleChatResizeKey} />
      <aside className={`paper-ai-panel${sideTab === "notes" ? " library-side-notes" : ""}`}>
        <div className="library-assistant-tabs"><Tabs value={sideTab} onChange={(value) => setSideTab(value as typeof sideTab)} label={t("Reading assistant")}><Tab value="chat" icon={<MessageCircleReply size={14} />}>{t("Paper chat")}</Tab><Tab value="notes" icon={<StickyNote size={14} />}>{t("Notes")}</Tab></Tabs><button className="reader-icon-button" onClick={() => setChatOpen(false)} title={t("Close AI panel")} aria-label={t("Close AI panel")}><X size={16} /></button></div>
        {sideTab === "notes" ? <LibraryPaperNotes key={paper.id} paper={paper} drafts={noteDrafts} compact onSave={(notes) => onUpdate({ notes })} /> : <>
        <header className="paper-ai-header">
          <Tabs value={aiMode} onChange={(value) => { if (value === "audit" && !checkout) { if (projectUrl) openCodebase(projectUrl); return; } setAiMode(value as typeof aiMode); }} label={t("Paper chat mode")} variant="segmented" className="paper-ai-mode-toggle"><Tab value="brief">{t("Briefing")}</Tab><Tab value="audit" title={checkout ? t("Use the cloned repository for strict verification") : t("Open Codebase and clone the repository first")}>{t("Code audit")}</Tab></Tabs>
          <div className="paper-ai-header-actions"><button className="reader-icon-button" onClick={restartBriefing} disabled={chatBusy || aiMode !== "brief"} title={t("Read the full paper again")}><RefreshCw size={15} /></button><button className="reader-icon-button" onClick={() => setChatOpen(false)} title={t("Close AI panel")}><X size={16} /></button></div>
        </header>
        <PaperChatThread messages={chatMessages} busy={chatBusy} aiMode={aiMode} streamingText={streamingChatText} onAsk={askPaperSuggestion} onOpenCodePath={openCodePath} />
        {(selection || figureCapture) && <div className="paper-ai-context-stack">
          {selection && <div className="paper-ai-context"><span>{t("p. {page} selection", { page: pageNumber })}</span><p>{selection}</p><button onClick={closeSelection}><X size={12} /></button></div>}
          {figureCapture && <div className="paper-ai-figure-context"><img src={figureCapture.image.image?.dataUrl} alt={`Selected ${figureCapture.kind} from page ${figureCapture.pageNumber}`} /><div><span>{t("Page {page} {kind}", { page: figureCapture.pageNumber, kind: figureCapture.kind === "table" ? t("Table") : figureCapture.kind === "equation" ? t("Equation") : t("Image") })}</span><p>{t("This region will be sent to AI as a high-resolution image.")}</p><button className="paper-ai-figure-canvas" onClick={addFigureToCanvas} title={t("Send to canvas")}><Frame size={12} /><span>{t("Send to canvas")}</span></button></div><button onClick={() => setFigureCapture(null)} title={t("Remove figure attachment")}><X size={13} /></button></div>}
        </div>}
        <PaperChatComposer initialDraft={composerDraftRef.current} onDraftChange={rememberComposerDraft} busy={chatBusy} cancelling={chatCancelling} canInterrupt={Boolean(chatThreadId)} attachments={codeAttachments} droppedAttachments={droppedAttachments} command={composerCommand} onAsk={submitPaperChat} onInterrupt={() => void interruptPaperChat()} onRemoveAttachment={(index) => setCodeAttachments((current) => current.filter((_, attachmentIndex) => attachmentIndex !== index))} onRemoveDropped={(id) => setDroppedAttachments((current) => current.filter((item) => item.id !== id))} onDropFiles={(files, repositoryPath) => void attachPaperChatDrop(files, repositoryPath)} />
      </>}
      </aside></>}
    </div>
    {selection && selectionAnchor && <div className="paper-selection-menu" style={{ left: Math.min(window.innerWidth - 430, Math.max(12, selectionAnchor.x - 170)), top: Math.max(12, selectionAnchor.y - 58) }} onMouseDown={(event) => event.preventDefault()}>
      <button ref={highlightTriggerRef} aria-haspopup="menu" aria-expanded={highlightPickerOpen} onClick={() => setHighlightPickerOpen((value) => !value)}><Highlighter size={15} />{t("Highlight")}</button><button onClick={translateSelection}><Languages size={15} />{t("Translate")}</button><button onClick={() => setCommentOpen(true)}><MessageCircleReply size={15} />{t("Comment")}</button><button onClick={openAskForSelection}><Bot size={15} />{t("Ask AI")}</button>{selectedHighlight && <button className="remove-highlight-action" onClick={() => void deleteSelectedHighlight()}><Trash size={14} />{t("Delete highlight")}</button>}<button className="add-to-canvas-action" onClick={addSelectionToCanvas}><Frame size={15} />{t("Add to canvas")}</button>
      <MenuSurface open={highlightPickerOpen} onClose={() => setHighlightPickerOpen(false)} anchorRef={highlightTriggerRef} placement="bottom-start" width={220} className="paper-highlight-picker" ariaLabel={t("Highlight color")}>
        {HIGHLIGHT_COLORS.map((color) => <MenuItem key={color.value} checked={selectedHighlight?.color === color.value} icon={<span className="highlight-dot" style={{ background: PDF_HIGHLIGHT_COLORS[color.value ?? "yellow"] ?? "transparent" }} />} onClick={() => { setHighlightPickerOpen(false); void saveHighlight("", color.value); }}>{t(color.label)}</MenuItem>)}
      </MenuSurface>
      {commentOpen && <form className="paper-comment-composer" onSubmit={(event) => { event.preventDefault(); void saveHighlight(comment, "blue"); }}><textarea autoFocus value={comment} onChange={(event) => setComment(event.target.value)} placeholder={t("Write a comment…")} rows={3} /><div><button type="button" onClick={closeSelection}>{t("Cancel")}</button><button type="submit" disabled={!comment.trim()}>{t("Save")}</button></div></form>}
    </div>}
    {translationPopover && <aside className="paper-translation-popover" style={{ left: Math.min(window.innerWidth - 404, Math.max(12, translationPopover.anchor.x - 150)), top: Math.min(window.innerHeight - 278, Math.max(12, translationPopover.anchor.y + 18)) }} onMouseDown={(event) => event.preventDefault()}>
      <header><span><Languages size={14} />{t("Translation")}</span><button onClick={() => setTranslationPopover(null)} title={t("Close translation")}><X size={14} /></button></header>
      <p className="paper-translation-source">{translationPopover.source}</p>
      <div className={translationPopover.error ? "paper-translation-result error" : "paper-translation-result"}>{translating ? <><LoaderCircle className="spin" size={14} />{t("Translating…")}</> : translationPopover.error || translationPopover.translation}</div>
    </aside>}
  </section>;
}

function LinkedProjectView({ url }: { url: string }) {
  const hostRef = useRef<HTMLDivElement>(null);
  const [state, setState] = useState<"loading" | "ready" | "error">("loading");
  const [error, setError] = useState("");
  const [reloadKey, setReloadKey] = useState(0);

  useEffect(() => {
    const host = hostRef.current;
    if (!host) return;
    setState("loading");
    setError("");

    const view = document.createElement("webview");
    view.setAttribute("src", url);
    view.setAttribute("partition", "linked-project");
    view.setAttribute("webpreferences", "contextIsolation=yes, sandbox=yes, nodeIntegration=no");
    view.setAttribute("aria-label", linkedProjectLabel(url));
    const loadTimeout = window.setTimeout(() => {
      setState("error");
      setError("The project page did not finish loading. Check your connection, then retry.");
    }, 15_000);
    const loaded = () => {
      window.clearTimeout(loadTimeout);
      setState("ready");
    };
    const failed = (event: Event) => {
      window.clearTimeout(loadTimeout);
      const detail = event as Event & { errorCode?: number; errorDescription?: string; detail?: { errorCode?: number; errorDescription?: string } };
      const code = Number(detail.errorCode ?? detail.detail?.errorCode);
      if (code === -3) return;
      setState("error");
      setError(detail.errorDescription ?? detail.detail?.errorDescription ?? "This project page could not be loaded in the paper workspace.");
    };
    view.addEventListener("did-finish-load", loaded);
    view.addEventListener("did-fail-load", failed);
    host.replaceChildren(view);

    return () => {
      window.clearTimeout(loadTimeout);
      view.removeEventListener("did-finish-load", loaded);
      view.removeEventListener("did-fail-load", failed);
      view.remove();
    };
  }, [url, reloadKey]);

  return <div className="github-project-workspace">
    <div className="github-project-toolbar"><span><Code2 size={15} />{linkedProjectLabel(url)}</span><span>{linkedProjectHost(url)}</span></div>
    <div className="github-project-frame" ref={hostRef} />
    {state === "loading" && <div className="github-project-status"><LoaderCircle className="spin" size={17} />Loading project...</div>}
    {state === "error" && <div className="github-project-status error"><strong>Project unavailable</strong><span>{error}</span><button className="secondary-button" onClick={() => setReloadKey((current) => current + 1)}>Retry</button></div>}
  </div>;
}

const RepositoryCodebaseView = memo(function RepositoryCodebaseView({ bridge, url, workspace, checkout, loading, error, onClone, onAddToChat, navigationTarget }: {
  bridge: ResearchDeskBridge;
  url: string;
  workspace: string;
  checkout: RepositoryCheckout | null;
  loading: boolean;
  error: string;
  onClone: () => void;
  onAddToChat: (file: RepositoryCheckoutFile, snippet: string, startLine: number) => void;
  navigationTarget: CodeNavigationTarget | null;
}) {
  const [tree, setTree] = useState<Record<string, RepositoryCheckoutEntry[]>>({});
  const [expanded, setExpanded] = useState<Set<string>>(new Set([""]));
  const [activeFile, setActiveFile] = useState<RepositoryCheckoutFile | null>(null);
  const [browserError, setBrowserError] = useState("");
  const [referenceChoices, setReferenceChoices] = useState<{ target: CodePathLocation; paths: string[] } | null>(null);
  const navigationRequestRef = useRef(0);
  const [fileLoading, setFileLoading] = useState(false);
  const [snippet, setSnippet] = useState("");
  const [snippetLine, setSnippetLine] = useState(1);
  const [activeRange, setActiveRange] = useState<{ start: number; end: number } | null>(null);
  const editorRef = useRef<HTMLElement>(null);

  const loadDirectory = useCallback(async (directory = "") => {
    if (!checkout) return;
    try {
      const listing = await bridge.listLibraryGithubRepositoryCheckout(url, workspace, directory);
      setTree((current) => ({ ...current, [directory]: listing.entries }));
      setBrowserError("");
    } catch (loadError) { setBrowserError(readableError(loadError, "Could not list this checkout directory.")); }
  }, [bridge, checkout, url, workspace]);

  useEffect(() => {
    navigationRequestRef.current += 1;
    setTree({});
    setExpanded(new Set([""]));
    setActiveFile(null);
    setSnippet("");
    setActiveRange(null);
    setReferenceChoices(null);
    setFileLoading(false);
    setBrowserError("");
    if (checkout) void loadDirectory("");
  }, [checkout?.commit, loadDirectory]);

  async function toggleDirectory(directory: string) {
    const next = new Set(expanded);
    if (next.has(directory)) next.delete(directory);
    else {
      next.add(directory);
      if (!tree[directory]) await loadDirectory(directory);
    }
    setExpanded(next);
  }
  async function openFile(entry: RepositoryCheckoutEntry) {
    const request = ++navigationRequestRef.current;
    setReferenceChoices(null);
    setFileLoading(true);
    setSnippet("");
    setActiveRange(null);
    try {
      const file = await bridge.readLibraryGithubRepositoryCheckoutFile(url, workspace, entry.path);
      if (request !== navigationRequestRef.current) return;
      setActiveFile(file);
      setBrowserError("");
    } catch (loadError) { if (request === navigationRequestRef.current) setBrowserError(readableError(loadError, "Could not open this repository file.")); }
    finally { if (request === navigationRequestRef.current) setFileLoading(false); }
  }
  async function openFilePath(target: CodePathLocation) {
    const request = ++navigationRequestRef.current;
    setFileLoading(true);
    setSnippet("");
    setBrowserError("");
    setReferenceChoices(null);
    try {
      const resolution = await bridge.resolveLibraryGithubRepositoryReference(url, workspace, target.path);
      if (request !== navigationRequestRef.current) return;
      if (resolution.status === "missing") {
        setBrowserError(`No file matches “${target.path}” in this checkout. The reference may be incomplete or from a different revision.`);
        return;
      }
      if (resolution.status === "ambiguous") {
        setReferenceChoices({ target, paths: resolution.paths });
        return;
      }
      const resolvedPath = resolution.paths[0];
      const directoryParts = resolvedPath.split("/").slice(0, -1);
      const directories = directoryParts.map((_, index) => directoryParts.slice(0, index + 1).join("/"));
      if (directories.length) {
        const listings = await Promise.all(directories.map(async (directory) => {
          const listing = await bridge.listLibraryGithubRepositoryCheckout(url, workspace, directory);
          return [directory, listing.entries] as const;
        }));
        if (request !== navigationRequestRef.current) return;
        setTree((current) => ({ ...current, ...Object.fromEntries(listings) }));
        setExpanded((current) => new Set([...current, "", ...directories]));
      }
      const file = await bridge.readLibraryGithubRepositoryCheckoutFile(url, workspace, resolvedPath);
      if (request !== navigationRequestRef.current) return;
      setActiveFile(file);
      if (target.startLine > file.line_count || target.endLine > file.line_count) {
        setActiveRange(target.startLine <= file.line_count ? { start: target.startLine, end: file.line_count } : null);
        setBrowserError(`Opened “${resolvedPath}”, but the cited lines ${target.startLine}–${target.endLine} exceed this file's ${file.line_count} lines. Check the repository revision.`);
      } else setActiveRange({ start: target.startLine, end: target.endLine });
    } catch (loadError) {
      if (request === navigationRequestRef.current) setBrowserError(readableError(loadError, `Could not open ${target.path} at line ${target.startLine}.`));
    } finally {
      if (request === navigationRequestRef.current) setFileLoading(false);
    }
  }
  function captureSelection(event: ReactMouseEvent<HTMLElement>) {
    if (!activeFile) return;
    const selection = window.getSelection();
    if (!selection?.rangeCount) return;
    const range = selection.getRangeAt(0);
    if (!event.currentTarget.contains(range.startContainer) || !event.currentTarget.contains(range.endContainer)) return;
    const text = selection.toString();
    if (!text.trim()) { setSnippet(""); return; }
    const startElement = range.startContainer.nodeType === Node.ELEMENT_NODE
      ? range.startContainer as Element
      : range.startContainer.parentElement;
    const line = startElement?.closest<HTMLElement>("[data-code-line]")?.dataset.codeLine;
    const before = range.cloneRange();
    before.selectNodeContents(event.currentTarget);
    before.setEnd(range.startContainer, range.startOffset);
    setSnippet(text.slice(0, 12_000));
    setSnippetLine(line ? Number(line) : before.toString().split("\n").length);
  }
  function renderEntries(directory = "", depth = 0) {
    return (tree[directory] || []).flatMap((entry) => {
      if (entry.type === "directory") {
        const open = expanded.has(entry.path);
        return [<div key={entry.path}><button draggable onDragStart={(event) => { event.dataTransfer.setData("application/x-archimedes-repository-path", entry.path); event.dataTransfer.effectAllowed = "copy"; }} className={open ? "codebase-tree-node open" : "codebase-tree-node"} style={{ paddingLeft: 12 + depth * 14 }} onClick={() => void toggleDirectory(entry.path)}>{open ? <FolderOpen size={14} /> : <Folder size={14} />}<span>{entry.name}</span></button>{open ? renderEntries(entry.path, depth + 1) : []}</div>];
      }
      return [<button draggable onDragStart={(event) => { event.dataTransfer.setData("application/x-archimedes-repository-path", entry.path); event.dataTransfer.effectAllowed = "copy"; }} className={activeFile?.path === entry.path ? "codebase-tree-node active" : "codebase-tree-node"} key={entry.path} style={{ paddingLeft: 12 + depth * 14 }} onClick={() => void openFile(entry)}><FileCode2 size={13} /><span>{entry.name}</span></button>];
    });
  }

  useEffect(() => {
    if (!checkout || !navigationTarget) return;
    void openFilePath(navigationTarget);
  }, [checkout?.commit, navigationTarget?.nonce]);

  useEffect(() => {
    if (!activeFile || !activeRange) return;
    const frame = requestAnimationFrame(() => {
      const line = editorRef.current?.querySelector<HTMLElement>(`[data-code-line="${activeRange.start}"]`);
      line?.scrollIntoView({ block: "center" });
    });
    return () => cancelAnimationFrame(frame);
  }, [activeFile?.path, activeRange, fileLoading]);

  if (!checkout) return <div className="codebase-empty"><span className="paper-reader-empty-icon"><Shield size={24} /></span><h2>Start a strict code audit</h2><p>Clone this public repository locally to inspect the full file tree, select code, and verify paper claims against the implementation. The checkout is read-only here and no repository code is executed.</p>{error && <div className="reader-runtime-error">{error}</div>}<button className="primary-button" disabled={loading || !workspace} onClick={onClone}>{loading ? <LoaderCircle className="spin" size={15} /> : <GitBranch size={15} />}{loading ? "Cloning repository…" : "Clone for code audit"}</button>{!workspace && <small>Choose a workspace before cloning a repository.</small>}</div>;

  return <div className="codebase-workspace">
    <header className="codebase-toolbar"><span><GitBranch size={14} />{checkout.owner}/{checkout.repo}</span><span>{checkout.branch} · {checkout.commit.slice(0, 8)} · {checkout.file_count.toLocaleString()} files</span></header>
    <div className="codebase-layout">
      <aside className="codebase-explorer"><header><span>Explorer</span><button className="reader-icon-button" title="Reload file tree" onClick={() => void loadDirectory("")}><RefreshCw size={13} /></button></header><div className="codebase-tree">{renderEntries()}</div></aside>
      <section className="codebase-editor" ref={editorRef}>
        {activeFile ? <>
          <header><span><FileCode2 size={14} />{activeFile.path}</span><small>{activeFile.line_count.toLocaleString()} lines</small></header>
          {activeFile.content.length <= 300_000 ? <SyntaxHighlighter
            className="codebase-source"
            language={codebaseLanguage(activeFile.path)}
            useInlineStyles={false}
            showLineNumbers
            wrapLines
            wrapLongLines={false}
            lineProps={(lineNumber: number) => ({
              className: `syntax-line${activeRange && lineNumber >= activeRange.start && lineNumber <= activeRange.end ? " code-target-line" : ""}`,
              "data-code-line": lineNumber,
            })}
            lineNumberStyle={{ minWidth: "38px", paddingRight: "12px", textAlign: "right", userSelect: "none" }}
            customStyle={{ minWidth: 0, minHeight: 0, margin: 0, padding: "15px 18px 56px 0", border: 0, fontSize: "11px", lineHeight: 1.65, overflow: "auto" }}
            codeTagProps={{ style: { fontFamily: "var(--font-mono)" } }}
            onMouseUp={captureSelection}
          >{activeFile.content || " "}</SyntaxHighlighter> : <pre onMouseUp={captureSelection}><code>{(() => {
            if (!activeRange) return activeFile.content;
            const lines = activeFile.content.split("\n");
            const before = lines.slice(0, activeRange.start - 1).join("\n");
            const selected = lines.slice(activeRange.start - 1, activeRange.end).join("\n");
            const after = lines.slice(activeRange.end).join("\n");
            return <>{before}{before && "\n"}<span className="code-target-line" data-code-line={activeRange.start}>{selected}</span>{after && "\n"}{after}</>;
          })()}</code></pre>}
          {snippet ? <div className="codebase-selection"><span>{activeFile.path} line {snippetLine}</span><button className="secondary-button" onMouseDown={(event) => event.preventDefault()} onClick={() => { onAddToChat(activeFile, snippet, snippetLine); setSnippet(""); window.getSelection()?.removeAllRanges(); }}><MessageCircleReply size={13} />Add to chat</button><button className="reader-icon-button" onClick={() => setSnippet("")} title="Discard code selection"><X size={13} /></button></div> : null}
        </> : <div className="codebase-editor-empty">{fileLoading ? <><LoaderCircle className="spin" size={18} />Opening file…</> : <><FileCode2 size={24} /><strong>Select a source file</strong><span>Choose a file in the explorer, then select code to add it to the evidence conversation.</span></>}</div>}
      </section>
    </div>
    {referenceChoices && <div className="codebase-reference-choices" role="group" aria-label="Choose a matching repository file"><strong>Multiple files match “{referenceChoices.target.path}”. Choose one:</strong>{referenceChoices.paths.map((candidate) => <button key={candidate} onClick={() => void openFilePath({ ...referenceChoices.target, path: candidate })}>{candidate}</button>)}<button onClick={() => setReferenceChoices(null)}>Cancel</button></div>}
    {browserError && <InlineNotice tone="danger" className="reader-runtime-error">{browserError}</InlineNotice>}
  </div>;
});

type PdfVisualRect = { left: number; top: number; width: number; height: number };
type PdfTextLine = PdfVisualRect & { text: string };
type PdfInteractiveRegion = { rect: PdfVisualRect; nearbyText: string; kind: PaperVisualKind; source: "caption" | "equation" | "image" };

function clampPdfCoordinate(value: number, minimum: number, maximum: number) {
  return Math.min(maximum, Math.max(minimum, value));
}

function pdfTextFragments(page: HTMLElement, textLayer: HTMLElement): PdfTextLine[] {
  const pageBounds = page.getBoundingClientRect();
  return Array.from(textLayer.querySelectorAll<HTMLElement>("span")).flatMap((span) => {
    const text = span.textContent?.replace(/\s+/g, " ").trim() || "";
    const bounds = span.getBoundingClientRect();
    if (!text || !bounds.width || !bounds.height) return [];
    return [{ text, left: bounds.left - pageBounds.left, top: bounds.top - pageBounds.top, width: bounds.width, height: bounds.height }];
  }).sort((first, second) => first.top - second.top || first.left - second.left);
}

function pdfTextLines(page: HTMLElement, textLayer: HTMLElement): PdfTextLine[] {
  const spans = pdfTextFragments(page, textLayer);
  const lines: Array<PdfTextLine & { bottom: number }> = [];
  for (const span of spans) {
    const center = span.top + span.height / 2;
    let line: (PdfTextLine & { bottom: number }) | undefined;
    for (let index = lines.length - 1; index >= 0; index -= 1) {
      const candidate = lines[index];
      const gap = Math.max(0, span.left - (candidate.left + candidate.width), candidate.left - (span.left + span.width));
      // Matching only by Y merges the left and right columns into one line. Keep
      // nearby formula fragments together, but never bridge a column gutter.
      if (Math.abs(candidate.top + candidate.height / 2 - center) <= Math.max(4, span.height * .45) && gap <= Math.max(28, span.height * 4.5)) {
        line = candidate;
        break;
      }
    }
    if (!line) {
      lines.push({ ...span, bottom: span.top + span.height });
      continue;
    }
    const right = Math.max(line.left + line.width, span.left + span.width);
    line.left = Math.min(line.left, span.left);
    line.top = Math.min(line.top, span.top);
    line.bottom = Math.max(line.bottom, span.top + span.height);
    line.width = right - line.left;
    line.height = line.bottom - line.top;
    line.text = `${line.text} ${span.text}`.replace(/\s+/g, " ").trim();
  }
  return lines.map(({ bottom: _bottom, ...line }) => line);
}

function distanceToPdfRect(x: number, y: number, rect: PdfVisualRect) {
  const dx = x < rect.left ? rect.left - x : x > rect.left + rect.width ? x - rect.left - rect.width : 0;
  const dy = y < rect.top ? rect.top - y : y > rect.top + rect.height ? y - rect.top - rect.height : 0;
  return Math.hypot(dx, dy);
}

function pdfCaptionFragments(fragments: PdfTextLine[]) {
  const labelOnlyPattern = /^(?:figure|fig\.?|table|图|表)$/i;
  const numberPattern = /^(?:\d+[a-z]?\b|[一二三四五六七八九十]+)/i;
  const joined: PdfTextLine[] = [];
  for (const label of fragments) {
    if (!labelOnlyPattern.test(label.text)) continue;
    const labelRight = label.left + label.width;
    const number = fragments
      .filter((fragment) => fragment !== label && numberPattern.test(fragment.text))
      .filter((fragment) => Math.abs(fragment.top + fragment.height / 2 - (label.top + label.height / 2)) <= Math.max(label.height, fragment.height) * .6)
      .filter((fragment) => fragment.left >= labelRight - 2 && fragment.left - labelRight <= Math.max(24, label.height * 2.5))
      .sort((first, second) => first.left - second.left)[0];
    if (!number) continue;
    const right = Math.max(labelRight, number.left + number.width);
    const bottom = Math.max(label.top + label.height, number.top + number.height);
    joined.push({ text: `${label.text} ${number.text}`, left: label.left, top: Math.min(label.top, number.top), width: right - label.left, height: bottom - Math.min(label.top, number.top) });
  }
  return [...fragments, ...joined];
}

function inferPdfVisualRect(page: HTMLElement, textLayer: HTMLElement, clientX: number, clientY: number): { rect: PdfVisualRect; nearbyText: string; kind: PaperVisualKind } {
  const pageBounds = page.getBoundingClientRect();
  const x = clampPdfCoordinate(clientX - pageBounds.left, 0, pageBounds.width);
  const y = clampPdfCoordinate(clientY - pageBounds.top, 0, pageBounds.height);
  const fragments = pdfTextFragments(page, textLayer);
  const lines = pdfTextLines(page, textLayer);
  const figureCaptionPattern = /^(?:(?:figure|fig\.?)\s*\d+[a-z]?\b|图\s*[一二三四五六七八九十\d]+)/i;
  const tableCaptionPattern = /^(?:table\s*\d+[a-z]?\b|表\s*[一二三四五六七八九十\d]+)/i;
  const captionFragments = pdfCaptionFragments(fragments);
  const captionCandidates = (captionFragments.some((fragment) => figureCaptionPattern.test(fragment.text) || tableCaptionPattern.test(fragment.text)) ? captionFragments : lines)
    .filter((line) => figureCaptionPattern.test(line.text) || tableCaptionPattern.test(line.text))
    .map((line) => ({ line, kind: tableCaptionPattern.test(line.text) ? "table" as const : "figure" as const, distance: distanceToPdfRect(x, y, line) }))
    .filter((candidate) => candidate.distance <= Math.max(pageBounds.width, pageBounds.height) * .62)
    .sort((first, second) => first.distance - second.distance);
  const captionCandidate = captionCandidates[0];
  const caption = captionCandidate?.line;
  const kind: PaperVisualKind = captionCandidate?.kind ?? "figure";
  let rect: PdfVisualRect;
  if (caption && kind === "table") {
    const captionX = caption.left + caption.width / 2;
    const captionY = caption.top + caption.height / 2;
    const captionIsBelow = y < captionY;
    const visualHeight = clampPdfCoordinate(
      Math.abs(y - captionY) * 1.7,
      pageBounds.height * .26,
      pageBounds.height * .42,
    );
    const visualWidth = clampPdfCoordinate(
      Math.max(pageBounds.width * .34, caption.width * 1.16),
      pageBounds.width * .34,
      pageBounds.width * .94,
    );
    const centerX = caption.width >= pageBounds.width * .26
      ? clampPdfCoordinate(captionX, visualWidth / 2, pageBounds.width - visualWidth / 2)
      : clampPdfCoordinate(x, visualWidth / 2, pageBounds.width - visualWidth / 2);
    rect = {
      left: centerX - visualWidth / 2,
      top: captionIsBelow ? caption.top - visualHeight : caption.top - 8,
      width: visualWidth,
      height: visualHeight + caption.height + 8,
    };
  } else if (caption) {
    const captionX = caption.left + caption.width / 2;
    const captionY = caption.top + caption.height / 2;
    const deltaX = x - captionX;
    const deltaY = y - captionY;
    if (Math.abs(deltaY) >= Math.abs(deltaX) * .55) {
      const visualHeight = clampPdfCoordinate(Math.max(pageBounds.height * .3, Math.abs(deltaY) * 1.9), pageBounds.height * .3, pageBounds.height * .64);
      const captionIsBelow = deltaY < 0;
      const top = captionIsBelow ? caption.top - visualHeight : caption.top - 10;
      const bottom = captionIsBelow ? caption.top + caption.height + 10 : caption.top + caption.height + visualHeight;
      const wideCaption = caption.width >= pageBounds.width * .42;
      const visualWidth = wideCaption ? pageBounds.width * .94 : Math.min(pageBounds.width * .62, Math.max(pageBounds.width * .42, caption.width * 1.22));
      const centerX = wideCaption ? pageBounds.width / 2 : clampPdfCoordinate((x + captionX) / 2, visualWidth / 2, pageBounds.width - visualWidth / 2);
      rect = { left: centerX - visualWidth / 2, top, width: visualWidth, height: bottom - top };
    } else {
      const visualWidth = clampPdfCoordinate(Math.max(pageBounds.width * .38, Math.abs(deltaX) * 1.85), pageBounds.width * .38, pageBounds.width * .72);
      const captionIsRight = deltaX < 0;
      const left = captionIsRight ? caption.left - visualWidth : caption.left - 10;
      const right = captionIsRight ? caption.left + caption.width + 10 : caption.left + caption.width + visualWidth;
      const visualHeight = Math.min(pageBounds.height * .54, Math.max(pageBounds.height * .28, caption.height * 8));
      const centerY = clampPdfCoordinate((y + captionY) / 2, visualHeight / 2, pageBounds.height - visualHeight / 2);
      rect = { left, top: centerY - visualHeight / 2, width: right - left, height: visualHeight };
    }
  } else {
    const width = pageBounds.width * .84;
    const height = pageBounds.height * .44;
    rect = { left: x - width / 2, top: y - height / 2, width, height };
  }
  const padding = 10;
  const left = clampPdfCoordinate(rect.left - padding, 0, pageBounds.width - 1);
  const top = clampPdfCoordinate(rect.top - padding, 0, pageBounds.height - 1);
  const right = clampPdfCoordinate(rect.left + rect.width + padding, left + 1, pageBounds.width);
  const bottom = clampPdfCoordinate(rect.top + rect.height + padding, top + 1, pageBounds.height);
  const normalized = { left, top, width: right - left, height: bottom - top };
  const nearbyText = lines
    .filter((line) => distanceToPdfRect(line.left + line.width / 2, line.top + line.height / 2, {
      left: normalized.left - 36, top: normalized.top - 36, width: normalized.width + 72, height: normalized.height + 72,
    }) === 0)
    .map((line) => line.text)
    .join(" ")
    .replace(/\s+/g, " ")
    .trim()
    .slice(0, 4_000);
  return { rect: normalized, nearbyText, kind };
}

function pdfRectArea(rect: PdfVisualRect) {
  return Math.max(0, rect.width) * Math.max(0, rect.height);
}

function pdfRectIntersection(first: PdfVisualRect, second: PdfVisualRect) {
  const left = Math.max(first.left, second.left);
  const top = Math.max(first.top, second.top);
  const right = Math.min(first.left + first.width, second.left + second.width);
  const bottom = Math.min(first.top + first.height, second.top + second.height);
  return Math.max(0, right - left) * Math.max(0, bottom - top);
}

function unionPdfRects(first: PdfVisualRect, second: PdfVisualRect): PdfVisualRect {
  const left = Math.min(first.left, second.left);
  const top = Math.min(first.top, second.top);
  const right = Math.max(first.left + first.width, second.left + second.width);
  const bottom = Math.max(first.top + first.height, second.top + second.height);
  return { left, top, width: right - left, height: bottom - top };
}

function padPdfRect(rect: PdfVisualRect, padding: number, pageWidth: number, pageHeight: number): PdfVisualRect {
  const left = clampPdfCoordinate(rect.left - padding, 0, pageWidth - 1);
  const top = clampPdfCoordinate(rect.top - padding, 0, pageHeight - 1);
  const right = clampPdfCoordinate(rect.left + rect.width + padding, left + 1, pageWidth);
  const bottom = clampPdfCoordinate(rect.top + rect.height + padding, top + 1, pageHeight);
  return { left, top, width: right - left, height: bottom - top };
}

function pdfNearbyText(lines: PdfTextLine[], rect: PdfVisualRect) {
  const nearby = { left: rect.left - 32, top: rect.top - 32, width: rect.width + 64, height: rect.height + 64 };
  return lines
    .filter((line) => pdfRectIntersection(line, nearby) > 0)
    .map((line) => line.text)
    .join(" ")
    .replace(/\s+/g, " ")
    .trim()
    .slice(0, 4_000);
}

function detectPdfImageRegions(operatorList: { fnArray: number[]; argsArray: unknown[][] }, pdfjs: typeof import("pdfjs-dist"), viewport: { transform: number[]; width: number; height: number }): PdfVisualRect[] {
  const stack: number[][] = [];
  let current = [1, 0, 0, 1, 0, 0];
  const regions: PdfVisualRect[] = [];
  const addTransformedRect = (transform: number[], sourceRect: number[], padding = 4) => {
    if (sourceRect.length < 4) return;
    const [firstX, firstY, secondX, secondY] = sourceRect;
    const corners = [[firstX, firstY], [secondX, firstY], [firstX, secondY], [secondX, secondY]].map((source) => {
      const point = [...source];
      pdfjs.Util.applyTransform(point, transform);
      return point;
    });
    const left = Math.min(...corners.map((point) => point[0]));
    const right = Math.max(...corners.map((point) => point[0]));
    const top = Math.min(...corners.map((point) => point[1]));
    const bottom = Math.max(...corners.map((point) => point[1]));
    const rect = padPdfRect({ left, top, width: right - left, height: bottom - top }, padding, viewport.width, viewport.height);
    const areaRatio = pdfRectArea(rect) / (viewport.width * viewport.height);
    if (rect.width >= 44 && rect.height >= 32 && areaRatio >= .004 && areaRatio <= .82) regions.push(rect);
  };
  for (let index = 0; index < operatorList.fnArray.length; index += 1) {
    const fn = operatorList.fnArray[index];
    const args = operatorList.argsArray[index] as unknown[] | undefined;
    if (fn === pdfjs.OPS.save) { stack.push([...current]); continue; }
    if (fn === pdfjs.OPS.restore) { current = stack.pop() || [1, 0, 0, 1, 0, 0]; continue; }
    if (fn === pdfjs.OPS.transform && args && args.length >= 6 && args.slice(0, 6).every((value) => typeof value === "number")) {
      current = pdfjs.Util.transform(current, args.slice(0, 6) as number[]);
      continue;
    }
    // A large proportion of LaTeX figures are imported as vector Form XObjects,
    // not raster Image XObjects. Their declared bbox is the only reliable full-
    // object boundary; ignoring it forces caption-based guessing and produces
    // partial or whitespace-heavy hover regions.
    if (fn === pdfjs.OPS.paintFormXObjectBegin) {
      stack.push([...current]);
      const matrixSource = args?.[0];
      const bboxSource = args?.[1];
      const matrix = (Array.isArray(matrixSource) || ArrayBuffer.isView(matrixSource))
        ? Array.from(matrixSource as ArrayLike<number>).slice(0, 6)
        : null;
      const bbox = (Array.isArray(bboxSource) || ArrayBuffer.isView(bboxSource))
        ? Array.from(bboxSource as ArrayLike<number>).slice(0, 4)
        : null;
      if (matrix) current = pdfjs.Util.transform(current, matrix.slice(0, 6));
      if (bbox) addTransformedRect(pdfjs.Util.transform(viewport.transform, current), bbox, 3);
      continue;
    }
    if (fn === pdfjs.OPS.paintFormXObjectEnd) {
      current = stack.pop() || [1, 0, 0, 1, 0, 0];
      continue;
    }
    if (fn !== pdfjs.OPS.paintImageXObject && fn !== pdfjs.OPS.paintInlineImageXObject) continue;
    const transform = pdfjs.Util.transform(viewport.transform, current);
    addTransformedRect(transform, [0, 0, 1, 1]);
  }
  return regions.filter((rect, index) => !regions.some((other, otherIndex) => otherIndex !== index && pdfRectArea(other) > pdfRectArea(rect) && pdfRectIntersection(rect, other) / pdfRectArea(rect) > .9));
}

function pdfCanvasInkScore(canvas: HTMLCanvasElement, page: HTMLElement, rect: PdfVisualRect, text: PdfTextLine[]) {
  const bounds = page.getBoundingClientRect();
  const scaleX = canvas.width / bounds.width;
  const scaleY = canvas.height / bounds.height;
  const left = Math.max(0, Math.floor(rect.left * scaleX));
  const top = Math.max(0, Math.floor(rect.top * scaleY));
  const width = Math.min(canvas.width - left, Math.max(1, Math.ceil(rect.width * scaleX)));
  const height = Math.min(canvas.height - top, Math.max(1, Math.ceil(rect.height * scaleY)));
  const context = canvas.getContext("2d", { willReadFrequently: true });
  if (!context || width * height > 18_000_000) return 0;
  const pixels = context.getImageData(left, top, width, height).data;
  const overlappingText = text.filter((line) => pdfRectIntersection(line, rect) > 0);
  const step = Math.max(2, Math.ceil(Math.max(width, height) / 520));
  let ink = 0;
  let sampled = 0;
  for (let py = 0; py < height; py += step) for (let px = 0; px < width; px += step) {
    const pageX = rect.left + px / scaleX;
    const pageY = rect.top + py / scaleY;
    if (overlappingText.some((line) => pageX >= line.left - 1 && pageX <= line.left + line.width + 1 && pageY >= line.top - 1 && pageY <= line.top + line.height + 1)) continue;
    const offset = (py * width + px) * 4;
    const darkness = 255 - (pixels[offset] + pixels[offset + 1] + pixels[offset + 2]) / 3;
    if (pixels[offset + 3] > 30 && darkness > 38) ink += 1;
    sampled += 1;
  }
  return sampled ? ink / sampled : 0;
}

function tightenPdfVisualRect(canvas: HTMLCanvasElement, page: HTMLElement, rect: PdfVisualRect) {
  const bounds = page.getBoundingClientRect();
  const scaleX = canvas.width / bounds.width;
  const scaleY = canvas.height / bounds.height;
  const sourceLeft = Math.max(0, Math.floor(rect.left * scaleX));
  const sourceTop = Math.max(0, Math.floor(rect.top * scaleY));
  const sourceWidth = Math.min(canvas.width - sourceLeft, Math.max(1, Math.ceil(rect.width * scaleX)));
  const sourceHeight = Math.min(canvas.height - sourceTop, Math.max(1, Math.ceil(rect.height * scaleY)));
  const context = canvas.getContext("2d", { willReadFrequently: true });
  if (!context || sourceWidth * sourceHeight > 24_000_000) return rect;
  const pixels = context.getImageData(sourceLeft, sourceTop, sourceWidth, sourceHeight).data;
  const stride = Math.max(1, Math.ceil(Math.max(sourceWidth, sourceHeight) / 1_100));
  let minX = sourceWidth;
  let minY = sourceHeight;
  let maxX = -1;
  let maxY = -1;
  let ink = 0;
  for (let py = 0; py < sourceHeight; py += stride) for (let px = 0; px < sourceWidth; px += stride) {
    const offset = (py * sourceWidth + px) * 4;
    const red = pixels[offset];
    const green = pixels[offset + 1];
    const blue = pixels[offset + 2];
    const alpha = pixels[offset + 3];
    const darkest = Math.min(red, green, blue);
    const chroma = Math.max(red, green, blue) - darkest;
    if (alpha <= 24 || (darkest >= 244 && chroma <= 8)) continue;
    minX = Math.min(minX, px);
    minY = Math.min(minY, py);
    maxX = Math.max(maxX, px);
    maxY = Math.max(maxY, py);
    ink += 1;
  }
  if (ink < 18 || maxX < minX || maxY < minY) return rect;
  const tightened: PdfVisualRect = {
    left: rect.left + minX / scaleX,
    top: rect.top + minY / scaleY,
    width: Math.max(1, (maxX - minX + stride) / scaleX),
    height: Math.max(1, (maxY - minY + stride) / scaleY),
  };
  return padPdfRect(tightened, 9, bounds.width, bounds.height);
}

function clipPdfTableAtOtherCaptions(rect: PdfVisualRect, caption: PdfVisualRect, otherCaptions: PdfVisualRect[]) {
  let top = rect.top;
  let bottom = rect.top + rect.height;
  for (const other of otherCaptions) {
    const horizontalOverlap = Math.max(0, Math.min(rect.left + rect.width, other.left + other.width) - Math.max(rect.left, other.left));
    if (horizontalOverlap < Math.min(24, other.width * .15)) continue;
    if (other.top > caption.top && other.top < bottom) bottom = Math.min(bottom, other.top - 4);
    if (other.top + other.height < caption.top && other.top + other.height > top) top = Math.max(top, other.top + other.height + 4);
  }
  return { ...rect, top, height: Math.max(1, bottom - top) };
}

function detectPdfTableRect(canvas: HTMLCanvasElement, page: HTMLElement, caption: PdfVisualRect, fragments: PdfTextLine[], otherCaptions: PdfVisualRect[]) {
  const bounds = page.getBoundingClientRect();
  const scaleX = canvas.width / bounds.width;
  const scaleY = canvas.height / bounds.height;
  const context = canvas.getContext("2d", { willReadFrequently: true });
  if (context) {
    const pixels = context.getImageData(0, 0, canvas.width, canvas.height).data;
    const ruled = findRuledTableRect(caption, findPdfHorizontalRules(pixels, canvas.width, canvas.height, scaleX, scaleY, bounds.width), bounds.width, bounds.height);
    if (ruled) return clipPdfTableAtOtherCaptions(ruled, caption, otherCaptions);
  }
  // Borderless tables are common in camera-ready papers; their repeated wide
  // multi-cell rows are still a stronger boundary than caption distance.
  const textTable = findTextTableRect(caption, fragments, bounds.width, bounds.height);
  return textTable ? clipPdfTableAtOtherCaptions(textTable, caption, otherCaptions) : null;
}

function pdfCaptionCandidates(fragments: PdfTextLine[], lines: PdfTextLine[]) {
  const candidates = [...lines, ...pdfCaptionFragments(fragments)]
    .flatMap((line) => {
      const kind = pdfCaptionKind(line.text);
      return kind ? [{ line, kind }] : [];
    })
    // Full caption lines carry the correct column and are more useful than a
    // separate “Figure” + “3” text fragment at the same position.
    .sort((first, second) => second.line.width - first.line.width);
  const accepted: typeof candidates = [];
  for (const candidate of candidates) {
    const centerY = candidate.line.top + candidate.line.height / 2;
    const duplicate = accepted.some((other) => {
      if (other.kind !== candidate.kind) return false;
      const otherCenterY = other.line.top + other.line.height / 2;
      return Math.abs(centerY - otherCenterY) <= Math.max(5, candidate.line.height, other.line.height) * .7
        && pdfRectIntersection(candidate.line, other.line) > 0;
    });
    if (!duplicate) accepted.push(candidate);
  }
  return accepted;
}

function pdfCaptionColumn(caption: PdfVisualRect, pageWidth: number): PdfVisualRect {
  if (caption.width >= pageWidth * .46) return { left: pageWidth * .035, top: 0, width: pageWidth * .93, height: 0 };
  const center = caption.left + caption.width / 2;
  if (center < pageWidth / 2) return { left: pageWidth * .045, top: 0, width: pageWidth * .455, height: 0 };
  return { left: pageWidth * .5, top: 0, width: pageWidth * .455, height: 0 };
}

function pdfVerticalGap(first: PdfVisualRect, second: PdfVisualRect) {
  const firstBottom = first.top + first.height;
  const secondBottom = second.top + second.height;
  return Math.max(0, second.top - firstBottom, first.top - secondBottom);
}

function pdfImageCluster(caption: PdfVisualRect, imageRects: PdfVisualRect[], column: PdfVisualRect, pageHeight: number) {
  const captionBottom = caption.top + caption.height;
  const candidates = imageRects.filter((rect) => {
    const overlap = Math.max(0, Math.min(rect.left + rect.width, column.left + column.width) - Math.max(rect.left, column.left));
    const isAbove = rect.top + rect.height <= caption.top + 3;
    const isBelow = rect.top >= captionBottom - 3;
    const distance = isAbove ? caption.top - rect.top - rect.height : isBelow ? rect.top - captionBottom : Number.POSITIVE_INFINITY;
    return overlap >= Math.min(rect.width * .25, 24) && distance <= pageHeight * .46;
  });
  if (!candidates.length) return null;
  const anchor = [...candidates].sort((first, second) => distanceToPdfRect(caption.left + caption.width / 2, caption.top + caption.height / 2, first) - distanceToPdfRect(caption.left + caption.width / 2, caption.top + caption.height / 2, second))[0];
  const direction = anchor.top + anchor.height / 2 < caption.top + caption.height / 2 ? "above" : "below";
  const onSide = candidates.filter((rect) => direction === "above" ? rect.top + rect.height <= caption.top + 3 : rect.top >= captionBottom - 3);
  const cluster = [anchor];
  let union = anchor;
  let changed = true;
  while (changed) {
    changed = false;
    for (const rect of onSide) {
      if (cluster.includes(rect)) continue;
      const gap = pdfVerticalGap(union, rect);
      const expanded = unionPdfRects(union, rect);
      if (gap <= pageHeight * .115 && expanded.height <= pageHeight * .56) {
        cluster.push(rect);
        union = expanded;
        changed = true;
      }
    }
  }
  return { rects: cluster, union, direction } as const;
}

function pdfTrimCandidatePastProse(lines: PdfTextLine[], candidate: PdfVisualRect, anchor: PdfVisualRect, direction: "above" | "below") {
  const longLines = lines
    .filter((line) => line.text.length >= 34 && line.width >= candidate.width * .46)
    .filter((line) => pdfRectIntersection(line, candidate) > 0)
    .filter((line) => direction === "above" ? line.top + line.height <= anchor.top : line.top >= anchor.top + anchor.height)
    .sort((first, second) => first.top - second.top);
  const runs: PdfTextLine[][] = [];
  for (const line of longLines) {
    const run = runs.at(-1);
    const previous = run?.at(-1);
    if (run && previous && line.top - previous.top - previous.height <= Math.max(14, line.height * 1.8) && Math.abs(line.left - previous.left) <= Math.max(20, candidate.width * .09)) run.push(line);
    else runs.push([line]);
  }
  const proseRuns = runs.filter((run) => run.length >= 3);
  if (!proseRuns.length) return candidate;
  if (direction === "above") {
    const last = proseRuns.at(-1)!.at(-1)!;
    const top = Math.max(candidate.top, last.top + last.height + 7);
    return { ...candidate, top, height: Math.max(1, candidate.top + candidate.height - top) };
  }
  const first = proseRuns[0][0];
  return { ...candidate, height: Math.max(1, first.top - candidate.top - 7) };
}

function pdfCompositeImageRect(page: HTMLElement, canvas: HTMLCanvasElement, lines: PdfTextLine[], caption: PdfVisualRect, cluster: NonNullable<ReturnType<typeof pdfImageCluster>>, column: PdfVisualRect) {
  if (cluster.rects.length === 1) return tightenPdfVisualRect(canvas, page, cluster.union);
  const bounds = page.getBoundingClientRect();
  const expansion = Math.max(bounds.height * .1, cluster.union.height * .86);
  const candidate: PdfVisualRect = cluster.direction === "above"
    ? { left: column.left, top: Math.max(0, cluster.union.top - expansion), width: column.width, height: caption.top - 4 - Math.max(0, cluster.union.top - expansion) }
    : { left: column.left, top: caption.top + caption.height + 4, width: column.width, height: Math.min(bounds.height, cluster.union.top + cluster.union.height + expansion) - caption.top - caption.height - 4 };
  const trimmed = pdfTrimCandidatePastProse(lines, candidate, cluster.union, cluster.direction);
  return tightenPdfVisualRect(canvas, page, trimmed);
}

function detectPdfCaptionRegions(page: HTMLElement, textLayer: HTMLElement, canvas: HTMLCanvasElement, imageRects: PdfVisualRect[]): PdfInteractiveRegion[] {
  const bounds = page.getBoundingClientRect();
  const fragments = pdfTextFragments(page, textLayer);
  const lines = pdfTextLines(page, textLayer);
  const captions = pdfCaptionCandidates(fragments, lines);
  return captions.flatMap<PdfInteractiveRegion>(({ line: caption, kind }) => {
    const column = pdfCaptionColumn(caption, bounds.width);
    if (kind === "table") {
      // Tables often share a page with a nearby chart. Resolve row/rule
      // structure first; otherwise the table caption can steal the following
      // figure's image object and the real table never gets an overlay.
      const rect = detectPdfTableRect(canvas, page, caption, fragments, captions.filter((candidate) => candidate.line !== caption).map((candidate) => candidate.line));
      if (rect) return [{ rect, nearbyText: pdfNearbyText(lines, unionPdfRects(rect, caption)), kind, source: "caption" as const }];
    }
    const imageCluster = pdfImageCluster(caption, imageRects, column, bounds.height);
    if (imageCluster) {
      const rect = pdfCompositeImageRect(page, canvas, lines, caption, imageCluster, column);
      const evidenceRect = unionPdfRects(rect, caption);
      return [{ rect, nearbyText: pdfNearbyText(lines, evidenceRect), kind, source: "image" as const }];
    }
    // Vector-only figures have no image XObject. Search only inside the caption's
    // column, then require real non-text ink and reject paragraph-shaped regions.
    const above: PdfVisualRect = { left: column.left, top: Math.max(0, caption.top - bounds.height * .47), width: column.width, height: Math.min(bounds.height * .47, caption.top - 4) };
    const belowTop = caption.top + caption.height + 4;
    const below: PdfVisualRect = { left: column.left, top: belowTop, width: column.width, height: Math.min(bounds.height * .47, bounds.height - belowTop) };
    const candidates = [above, below]
      .filter((rect) => rect.width > 20 && rect.height > 20 && !isDensePdfProse(lines, rect))
      .map((rect) => ({ rect, score: pdfCanvasInkScore(canvas, page, rect, lines) }))
      .filter((candidate) => candidate.score >= .0022)
      .sort((first, second) => second.score - first.score);
    if (!candidates.length) return [];
    const rect = tightenPdfVisualRect(canvas, page, candidates[0].rect);
    if (isDensePdfProse(lines, rect)) return [];
    const evidenceRect = unionPdfRects(rect, caption);
    return [{ rect, nearbyText: pdfNearbyText(lines, evidenceRect), kind, source: "caption" as const }];
  });
}

function mergePdfInteractiveRegions(regions: PdfInteractiveRegion[]) {
  return mergePdfVisualRegions(regions);
}

function installPdfInteractiveRegions(page: HTMLElement, canvas: HTMLCanvasElement, regions: PdfInteractiveRegion[], pageNumber: number, onCapture: (capture: PaperFigureCapture) => void, labels: Record<PaperVisualKind, string>) {
  const overlays = regions.map((region) => {
    const overlay = window.document.createElement("div");
    overlay.className = `arch-pdf-object-region ${region.kind}`;
    overlay.style.left = `${region.rect.left}px`;
    overlay.style.top = `${region.rect.top}px`;
    overlay.style.width = `${region.rect.width}px`;
    overlay.style.height = `${region.rect.height}px`;
    const action = window.document.createElement("button");
    action.type = "button";
    action.className = "arch-pdf-object-action";
    action.textContent = labels[region.kind];
    action.addEventListener("mousedown", (event) => { event.preventDefault(); event.stopPropagation(); });
    action.addEventListener("click", (event) => {
      event.preventDefault();
      event.stopPropagation();
      overlays.forEach((item) => item.classList.remove("selected"));
      overlay.classList.add("active", "selected");
      onCapture({ pageNumber, nearbyText: region.nearbyText, kind: region.kind, image: cropPdfVisual(canvas, page, region.rect, pageNumber, region.kind) });
      window.getSelection()?.removeAllRanges();
    });
    overlay.append(action);
    page.append(overlay);
    return overlay;
  });
  const activate = (event: MouseEvent) => {
    if ((event.target as Element | null)?.closest(".arch-pdf-object-action")) return;
    const bounds = page.getBoundingClientRect();
    const x = event.clientX - bounds.left;
    const y = event.clientY - bounds.top;
    let match = -1;
    let area = Number.POSITIVE_INFINITY;
    regions.forEach((region, index) => {
      const rect = region.rect;
      if (x >= rect.left && x <= rect.left + rect.width && y >= rect.top && y <= rect.top + rect.height && pdfRectArea(rect) < area) { match = index; area = pdfRectArea(rect); }
    });
    overlays.forEach((overlay, index) => overlay.classList.toggle("active", index === match || overlay.classList.contains("selected")));
  };
  page.addEventListener("mousemove", activate);
  page.addEventListener("mouseleave", () => overlays.forEach((overlay) => overlay.classList.toggle("active", overlay.classList.contains("selected"))));
}

function cropPdfVisual(canvas: HTMLCanvasElement, page: HTMLElement, rect: PdfVisualRect, pageNumber: number, kind: PaperVisualKind): ContextAttachment {
  const pageBounds = page.getBoundingClientRect();
  const scaleX = canvas.width / pageBounds.width;
  const scaleY = canvas.height / pageBounds.height;
  const sourceX = Math.max(0, Math.floor(rect.left * scaleX));
  const sourceY = Math.max(0, Math.floor(rect.top * scaleY));
  const sourceWidth = Math.min(canvas.width - sourceX, Math.max(1, Math.ceil(rect.width * scaleX)));
  const sourceHeight = Math.min(canvas.height - sourceY, Math.max(1, Math.ceil(rect.height * scaleY)));
  const outputScale = Math.min(1, 2_400 / Math.max(sourceWidth, sourceHeight));
  const output = window.document.createElement("canvas");
  output.width = Math.max(1, Math.round(sourceWidth * outputScale));
  output.height = Math.max(1, Math.round(sourceHeight * outputScale));
  const context = output.getContext("2d");
  if (!context) throw new Error("Figure capture is unavailable.");
  context.fillStyle = "#fff";
  context.fillRect(0, 0, output.width, output.height);
  context.drawImage(canvas, sourceX, sourceY, sourceWidth, sourceHeight, 0, 0, output.width, output.height);
  let mimeType: ContextImage["mimeType"] = "image/png";
  let dataUrl = output.toDataURL(mimeType);
  let base64 = dataUrl.slice(dataUrl.indexOf(",") + 1);
  let sizeBytes = Math.ceil(base64.length * 3 / 4);
  if (sizeBytes > 5_500_000) {
    mimeType = "image/jpeg";
    dataUrl = output.toDataURL(mimeType, .9);
    base64 = dataUrl.slice(dataUrl.indexOf(",") + 1);
    sizeBytes = Math.ceil(base64.length * 3 / 4);
  }
  return {
    id: `paper-visual:${pageNumber}:${crypto.randomUUID()}`,
    type: "image",
    name: `PDF page ${pageNumber} ${kind}`,
    detail: `Automatically selected ${kind} from PDF page ${pageNumber}`,
    image: { dataUrl, mimeType, sizeBytes, width: output.width, height: output.height },
  };
}

function PdfPaperCanvas({ url, pageNumber, highlights, searchQuery, zoom, activeSelection, figureCaptureActive, onZoomChange, onSelection, onFigureCapture, onClearSelection, onProjectLink, onProjectDetected }: { url: string; pageNumber: number; highlights: PaperHighlight[]; searchQuery: string; zoom: number; activeSelection: string; figureCaptureActive: boolean; onZoomChange: (updater: (current: number) => number) => void; onSelection: (text: string, anchor: SelectionAnchor) => void; onFigureCapture: (capture: PaperFigureCapture) => void; onClearSelection: () => void; onProjectLink: (url: string) => void; onProjectDetected: (url: string) => void }) {
  const stageRef = useRef<HTMLDivElement>(null);
  const { t } = useUISettings();
  const hostRef = useRef<HTMLDivElement>(null);
  const highlightsRef = useRef(highlights);
  const searchQueryRef = useRef(searchQuery);
  const onFigureCaptureRef = useRef(onFigureCapture);
  const onProjectLinkRef = useRef(onProjectLink);
  const onProjectDetectedRef = useRef(onProjectDetected);
  const translateRef = useRef(t);
  const [width, setWidth] = useState(0);
  const [state, setState] = useState<"loading" | "ready" | "error">("loading");
  const [error, setError] = useState("");
  useEffect(() => {
    const stage = stageRef.current;
    if (!stage) return;
    // Measure the usable viewport, not the rendered surface. The surface grows
    // with the PDF and can make fit-to-width feed back into itself. Reserving
    // the vertical gutter in CSS keeps this value unchanged as the PDF arrives.
    const updateWidth = () => {
      const styles = window.getComputedStyle(stage);
      const horizontalPadding = Number.parseFloat(styles.paddingLeft) + Number.parseFloat(styles.paddingRight);
      // A native scrollbar and fractional device-pixel rounding can make the
      // reported width alternate by a few pixels. Quantize the fit width so
      // that tiny observer fluctuations cannot trigger a complete PDF repaint.
      const usableWidth = stage.clientWidth - horizontalPadding;
      const next = Math.max(320, Math.floor(usableWidth / PDF_VIEWPORT_WIDTH_STEP) * PDF_VIEWPORT_WIDTH_STEP);
      setWidth((current) => Math.abs(current - next) < 1 ? current : next);
    };
    updateWidth();
    // Initial PDF mounting changes gutters in several frames. Debounce those
    // observations so the page is rendered once the reader shell settles,
    // instead of cancelling and restarting the render on every frame.
    let timer: number | undefined;
    const observer = new ResizeObserver(() => {
      window.clearTimeout(timer);
      timer = window.setTimeout(updateWidth, 80);
    });
    observer.observe(stage);
    return () => {
      observer.disconnect();
      window.clearTimeout(timer);
    };
  }, []);
  useEffect(() => {
    highlightsRef.current = highlights;
    const textLayer = hostRef.current?.querySelector<HTMLDivElement>(".arch-pdf-text-layer");
    if (textLayer) applyPdfHighlights(textLayer, highlights.filter((highlight) => highlight.page_number === pageNumber));
  }, [highlights, pageNumber]);
  useEffect(() => {
    searchQueryRef.current = searchQuery;
    const textLayer = hostRef.current?.querySelector<HTMLDivElement>(".arch-pdf-text-layer");
    if (textLayer) applyPdfSearchHighlights(textLayer, searchQuery);
  }, [searchQuery]);
  useEffect(() => { onFigureCaptureRef.current = onFigureCapture; }, [onFigureCapture]);
  useEffect(() => { onProjectLinkRef.current = onProjectLink; }, [onProjectLink]);
  useEffect(() => { onProjectDetectedRef.current = onProjectDetected; }, [onProjectDetected]);
  useEffect(() => { translateRef.current = t; }, [t]);
  useEffect(() => {
    if (activeSelection) return;
    clearActivePdfSelection(hostRef.current);
  }, [activeSelection]);
  useEffect(() => {
    if (figureCaptureActive) return;
    hostRef.current?.querySelectorAll(".arch-pdf-object-region.selected").forEach((element) => element.classList.remove("selected", "active"));
  }, [figureCaptureActive]);
  useEffect(() => {
    let cancelled = false;
    let destroyLoadingTask: (() => void) | undefined;
    const host = hostRef.current;
    if (!host || !url || width <= 0) return;
    const renderHost = host;
    async function render() {
      const hasVisiblePage = Boolean(renderHost.querySelector(".arch-pdf-page"));
      if (!hasVisiblePage) setState("loading");
      setError("");
      try {
        const { pdfjs } = await import("./pdf-runtime");
        const response = await fetch(url);
        if (!response.ok) throw new Error(`PDF request failed (${response.status}).`);
        const loadingTask = pdfjs.getDocument({ data: new Uint8Array(await response.arrayBuffer()) });
        destroyLoadingTask = () => loadingTask.destroy();
        const pdfDocument = await loadingTask.promise;
        const pdfPage = await pdfDocument.getPage(pageNumber);
        const baseViewport = pdfPage.getViewport({ scale: 1 });
        const fitScale = Math.min(1.65, Math.max(.7, (width - 4) / baseViewport.width));
        const scale = fitScale * zoom;
        const viewport = pdfPage.getViewport({ scale });
        const page = window.document.createElement("div");
        page.className = "arch-pdf-page";
        page.style.width = `${viewport.width}px`;
        page.style.height = `${viewport.height}px`;
        const canvas = window.document.createElement("canvas");
        const pixelRatio = Math.min(window.devicePixelRatio || 1, 2);
        canvas.width = Math.floor(viewport.width * pixelRatio); canvas.height = Math.floor(viewport.height * pixelRatio);
        canvas.style.width = `${viewport.width}px`; canvas.style.height = `${viewport.height}px`;
        page.append(canvas);
        const textLayer = window.document.createElement("div");
        textLayer.className = "arch-pdf-text-layer";
        textLayer.style.setProperty("--total-scale-factor", String(scale));
        page.append(textLayer);
        const context = canvas.getContext("2d");
        if (!context) throw new Error("Canvas rendering is unavailable.");
        context.setTransform(pixelRatio, 0, 0, pixelRatio, 0, 0);
        await pdfPage.render({ canvas, canvasContext: context, viewport }).promise;
        const textContent = await pdfPage.getTextContent();
        // Keep PDF.js's declared text styles intact. TextLayer measures and scales
        // spans using those same styles; replacing them with embedded font names
        // makes the DOM selection boxes drift from the canvas glyphs.
        const layer = new pdfjs.TextLayer({ textContentSource: textContent, container: textLayer, viewport });
        await layer.render();
        // Geometry-based object detection must run after the page is in the live
        // document. Detached PDF.js spans report zero-sized client rectangles.
        if (cancelled) return;
        renderHost.replaceChildren(page);
        const operatorList = await pdfPage.getOperatorList();
        const imageRects = detectPdfImageRegions(operatorList, pdfjs, viewport);
        const nearbyLines = pdfTextLines(page, textLayer);
        const equationRegions: PdfInteractiveRegion[] = findEquationRects(equationTokens(textContent, viewport), viewport.width, viewport.height, imageRects)
          .map((rect) => ({ rect, nearbyText: pdfNearbyText(nearbyLines, rect), kind: "equation", source: "equation" }));
        const captionRegions = detectPdfCaptionRegions(page, textLayer, canvas, imageRects);
        const uncaptionedImages: PdfInteractiveRegion[] = imageRects
          .filter((rect) => !captionRegions.some((region) => region.source === "image" && pdfRectIntersection(region.rect, rect) / pdfRectArea(rect) > .72))
          .map((rect) => {
            const tightened = tightenPdfVisualRect(canvas, page, rect);
            return { rect: tightened, nearbyText: pdfNearbyText(pdfTextLines(page, textLayer), tightened), kind: "figure" as const, source: "image" as const };
          });
        installPdfInteractiveRegions(page, canvas, mergePdfInteractiveRegions([...equationRegions, ...captionRegions, ...uncaptionedImages]), pageNumber, (capture) => onFigureCaptureRef.current(capture), { equation: translateRef.current("Explain this equation"), table: translateRef.current("Explain this table"), figure: translateRef.current("Explain this image") });
        const annotations = await pdfPage.getAnnotations();
        for (const annotation of annotations) {
          const targetUrl = typeof annotation.url === "string" ? annotation.url : "";
          if (!targetUrl || !Array.isArray(annotation.rect)) continue;
          const [firstX, firstY, secondX, secondY] = viewport.convertToViewportRectangle(annotation.rect);
          const link = window.document.createElement("a");
          link.className = "arch-pdf-link";
          link.href = targetUrl;
          const isProjectLink = /^https:\/\//i.test(targetUrl) && (/^https:\/\/github\.com\/[^/]+\/[^/]+/i.test(targetUrl) || /\.github\.io(?:\/|$)/i.test(targetUrl));
          link.target = isProjectLink ? "_self" : "_blank";
          link.rel = "noreferrer";
          link.style.left = `${Math.min(firstX, secondX)}px`;
          link.style.top = `${Math.min(firstY, secondY)}px`;
          link.style.width = `${Math.abs(secondX - firstX)}px`;
          link.style.height = `${Math.abs(secondY - firstY)}px`;
          link.title = isProjectLink ? "Open linked project alongside this paper" : "Open link";
          if (isProjectLink) {
            onProjectDetectedRef.current(targetUrl);
            link.addEventListener("click", (event) => { event.preventDefault(); onProjectLinkRef.current(targetUrl); });
          }
          page.append(link);
        }
        applyPdfHighlights(textLayer, highlightsRef.current.filter((highlight) => highlight.page_number === pageNumber));
        applyPdfSearchHighlights(textLayer, searchQueryRef.current);
        if (!cancelled) setState("ready");
        pdfPage.cleanup(); pdfDocument.cleanup();
      } catch (renderError) { if (!cancelled) { setState("error"); setError(readableError(renderError, "The PDF page could not be rendered.")); } }
    }
    void render();
    return () => { cancelled = true; destroyLoadingTask?.(); };
  }, [pageNumber, url, width, zoom]);
  function selected(event: ReactMouseEvent<HTMLDivElement>) {
    const target = event.currentTarget;
    const selection = window.getSelection();
    if (!selection?.rangeCount || !selection.toString().trim() || !target.contains(selection.anchorNode) || !target.contains(selection.focusNode)) { onClearSelection(); return; }
    const textLayer = target.querySelector<HTMLDivElement>(".arch-pdf-text-layer");
    const anchorNode = selection.anchorNode;
    const focusNode = selection.focusNode;
    if (!anchorNode || !focusNode) { onClearSelection(); return; }
    const anchorSpan = textLayer && selectionNodeSpan(anchorNode, textLayer);
    const focusSpan = textLayer && selectionNodeSpan(focusNode, textLayer);
    const precise = textLayer && anchorSpan && focusSpan
      ? selectPdfTextByLayout(textLayer, anchorSpan, anchorNode, selection.anchorOffset, focusSpan, focusNode, selection.focusOffset)
      : null;
    const text = precise?.text || selection.toString();
    if (!text.trim()) { onClearSelection(); return; }
    clearActivePdfSelection(textLayer);
    precise?.segments.forEach(({ span, start, end }) => {
      const bounds = pdfSelectionSegmentBounds(span, start, end);
      span.style.setProperty("--arch-selection-start", `${bounds.start}%`);
      span.style.setProperty("--arch-selection-end", `${bounds.end}%`);
      span.classList.add("arch-pdf-active-selection");
    });
    const rect = (precise?.segments.at(-1)?.span || focusSpan || anchorSpan)?.getBoundingClientRect() || selection.getRangeAt(0).getBoundingClientRect();
    window.getSelection()?.removeAllRanges();
    onSelection(text, { x: rect.left + rect.width / 2, y: rect.top });
  }
  function zoomWithTrackpad(event: ReactWheelEvent<HTMLDivElement>) {
    if (!event.ctrlKey) return;
    event.preventDefault();
    onZoomChange((current) => Math.min(3.2, Math.max(.55, current * (event.deltaY < 0 ? 1.12 : .89))));
  }
  function beginSelection(event: ReactMouseEvent<HTMLDivElement>) {
    if ((event.target as Element | null)?.closest(".arch-pdf-object-action")) return;
    clearActivePdfSelection(hostRef.current);
    onClearSelection();
  }
  return <div className="arch-pdf-stage" ref={stageRef} onMouseDown={beginSelection} onMouseUp={selected} onWheel={zoomWithTrackpad}><div className="arch-pdf-surface" ref={hostRef} />{state === "loading" && <div className="arch-pdf-loading"><LoaderCircle className="spin" size={17} />{t("Rendering original PDF…")}</div>}{state === "error" && <div className="arch-pdf-loading error"><FileText size={17} />{error}</div>}<span className="arch-pdf-zoom-readout">{Math.round(zoom * 100)}%</span></div>;
}

function selectionNodeSpan(node: Node | null, layer: HTMLElement) {
  const element = node?.nodeType === Node.ELEMENT_NODE ? node as Element : node?.parentElement;
  const span = element?.closest<HTMLSpanElement>("span");
  return span && layer.contains(span) ? span : null;
}

function textOffsetWithinSpan(span: HTMLSpanElement, node: Node, offset: number) {
  try {
    const range = document.createRange();
    range.selectNodeContents(span);
    range.setEnd(node, offset);
    return range.toString().length;
  } catch { return 0; }
}

function clearActivePdfSelection(root: ParentNode | null) {
  root?.querySelectorAll<HTMLElement>(".arch-pdf-active-selection").forEach((element) => {
    element.classList.remove("arch-pdf-active-selection");
    element.style.removeProperty("--arch-selection-start");
    element.style.removeProperty("--arch-selection-end");
  });
}

function pdfTextPosition(span: HTMLSpanElement, requestedOffset: number) {
  const walker = document.createTreeWalker(span, NodeFilter.SHOW_TEXT);
  let remaining = Math.max(0, requestedOffset);
  let node = walker.nextNode();
  while (node) {
    const length = node.textContent?.length || 0;
    if (remaining <= length) return { node, offset: remaining };
    remaining -= length;
    node = walker.nextNode();
  }
  return { node: span, offset: span.childNodes.length };
}

function pdfSelectionSegmentBounds(span: HTMLSpanElement, requestedStart: number, requestedEnd: number) {
  const length = span.textContent?.length || 0;
  const start = Math.max(0, Math.min(length, requestedStart));
  const end = Math.max(start, Math.min(length, requestedEnd));
  if (start === 0 && end === length) return { start: 0, end: 100 };
  try {
    const range = document.createRange();
    const from = pdfTextPosition(span, start);
    const to = pdfTextPosition(span, end);
    range.setStart(from.node, from.offset);
    range.setEnd(to.node, to.offset);
    const spanRect = span.getBoundingClientRect();
    const rangeRect = range.getBoundingClientRect();
    if (spanRect.width <= 0 || rangeRect.width <= 0) throw new Error("No measurable text range");
    return {
      start: Math.max(0, Math.min(100, (rangeRect.left - spanRect.left) / spanRect.width * 100)),
      end: Math.max(0, Math.min(100, (rangeRect.right - spanRect.left) / spanRect.width * 100)),
    };
  } catch {
    return { start: length ? start / length * 100 : 0, end: length ? end / length * 100 : 100 };
  }
}

function selectPdfTextByLayout(layer: HTMLElement, anchorSpan: HTMLSpanElement, anchorNode: Node, anchorOffset: number, focusSpan: HTMLSpanElement, focusNode: Node, focusOffset: number) {
  const layerBounds = layer.getBoundingClientRect();
  const measured = Array.from(layer.querySelectorAll<HTMLSpanElement>("span"))
    .filter((span) => span.textContent?.trim())
    .map((span) => ({ span, rect: span.getBoundingClientRect() }))
    .filter(({ rect }) => rect.width > 0 && rect.height > 0);
  const anchor = measured.find((item) => item.span === anchorSpan);
  const focus = measured.find((item) => item.span === focusSpan);
  if (!anchor || !focus) return null;
  const before = (left: DOMRect, right: DOMRect) => left.top < right.top - 2 || (Math.abs(left.top - right.top) <= 2 && left.left <= right.left);
  const [first, last, firstNode, firstOffset, lastNode, lastOffset] = before(anchor.rect, focus.rect)
    ? [anchor, focus, anchorNode, anchorOffset, focusNode, focusOffset]
    : [focus, anchor, focusNode, focusOffset, anchorNode, anchorOffset];
  const top = first.rect.top - Math.max(first.rect.height, 8) * .45;
  const bottom = last.rect.bottom + Math.max(last.rect.height, 8) * .45;
  const firstCenterY = first.rect.top + first.rect.height / 2;
  const lastCenterY = last.rect.top + last.rect.height / 2;
  const sameVisualLine = Math.abs(firstCenterY - lastCenterY) <= Math.max(first.rect.height, last.rect.height) * .82;
  const selectionLeft = Math.min(first.rect.left, last.rect.left) - 14;
  const selectionRight = Math.max(first.rect.right, last.rect.right) + 14;
  const pageCenter = layerBounds.left + layerBounds.width / 2;
  const firstSide = first.rect.right < pageCenter ? -1 : first.rect.left > pageCenter ? 1 : 0;
  const lastSide = last.rect.right < pageCenter ? -1 : last.rect.left > pageCenter ? 1 : 0;
  const sharedColumn = firstSide !== 0 && firstSide === lastSide ? firstSide : 0;
  // PDF extraction order can place a footer, note, or a neighbouring column
  // between two visual text spans. Re-sort and crop by their page coordinates,
  // then constrain the path to the selected line or column. Without this,
  // equations and two-column papers absorb unrelated spans at the same Y.
  const visual = measured.filter(({ rect }) => {
    if (rect.bottom < top || rect.top > bottom) return false;
    if (sameVisualLine) return rect.right >= selectionLeft && rect.left <= selectionRight;
    if (sharedColumn < 0) return rect.left < pageCenter;
    if (sharedColumn > 0) return rect.right > pageCenter;
    return rect.right >= selectionLeft && rect.left <= selectionRight;
  })
    .sort((a, b) => Math.abs(a.rect.top - b.rect.top) > 2 ? a.rect.top - b.rect.top : a.rect.left - b.rect.left);
  const start = visual.findIndex((item) => item.span === first.span);
  const end = visual.findIndex((item) => item.span === last.span);
  if (start < 0 || end < start) return null;
  const spans = visual.slice(start, end + 1);
  const firstTextOffset = textOffsetWithinSpan(first.span, firstNode, firstOffset);
  const lastTextOffset = textOffsetWithinSpan(last.span, lastNode, lastOffset);
  const segments = spans.map(({ span }, index) => {
    const length = span.textContent?.length || 0;
    if (spans.length === 1) return { span, start: Math.min(firstTextOffset, lastTextOffset), end: Math.max(firstTextOffset, lastTextOffset) };
    if (index === 0) return { span, start: firstTextOffset, end: length };
    if (index === spans.length - 1) return { span, start: 0, end: lastTextOffset };
    return { span, start: 0, end: length };
  });
  let previousTop = Number.NaN;
  const text = spans.map(({ span, rect }, index) => {
    const source = span.textContent || "";
    const segment = segments[index];
    const fragment = source.slice(segment.start, segment.end);
    const prefix = Number.isNaN(previousTop) || Math.abs(rect.top - previousTop) <= 2 ? "" : "\n";
    previousTop = rect.top;
    return prefix + fragment;
  }).join("").replace(/\s*\n\s*/g, " ").replace(/\s+/g, " ").trim();
  return { text, segments };
}

function applyPdfHighlights(textLayer: HTMLDivElement, highlights: PaperHighlight[]) {
  const spans = Array.from(textLayer.querySelectorAll<HTMLSpanElement>("span"));
  for (const span of spans) {
    span.classList.remove("arch-pdf-highlight", "arch-pdf-highlight-note", "arch-pdf-highlight-yellow", "arch-pdf-highlight-red", "arch-pdf-highlight-blue", "arch-pdf-highlight-green", "arch-pdf-highlight-pink");
    span.style.backgroundImage = "";
    span.style.backgroundSize = "";
    span.style.backgroundPosition = "";
    span.style.backgroundRepeat = "";
    span.removeAttribute("title");
  }
  if (!highlights.length) return;

  const grouped = new Map<number, Array<{ start: number; end: number; color: string; note: boolean; noteText: string }>>();
  for (const segment of buildPdfHighlightSegments(spans.map((span) => span.textContent || ""), highlights)) {
    const list = grouped.get(segment.spanIndex) ?? [];
    list.push(segment);
    grouped.set(segment.spanIndex, list);
  }

  for (const [spanIndex, segments] of grouped) {
    const span = spans[spanIndex];
    if (!span) continue;
    const layers: string[] = [];
    const sizes: string[] = [];
    const positions: string[] = [];
    const repeats: string[] = [];
    for (const segment of segments) {
      const bounds = pdfSelectionSegmentBounds(span, segment.start, segment.end);
      const color = PDF_HIGHLIGHT_COLORS[segment.color] || PDF_HIGHLIGHT_COLORS.yellow;
      layers.push(`linear-gradient(90deg, transparent 0 ${bounds.start}%, ${color} ${bounds.start}% ${bounds.end}%, transparent ${bounds.end}% 100%)`);
      sizes.push("100% 100%");
      positions.push("0 0");
      repeats.push("no-repeat");
      if (segment.note) {
        layers.push(`linear-gradient(90deg, transparent 0 ${bounds.start}%, rgba(38, 103, 77, .72) ${bounds.start}% ${bounds.end}%, transparent ${bounds.end}% 100%)`);
        sizes.push("100% 2px");
        positions.push("0 100%");
        repeats.push("no-repeat");
      }
    }
    span.classList.add("arch-pdf-highlight");
    span.style.backgroundImage = layers.join(", ");
    span.style.backgroundSize = sizes.join(", ");
    span.style.backgroundPosition = positions.join(", ");
    span.style.backgroundRepeat = repeats.join(", ");
    const note = segments.find((segment) => segment.noteText)?.noteText;
    if (note) span.title = note;
  }
}

function normalizePaperMathDelimiters(content: string) {
  let activeFence = "";
  let displayMathOpen = false;
  const normalizedLines: string[] = [];
  for (const line of content.replace(/\r\n?/g, "\n").split("\n")) {
    const fence = /^\s*(`{3,}|~{3,})/.exec(line)?.[1] || "";
    if (fence) {
      if (!activeFence) activeFence = fence[0];
      else if (fence[0] === activeFence) activeFence = "";
      normalizedLines.push(line);
      continue;
    }
    if (activeFence) {
      normalizedLines.push(line);
      continue;
    }
    const normalized = normalizePaperMathLine(line);
    if (normalized.trim() === "$$") {
      displayMathOpen = !displayMathOpen;
      normalizedLines.push(normalized);
      continue;
    }
    const standaloneDisplay = /^\s*\$\$([\s\S]*?)\$\$\s*$/.exec(normalized);
    if (standaloneDisplay) {
      normalizedLines.push("$$", standaloneDisplay[1].trim(), "$$");
      continue;
    }
    // Providers sometimes emit a bare equation or leave one display delimiter unmatched.
    if (!displayMathOpen && !normalized.includes("$") && looksLikePaperEquation(normalized)) {
      const equation = normalized.trim().replace(/^\$+|\$+$/g, "").replace(/(^|[^\\])\$/g, "$1").trim();
      normalizedLines.push("$$", equation, "$$");
      continue;
    }
    normalizedLines.push(normalized);
  }
  return normalizedLines.join("\n");
}

function looksLikePaperEquation(line: string) {
  const trimmed = line.trim();
  if (!trimmed || /^(#{1,6}|[-*+]\s|\d+\.\s|>|<)/.test(trimmed)) return false;
  const equation = trimmed.replace(/^\$+|\$+$/g, "");
  return equation.includes("=")
    && /(?:\\[a-zA-Z]+|[_^][{(]|[A-Za-z]\s*[_^])/.test(equation)
    && !/[。；;]$/.test(equation);
}

function normalizePaperMathLine(line: string) {
  let result = "";
  let index = 0;
  while (index < line.length) {
    if (line[index] === "`") {
      const tickCount = /^`+/.exec(line.slice(index))?.[0].length || 1;
      const closingIndex = line.indexOf("`".repeat(tickCount), index + tickCount);
      if (closingIndex < 0) return result + line.slice(index);
      result += line.slice(index, closingIndex + tickCount);
      index = closingIndex + tickCount;
      continue;
    }
    const delimiter = line.slice(index, index + 2);
    if (delimiter === "\\[" || delimiter === "\\]") { result += "$$"; index += 2; continue; }
    if (delimiter === "\\(" || delimiter === "\\)") { result += "$"; index += 2; continue; }
    result += line[index];
    index += 1;
  }
  return result;
}

function LibraryEditor({ editor, active = true, onClose, onSave }: { editor: ResearchLibrary | "new" | null; active?: boolean; onClose: () => void; onSave: (input: { name: string; description: string; color: string }) => Promise<void> }) {
  const dialogOpen = Boolean(editor) && active;
  const [name, setName] = useState("");
  const [description, setDescription] = useState("");
  const [color, setColor] = useState(LIBRARY_COLORS[0]);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  useEffect(() => {
    setError("");
    setName(editor && editor !== "new" ? editor.name : "");
    setDescription(editor && editor !== "new" ? editor.description : "");
    setColor(editor && editor !== "new" ? editor.color : LIBRARY_COLORS[0]);
  }, [editor]);
  if (!editor || !active) return null;
  async function submit() {
    if (!name.trim()) return;
    setBusy(true);
    try { await onSave({ name: name.trim(), description: description.trim(), color }); }
    catch (cause) { setError(cause instanceof Error ? cause.message : String(cause)); }
    finally { setBusy(false); }
  }
  return <Dialog open={dialogOpen} onClose={onClose} size="md" className="dialog-ref library-editor-dialog" overlayClassName="modal-backdrop dialog-ref-backdrop" ariaLabelledBy="library-editor-title">
    <header className="dialog-ref-header">
      <div><h2 id="library-editor-title">{editor === "new" ? "New literature library" : "Edit library"}</h2><p>{editor === "new" ? "Libraries keep related papers, notes, and annotations together so you can return to a research direction without rebuilding context." : "Update the name, description, or color of this library."}</p></div>
      <button className="dialog-ref-close" onClick={onClose} title="Close" aria-label="Close"><X size={18} /></button>
    </header>
    <div className="dialog-ref-body">
      {error && <InlineNotice tone="danger">{error}</InlineNotice>}
      <label className="dialog-ref-field"><span>Library name</span><input autoFocus value={name} onChange={(event) => setName(event.target.value)} placeholder="Agentic RAG" /><small>Use a short name that identifies this research direction.</small></label>
      <label className="dialog-ref-field"><span>Description</span><textarea value={description} onChange={(event) => setDescription(event.target.value)} rows={4} placeholder="What belongs in this research direction?" /><small>Optional. Briefly describe the scope of the library.</small></label>
      <div className="dialog-ref-field"><span>Color</span><div className="color-picker" aria-label="Library color">{LIBRARY_COLORS.map((swatch) => <button key={swatch} className={color === swatch ? "color-swatch selected" : "color-swatch"} style={{ background: swatch }} onClick={() => setColor(swatch)} title={swatch}>{color === swatch && <Check size={13} />}</button>)}</div></div>
    </div>
    <footer className="dialog-ref-footer">
      <button className="secondary-button" onClick={onClose}>Cancel</button>
      <button className="primary-button" disabled={busy || !name.trim()} onClick={() => void submit()}>{busy ? <LoaderCircle className="spin" size={14} /> : null}{editor === "new" ? "Create library" : "Save changes"}</button>
    </footer>
  </Dialog>;
}

function PaperImportModal({ open, bridge, library, workspace, onClose, onImport, onLocalImported }: { open: boolean; bridge: ResearchDeskBridge; library: ResearchLibrary; workspace: string; onClose: () => void; onImport: (paper: AcademicSearchResult) => Promise<void>; onLocalImported: () => Promise<void> }) {
  const { t } = useUISettings();
  const [localImporting, setLocalImporting] = useState(false);
  const [query, setQuery] = useState("");
  const [results, setResults] = useState<AcademicSearchResult[]>([]);
  const [searching, setSearching] = useState(false);
  const [error, setError] = useState("");
  const [imported, setImported] = useState<Set<string>>(new Set());
  const [adding, setAdding] = useState<string | null>(null);
  if (!open) return null;
  async function search() {
    if (!query.trim()) return;
    setSearching(true);
    setError("");
    setResults([]);
    try {
      const nextResults = await bridge.searchAcademicPapers(query.trim(), 12);
      setResults(nextResults);
      if (!nextResults.length) setError("No matching papers were found. Check the identifier or try a title keyword.");
    } catch (searchError) {
      setError(readableError(searchError, "Paper search failed."));
    } finally {
      setSearching(false);
    }
  }
  async function add(paper: AcademicSearchResult) {
    const key = paper.external_id || paper.title;
    setAdding(key);
    setError("");
    try {
      await onImport(paper);
      setImported((current) => new Set(current).add(key));
    } catch (importError) {
      setError(readableError(importError, "The paper could not be added."));
    } finally {
      setAdding(null);
    }
  }
  async function importLocal() {
    setLocalImporting(true);
    setError("");
    try {
      const paper = await bridge.importLocalLibraryPaper(library.id, workspace);
      if (paper) { await onLocalImported(); onClose(); }
    } catch (importError) {
      setError(readableError(importError, t("The PDF could not be imported.")));
    } finally { setLocalImporting(false); }
  }
  return <Dialog open={open} onClose={onClose} size="lg" className="workspace-modal paper-import-modal" ariaLabel="Import paper">
    <div className="modal-header"><div><span className="eyebrow">Import into {library.name}</span><h2>Find academic papers</h2></div><button className="icon-button" onClick={onClose} title="Close"><X size={16} /></button></div>
    <div className="local-paper-import"><div><strong>{t("Import a local PDF")}</strong><small>{t("Choose a PDF from your computer. Its filename will be used as the title.")}</small></div><button type="button" className="secondary-button" disabled={localImporting} onClick={() => void importLocal()}>{localImporting ? <LoaderCircle className="spin" size={14} /> : <FileText size={14} />}{t(localImporting ? "Importing PDF…" : "Choose PDF")}</button></div>
    <p>Search by title, topic, DOI, arXiv URL, or arXiv ID. arXiv links are resolved directly; other queries use Semantic Scholar and OpenAlex.</p>
    <div className="external-search-box"><Search size={16} /><input autoFocus value={query} onChange={(event) => setQuery(event.target.value)} onKeyDown={(event) => event.key === "Enter" && void search()} placeholder="e.g. adaptive retrieval or 2401.18059" /><button className="primary-button" disabled={searching || !query.trim()} onClick={() => void search()}>{searching ? <LoaderCircle className="spin" size={14} /> : <Search size={14} />}Search</button></div>
    {error && <InlineNotice tone="danger" className="library-error">{error}</InlineNotice>}
    <div className="external-results">{results.map((paper) => {
      const key = paper.external_id || paper.title;
      const isImported = imported.has(key);
      const isAdding = adding === key;
      return <article className="external-paper" key={key}><div><strong>{paper.title}</strong><small>{paper.authors.slice(0, 3).join(", ")} · {paper.year ?? "n.d."} · {paper.venue || paper.source}</small></div><button className={isImported ? "secondary-button imported" : "outline-button"} disabled={isImported || Boolean(adding)} onClick={() => void add(paper)}>{isImported ? <Check size={14} /> : isAdding ? <LoaderCircle className="spin" size={14} /> : <Plus size={14} />}{isImported ? "Added" : isAdding ? "Adding" : "Add"}</button></article>;
    })}</div>
  </Dialog>;
}

function readableError(error: unknown, fallback: string) {
  const message = error instanceof Error ? error.message : String(error || fallback);
  return message
    .replace(/^Error invoking remote method '[^']+':\s*/i, "")
    .replace(/^Error:\s*/i, "")
    .trim() || fallback;
}

function DailyThumbnail({ paper, bridge }: { paper: DailyPaper; bridge: ResearchDeskBridge }) {
  const [figureUrl, setFigureUrl] = useState(() => peekDailyFigure(bridge, paper.arxiv_id));
  const holder = useRef<HTMLDivElement | null>(null);
  useEffect(() => {
    const cached = peekDailyFigure(bridge, paper.arxiv_id);
    setFigureUrl(cached);
    const node = holder.current;
    if (cached || !node || !paper.arxiv_id || !bridge.getDailyFigure) return;
    let disposed = false;
    let unsubscribe: (() => void) | undefined;
    const observer = new IntersectionObserver((entries) => {
      if (disposed) return;
      const entry = entries.find(item => item.target === node);
      if (!entry?.isIntersecting) { unsubscribe?.(); unsubscribe = undefined; return; }
      if (unsubscribe) return;
      const visible = entry.boundingClientRect.top < window.innerHeight && entry.boundingClientRect.bottom > 0;
      unsubscribe = subscribeDailyFigure(bridge, paper.arxiv_id, true, visible ? 0 : 1, (url) => {
        if (!disposed && url) { setFigureUrl(url); observer.disconnect(); }
      });
    }, { rootMargin: "160px" });
    observer.observe(node);
    return () => { disposed = true; unsubscribe?.(); observer.disconnect(); };
  }, [bridge, paper.arxiv_id]);
  return <div className="daily-paper-thumb" ref={holder}>
    <span className="daily-paper-thumb-fallback">{paper.categories[0] || "Paper"}</span>
    {figureUrl && <img src={figureUrl} alt="" decoding="async" onError={() => { forgetDailyFigure(bridge, paper.arxiv_id); setFigureUrl(""); }} />}
  </div>;
}

function DailyDiscovery({ storageKey, projectId, initialMode = "latest", bridge, libraries, loadingLibraries, onImported }: { storageKey: string; projectId?: string | null; initialMode?: DailyDiscoveryMode | "conference"; bridge: ResearchDeskBridge; libraries: ResearchLibrary[]; loadingLibraries: boolean; onImported: () => Promise<void> }) {
  const { t } = useUISettings();
  const [saved] = useState(() => readDiscoverySnapshot(window.localStorage, storageKey));
  const [mode, setMode] = useState<DailyDiscoveryMode | "conference">(saved?.mode || initialMode);
  const [range, setRange] = useState<DailyDiscoveryRange>(saved?.range || "7d");
  const [topic, setTopic] = useState<DailyDiscoveryTopic>(saved?.topic || "all");
  const [searchKind, setSearchKind] = useState<"quick" | "deep">(saved?.searchKind || "quick");
  const [query, setQuery] = useState(saved?.query || "");
  const [submittedQuery, setSubmittedQuery] = useState(saved?.submittedQuery || "");
  const [deepResponse, setDeepResponse] = useState<DeepPaperSearchResponse | null>(saved?.deepResponse || null);
  const [targetLibraryId, setTargetLibraryId] = useState(saved?.targetLibraryId || "");
  const [response, setResponse] = useState<DailyDiscoveryResponse | null>(saved?.response || null);
  const [loading, setLoading] = useState(false);
  const [added, setAdded] = useState<Set<string>>(new Set());
  const [adding, setAdding] = useState<string | null>(null);
  const [previewPaper, setPreviewPaper] = useState<DailyPaper | null>(null);
  const [error, setError] = useState(saved?.deepResponse?.warning || saved?.response?.warning || "");
  const [reasons, setReasons] = useState<Record<string, string>>(saved?.reasons || {});
  const [newLibraryName, setNewLibraryName] = useState("");
  const [newLibraryOpen, setNewLibraryOpen] = useState(false);
  const [creatingLibrary, setCreatingLibrary] = useState(false);
  const [persistenceError, setPersistenceError] = useState("");
  const alive = useRef(true);
  useEffect(() => { alive.current = true; return () => { alive.current = false; }; }, []);
  const savedPaperRequestId = useRef(0);
  const feedRequestId = useRef(0);
  const deepRequestId = useRef(0);
  const responseRef = useRef<DailyDiscoveryResponse | null>(saved?.response || null);
  const cachedFeedKey = useRef(saved?.response ? JSON.stringify([saved.mode, saved.range, saved.topic, saved.searchKind, saved.submittedQuery]) : "");
  useEffect(() => {
    try {
      writeDiscoverySnapshot(window.localStorage, storageKey, { mode, range, topic, searchKind, query, submittedQuery, targetLibraryId, response, deepResponse, reasons });
      setPersistenceError("");
    } catch { setPersistenceError(t("Discovery could not be saved on this device. Keep this page open or free storage before leaving.")); }
  }, [storageKey, mode, range, topic, searchKind, query, submittedQuery, targetLibraryId, response, deepResponse, reasons, t]);
  useEffect(() => () => { deepRequestId.current += 1; }, []);
  useEffect(() => { if (!libraries.some((item) => item.id === targetLibraryId) && libraries[0]) setTargetLibraryId(libraries[0].id); }, [libraries, targetLibraryId]);
  const targetLibrary = useMemo(() => libraries.find((library) => library.id === targetLibraryId), [libraries, targetLibraryId]);
  useEffect(() => {
    let active = true;
    const request = ++savedPaperRequestId.current;
    setAdded(new Set());
    if (targetLibraryId && bridge.listLibraryPapers) void bridge.listLibraryPapers(targetLibraryId).then((papers) => {
      if (active && request === savedPaperRequestId.current) setAdded(new Set(papers.map((paper) => discoveryPaperKey(paper))));
    }).catch((cause) => { if (active) setError(readableError(cause, "Saved papers could not be checked.")); });
    return () => { active = false; };
  }, [bridge, targetLibraryId]);
  const searchActive = Boolean(submittedQuery);
  const loadFeed = useCallback(async (forceRefresh = false) => {
    if (mode === "conference" || (searchKind === "deep" && submittedQuery)) return;
    const cacheKey = JSON.stringify([mode, range, topic, searchKind, submittedQuery]);
    if (!forceRefresh && cachedFeedKey.current === cacheKey && responseRef.current) return;
    const requestId = ++feedRequestId.current;
    setLoading(true);
    setError("");
    try {
      const nextResponse = await bridge.discoverDailyPapers({ mode, range, topic, query: searchKind === "quick" ? submittedQuery : "", limit: 60, forceRefresh });
      if (requestId !== feedRequestId.current) return;
      cachedFeedKey.current = cacheKey;
      responseRef.current = nextResponse;
      setResponse(nextResponse);
      if (nextResponse.warning) setError(nextResponse.warning);
    } catch (discoverError) {
      if (requestId !== feedRequestId.current) return;
      const message = readableError(discoverError, "The daily paper feed could not be refreshed.");
      setError(responseRef.current ? `${message} Showing the previous results.` : message);
    } finally {
      if (requestId === feedRequestId.current) setLoading(false);
    }
  }, [bridge, mode, range, searchKind, submittedQuery, topic]);

  useEffect(() => {
    void loadFeed(false);
    return () => { feedRequestId.current += 1; };
  }, [loadFeed]);

  const visiblePapers = response?.papers ?? [];

  async function submitSearch() {
    const nextQuery = query.trim();
    if (!nextQuery) {
      clearSearch();
      return;
    }
    if (searchKind === "quick") {
      setDeepResponse(null);
      if (nextQuery === submittedQuery) void loadFeed(true);
      else setSubmittedQuery(nextQuery);
      return;
    }
    const requestId = ++deepRequestId.current;
    setSubmittedQuery(nextQuery);
    setDeepResponse(null);
    setLoading(true);
    setError("");
    try {
      const next = await bridge.deepSearchPapers({ prompt: nextQuery, topic, limit: 18 });
      if (requestId !== deepRequestId.current) return;
      setDeepResponse(next);
      if (next.warning) setError(next.warning);
    } catch (searchError) {
      if (requestId !== deepRequestId.current) return;
      setError(readableError(searchError, "Deep paper search failed."));
    } finally {
      if (requestId === deepRequestId.current) setLoading(false);
    }
  }

  function clearSearch() {
    feedRequestId.current += 1;
    deepRequestId.current += 1;
    setQuery("");
    setSubmittedQuery("");
    setDeepResponse(null);
    setError("");
    setLoading(false);
  }

  function changeQuery(value: string) {
    setQuery(value);
    // Emptying the box is the way back to the live feed. Without this the
    // completed search stays submitted, so Latest / Trending and the range
    // control stay locked until the search is cleared explicitly.
    if (!value.trim() && submittedQuery) clearSearch();
  }

  function changeSearchKind(next: "quick" | "deep") {
    if (next === searchKind) return;
    feedRequestId.current += 1;
    deepRequestId.current += 1;
    setSearchKind(next);
    setSubmittedQuery("");
    setDeepResponse(null);
    setError("");
    setLoading(false);
  }

  async function add(paper: DailyPaper | AcademicSearchResult) {
    if (!targetLibraryId) return;
    const key = discoveryPaperKey(paper);
    savedPaperRequestId.current += 1;
    setAdding(key);
    setError("");
    try {
      await (bridge as SelectionBridge).addLibraryPaper(targetLibraryId, paper, projectId ? {
        ...(reasons[key]?.trim() ? { reason: reasons[key].trim() } : {}),
        discovery: discoveryProvenance({ mode, range, topic, searchKind, submittedQuery, response, deepResponse }, paper),
      } : undefined);
      if (!alive.current) return;
      setAdded((current) => new Set(current).add(key));
      await onImported();
    } catch (addError) {
      setError(readableError(addError, "The paper could not be saved."));
    } finally {
      setAdding(null);
    }
  }

  async function createLibrary() {
    if (!newLibraryName.trim()) return;
    setCreatingLibrary(true); setError("");
    try {
      const created = await bridge.createLibrary({ projectId, name: newLibraryName.trim() });
      if (!alive.current) return;
      await onImported();
      if (!alive.current) return;
      setTargetLibraryId(created.id); setNewLibraryName(""); setNewLibraryOpen(false);
    } catch (cause) { setError(readableError(cause, "The library could not be created.")); }
    finally { setCreatingLibrary(false); }
  }

  return <section className="library-page daily-page">
    <div className="daily-feed-toolbar daily-conference-toolbar">
      <div className="daily-live-controls">
      <Tabs value={searchActive ? "" : mode} onChange={(value) => setMode(value as typeof mode)} label="Paper feed mode" variant="segmented" className="daily-mode-tabs">
        <Tab value="latest" icon={<Clock3 size={12} />} disabled={searchActive} title={searchActive ? "Clear search to return to the daily feed" : "Newest arXiv submissions"}>Latest</Tab>
        <Tab value="trending" icon={<Flame size={12} />} disabled={searchActive} title={searchActive ? "Clear search to return to the daily feed" : "Trending community papers"}>Trending</Tab>
      </Tabs>
      <div className="daily-range-control" aria-label="Publication range">{DAILY_RANGES.map((item) => <button key={item.id} disabled={mode === "conference" || (searchActive && searchKind === "deep")} className={range === item.id && mode !== "conference" && !(searchActive && searchKind === "deep") ? "active" : ""} title={searchActive && searchKind === "deep" ? "Deep search uses the time range inferred from your request" : item.id === "all" ? "Search the whole archive, not just the last 90 days" : ""} onClick={() => setRange(item.id)}>{item.label}</button>)}</div>
      </div>
      <button className={mode === "conference" ? "secondary-button conference-mode-button active" : "secondary-button conference-mode-button"} aria-pressed={mode === "conference"} disabled={searchActive} title={searchActive ? "Clear search before switching discovery modes" : "Search official conference catalogs"} onClick={() => setMode("conference")}><GraduationCap size={16} />Top conference search</button>
      {mode !== "conference" && !searchActive && <button className="secondary-button daily-refresh" disabled={loading} onClick={() => void loadFeed(true)}>{loading ? <LoaderCircle className="spin" size={14} /> : <RefreshCw size={14} />}Refresh</button>}
      <label className="daily-save-target">Save to<select value={targetLibraryId} disabled={loadingLibraries} onChange={(event) => setTargetLibraryId(event.target.value)}>{libraries.map((library) => <option key={library.id} value={library.id}>{library.name}</option>)}</select></label>
      <button className="secondary-button" aria-expanded={newLibraryOpen} onClick={() => setNewLibraryOpen((current) => !current)}>{t("New library")}</button>
    </div>
    {persistenceError && <InlineNotice tone="warning">{persistenceError}</InlineNotice>}
    {newLibraryOpen && <div className="daily-create-library"><label>{t("New discovery library")}<input autoFocus aria-label={t("New discovery library")} value={newLibraryName} onChange={(event) => setNewLibraryName(event.target.value)} placeholder={t("Library name")} onKeyDown={(event) => { if (event.key === "Enter" && !event.nativeEvent.isComposing) void createLibrary(); }} /></label><button className="secondary-button" disabled={creatingLibrary || !newLibraryName.trim()} onClick={() => void createLibrary()}>{t("Create library here")}</button></div>}
    <FilterGroup label="AI research topic" className="daily-topic-filter">{DAILY_TOPICS.map((item) => <FilterButton key={item.id} active={topic === item.id} disabled={searchActive && searchKind === "deep"} title={searchActive && searchKind === "deep" ? "Clear deep search to change its topic constraint" : item.description} onClick={() => setTopic(item.id)}>{item.label}</FilterButton>)}</FilterGroup>
    {mode === "conference" ? <ConferenceDiscovery storageKey={`${storageKey}:conference`} projectId={projectId} bridge={bridge} targetLibraryId={targetLibraryId} topic={topic} onImported={onImported} /> : <>
    <div className={searchKind === "deep" ? "daily-search-panel deep" : "daily-search-panel"}>
      <Tabs value={searchKind} onChange={(value) => changeSearchKind(value as typeof searchKind)} label="Paper search type" variant="segmented" className="daily-search-kind">
        <Tab value="quick" icon={<Search size={12} />}>Quick search</Tab>
        <Tab value="deep" icon={<Sparkle size={12} />}>Deep search</Tab>
      </Tabs>
      <div className="daily-search-input-row">{searchKind === "quick" ? <input value={query} onChange={(event) => changeQuery(event.target.value)} onKeyDown={(event) => event.key === "Enter" && void submitSearch()} placeholder="Search recent papers by keyword, title, author, or topic" /> : <textarea value={query} onChange={(event) => changeQuery(event.target.value)} onKeyDown={(event) => (event.metaKey || event.ctrlKey) && event.key === "Enter" && void submitSearch()} placeholder="Describe the field, problem, methods, evaluation setting, time range, and anything to exclude. The more specific you are, the better the match." />}
        <button className="daily-search-send" disabled={loading || !query.trim()} onClick={() => void submitSearch()} title={searchKind === "deep" ? "Deep search" : "Search"} aria-label={searchKind === "deep" ? "Deep search" : "Search"}>{loading ? <LoaderCircle className="spin" size={14} /> : <ArrowUp size={15} />}</button>
      </div>
      {(searchKind !== "deep" || searchActive) && <div className="daily-search-meta"><span>{`${searchKind === "deep" ? deepResponse?.results.length ?? 0 : visiblePapers.length} papers`}{submittedQuery ? ` · “${submittedQuery}”` : ""}{searchKind === "quick" && response ? ` · ${response.cached ? "cached" : "live"} · updated ${formatFeedTime(response.fetched_at)}` : ""}{searchKind === "deep" && deepResponse ? ` · ${deepResponse.providers.join(" + ") || "metadata search"} · updated ${formatFeedTime(deepResponse.fetched_at)}` : ""}{searchKind === "quick" && searchActive && response?.options?.topic === "all" && topic !== "all" ? " · title search across all topics" : ""}</span></div>}
    </div>
    {error && <InlineNotice tone={deepResponse ? "warning" : "danger"} className={deepResponse ? "daily-search-warning" : "library-error"}>{error}</InlineNotice>}
    {searchKind === "deep" && searchActive ? <DeepSearchResults response={deepResponse} loading={loading} error={error} targetLibrary={targetLibrary} added={added} adding={adding} onSave={add} reasons={reasons} onReason={(key, reason) => setReasons((current) => ({ ...current, [key]: reason }))} /> : loading && !response ? <LoadingState /> : error && !response ? <StateView tone="error" className="daily-empty daily-feed-failed" icon={<RefreshCw size={28} />} title="Could not load the live feed" description="arXiv may be responding slowly. Your library is unaffected." action={<button className="secondary-button" onClick={() => void loadFeed(true)}><RefreshCw size={14} />Retry</button>} /> : !visiblePapers.length ? <StateView className="daily-empty" icon={<Calendar size={28} />} title="No papers found" description="Try another topic, expand the date range, or use a broader keyword." /> : <div className="daily-paper-list">{visiblePapers.map((paper) => {
      const key = discoveryPaperKey(paper);
      const isAdded = added.has(key);
      const isAdding = adding === key;
      return <article
        className="daily-paper-row"
        key={key}
        role="button"
        tabIndex={0}
        title={t("Open paper preview")}
        aria-label={`${t("Open paper preview")}: ${paper.title}`}
        onClick={(event) => {
          if ((event.target as HTMLElement).closest("a, button, input, textarea, select, label")) return;
          setPreviewPaper(paper);
        }}
        onKeyDown={(event) => {
          if (event.target !== event.currentTarget) return;
          if (event.key === "Enter" || event.key === " ") {
            event.preventDefault();
            setPreviewPaper(paper);
          }
        }}
      >
        <div className="daily-paper-content">
          <div className="daily-paper-title"><h2>{paper.title}</h2>{paper.url && <a href={paper.url} target="_blank" rel="noreferrer" title="Open paper"><ExternalLink size={13} /></a>}<button className={isAdded ? "secondary-button imported" : "outline-button"} disabled={isAdded || Boolean(adding) || !targetLibrary} onClick={() => void add(paper)}>{isAdded ? <Check size={14} /> : isAdding ? <LoaderCircle className="spin" size={14} /> : <Plus size={14} />}{isAdded ? "Saved" : isAdding ? "Saving" : "Save"}</button></div>
          <p className="daily-paper-meta"><span className="daily-paper-date">{formatPaperDate(paper.published_at)}</span><span className="daily-paper-source">{paper.source === "hugging-face" ? "HF Daily" : "arXiv"}</span><span className="daily-paper-authors">{paper.authors.slice(0, 4).join(", ")}{paper.authors.length > 4 ? " et al." : ""}</span></p>
          <small>{paper.abstract || "No abstract available."}</small>
          <label>{t("Project selection reason")}<input aria-label={`${t("Project selection reason")}: ${paper.title}`} value={reasons[key] || ""} onChange={(event) => setReasons((current) => ({ ...current, [key]: event.target.value }))} placeholder={t("Your reason for selecting this paper")} /></label>
          <div className="daily-paper-signals">{paper.categories.slice(0, 3).map((category) => <span key={category}>{category}</span>)}{paper.upvotes > 0 && <span><Flame size={11} />{paper.upvotes}</span>}{paper.github_url && <a href={paper.github_url} target="_blank" rel="noreferrer"><Code2 size={11} />{paper.github_stars > 0 ? paper.github_stars : "Code"}</a>}</div>
        </div>
        <DailyThumbnail paper={paper} bridge={bridge} />
      </article>;
    })}</div>}
    {previewPaper && <DailyPaperPreview
      paper={previewPaper}
      bridge={bridge}
      canSave={Boolean(targetLibrary)}
      isAdded={added.has(discoveryPaperKey(previewPaper))}
      isAdding={adding === (discoveryPaperKey(previewPaper))}
      onAdd={() => void add(previewPaper)}
      onClose={() => setPreviewPaper(null)}
    />}
    </>}
  </section>;
}

function DailyPaperPreview({ paper, bridge, canSave, isAdded, isAdding, onAdd, onClose }: {
  paper: DailyPaper;
  bridge: ResearchDeskBridge;
  canSave: boolean;
  isAdded: boolean;
  isAdding: boolean;
  onAdd: () => void;
  onClose: () => void;
}) {
  const { t } = useUISettings();
  const [figureUrl, setFigureUrl] = useState(() => peekDailyFigure(bridge, paper.arxiv_id));
  useEffect(() => {
    setFigureUrl(peekDailyFigure(bridge, paper.arxiv_id));
    return subscribeDailyFigure(bridge, paper.arxiv_id, false, -1, (url) => { if (url) setFigureUrl(url); });
  }, [bridge, paper.arxiv_id]);
  const authors = paper.authors.length ? paper.authors.join(", ") : t("Unknown authors");
  return <Dialog open onClose={onClose} size="lg" className="daily-paper-preview-dialog" ariaLabelledBy="daily-paper-preview-title">
    <header className="daily-paper-preview-header">
      <div>
        <span className="eyebrow">{paper.source === "hugging-face" ? "HF Daily" : "arXiv"}{paper.year ? ` · ${paper.year}` : ""}</span>
        <h2 id="daily-paper-preview-title">{paper.title}</h2>
        <p className="daily-paper-preview-authors">{authors}</p>
      </div>
      <button className="icon-button" onClick={onClose} title={t("Close preview")} aria-label={t("Close preview")}><X size={16} /></button>
    </header>
    <div className="daily-paper-preview-body">
      <div className="daily-paper-preview-figure">
        <span className="daily-paper-thumb-fallback">{paper.categories[0] || "Paper"}</span>
        {figureUrl && <img src={figureUrl} alt={t("Figure preview for {title}").replace("{title}", paper.title)} onError={() => {
          forgetDailyFigure(bridge, paper.arxiv_id, false);
          const fallback = peekDailyFigure(bridge, paper.arxiv_id);
          if (fallback === figureUrl) { forgetDailyFigure(bridge, paper.arxiv_id); setFigureUrl(""); }
          else setFigureUrl(fallback);
        }} />}
      </div>
      <div className="daily-paper-preview-copy">
        <div className="daily-paper-preview-meta">
          <span>{formatPaperDate(paper.published_at)}</span>
          {paper.venue && <span>{paper.venue}</span>}
          {paper.upvotes > 0 && <span><Flame size={11} />{paper.upvotes}</span>}
          {paper.citation_count > 0 && <span>{paper.citation_count.toLocaleString()} citations</span>}
        </div>
        <div className="daily-paper-preview-tags">
          {paper.categories.map((category) => <span key={category}>{category}</span>)}
        </div>
        <p className="daily-paper-preview-abstract">{paper.abstract || t("No abstract available.")}</p>
      </div>
    </div>
    <footer className="daily-paper-preview-actions">
      <div>
        {paper.url && <a className="secondary-button" href={paper.url} target="_blank" rel="noreferrer"><ExternalLink size={14} />{t("Open paper")}</a>}
        {paper.pdf_url && <a className="secondary-button" href={paper.pdf_url} target="_blank" rel="noreferrer"><FileText size={14} />PDF</a>}
        {paper.github_url && <a className="secondary-button" href={paper.github_url} target="_blank" rel="noreferrer"><Code2 size={14} />Code</a>}
      </div>
      <button className={isAdded ? "secondary-button imported" : "primary-button"} disabled={isAdded || isAdding || !canSave} onClick={onAdd}>
        {isAdded ? <Check size={14} /> : isAdding ? <LoaderCircle className="spin" size={14} /> : <Plus size={14} />}
        {isAdded ? t("Saved") : isAdding ? t("Saving") : t("Save")}
      </button>
    </footer>
  </Dialog>;
}

function DeepSearchResults({ response, loading, error, targetLibrary, added, adding, onSave, reasons, onReason }: {
  response: DeepPaperSearchResponse | null;
  loading: boolean;
  error: string;
  targetLibrary: ResearchLibrary | undefined;
  added: Set<string>;
  adding: string | null;
  onSave: (paper: AcademicSearchResult) => Promise<void>;
  reasons: Record<string, string>;
  onReason: (key: string, reason: string) => void;
}) {
  const { t } = useUISettings();
  if (loading && !response) return <StateView tone="loading" className="daily-deep-progress" icon={<LoaderCircle className="spin" size={22} />} title="Expanding and matching your research request" description="Understanding methods and domains, searching multiple scholarly indexes, deduplicating, then reranking titles and abstracts." />;
  if (error && !response) return <StateView tone="error" className="daily-empty daily-feed-failed" icon={<Search size={28} />} title="Deep search could not finish" description="Check the model configuration or try a shorter, more specific research request." />;
  if (!response?.results.length) return <StateView className="daily-empty" icon={<Search size={28} />} title="No deep-search results yet" description="Describe the research problem, preferred methods, and evaluation setting, then start a deep search." />;
  const planTags = [
    ...response.plan.domains.map((value) => ({ kind: "Domain", value })),
    ...response.plan.methods.map((value) => ({ kind: "Method", value })),
    ...response.plan.tasks.map((value) => ({ kind: "Task", value })),
  ].slice(0, 12);
  return <>
    <section className="daily-search-plan"><div><span className="eyebrow">Search interpretation</span><strong>{response.plan.research_problem}</strong><p>Matches are based on titles and abstracts. Full-paper claims have not been verified.</p></div><div className="daily-search-plan-tags">{planTags.map((tag) => <span key={`${tag.kind}:${tag.value}`}><small>{tag.kind}</small>{tag.value}</span>)}{response.plan.year_range && <span><small>Years</small>{response.plan.year_range.start ?? "Any"}–{response.plan.year_range.end ?? "Any"}</span>}</div><details><summary>{response.plan.queries.length} expanded queries</summary><ul>{response.plan.queries.map((item) => <li key={item}>{item}</li>)}</ul></details></section>
    <div className="daily-paper-list deep-paper-list">{response.results.map((result) => {
      const paper = result.paper;
      const key = discoveryPaperKey(paper);
      const isAdded = added.has(key);
      const isAdding = adding === key;
      return <article className="daily-paper-row" key={key}>
        <div className="daily-paper-date"><strong>{paper.year || "—"}</strong><span>{paper.source?.split(",").join(" + ") || "Index"}</span></div>
        <div className="daily-paper-content"><div className="daily-paper-title"><h2>{paper.title}</h2>{paper.url && <a href={paper.url} target="_blank" rel="noreferrer" title="Open paper"><ExternalLink size={13} /></a>}</div><p>{paper.authors.slice(0, 4).join(", ")}{paper.authors.length > 4 ? " et al." : ""}{paper.venue ? ` · ${paper.venue}` : ""}</p><div className={`deep-match-reason ${result.relevance}`}><strong>{result.relevance === "strong" ? "Strong match" : result.relevance === "related" ? "Related method" : "Background"}</strong><span>{result.reason}</span></div><small>{paper.abstract || "No abstract available."}</small><div className="daily-paper-signals">{result.matched_terms.map((term) => <span key={term}>{term}</span>)}{paper.citation_count > 0 && <span>{paper.citation_count.toLocaleString()} citations</span>}{paper.pdf_url && <a href={paper.pdf_url} target="_blank" rel="noreferrer"><FileText size={11} />PDF</a>}</div></div>
        <label>{t("Project selection reason")}<input aria-label={`${t("Project selection reason")}: ${paper.title}`} value={reasons[key] || ""} onChange={(event) => onReason(key, event.target.value)} /></label>
        <button className={isAdded ? "secondary-button imported" : "outline-button"} disabled={isAdded || Boolean(adding) || !targetLibrary} onClick={() => void onSave(paper)}>{isAdded ? <Check size={14} /> : isAdding ? <LoaderCircle className="spin" size={14} /> : <Plus size={14} />}{isAdded ? "Saved" : isAdding ? "Saving" : "Save"}</button>
      </article>;
    })}</div>
  </>;
}

function formatPaperDate(value: string) {
  const date = new Date(value);
  return Number.isNaN(date.getTime()) ? "—" : date.toLocaleDateString("en-US", { month: "short", day: "numeric" });
}

function formatFeedTime(value: string) {
  const date = new Date(value);
  return Number.isNaN(date.getTime()) ? "now" : date.toLocaleTimeString(undefined, { hour: "2-digit", minute: "2-digit" });
}

function LoadingState() {
  return <StateView tone="loading" className="library-loading" icon={<LoaderCircle className="spin" size={18} />} title="Loading research records…" />;
}
