import { useEffect, useMemo, useRef, useState } from "react";
import { Archive, ArchiveRestore, BookOpen, FolderOpen, MoreVertical, Pencil, Plus, Trash, X } from "lucide-react";
import { useUISettings } from "./i18n";
import { Dialog } from "./Dialog";
import { MenuDivider, MenuItem, MenuSurface } from "./Menu";
import { workspaceName } from "./workspace-name";
import WorkspaceMenuActions from "./WorkspaceMenuActions";
import { orderSidebarIds, type SidebarOrder, type SidebarOrderGroup } from "./sidebar-order";

export default function ProjectSidebar({ projects, archivedProjects, workspaces, order, onReorder, activeProjectId, activeWorkspaceId, disabled, onNewProject, onNewWorkspace, onRenameProject, onArchiveProject, onRemoveProject, onChangeProjectWorkspace, onTransferProject, onOpenProjectResearch, onOpenWorkspace, onRenameWorkspace, onDeleteWorkspace, filterError }: {
  projects: ResearchProject[];
  archivedProjects: ResearchProject[];
  workspaces: ProjectWorkspace[];
  order: SidebarOrder;
  onReorder: (group: SidebarOrderGroup, sourceId: string, targetId: string, after: boolean, parentId?: string) => void;
  activeProjectId: string | null;
  activeWorkspaceId: string | null;
  disabled: boolean;
  onNewProject: () => void;
  onNewWorkspace: (projectId: string, kind?: ProjectWorkspaceKind) => void;
  onRenameProject: (projectId: string, name: string) => Promise<void>;
  onArchiveProject: (project: ResearchProject, archived: boolean) => void;
  onRemoveProject: (project: ResearchProject) => void;
  onChangeProjectWorkspace: (project: ResearchProject) => void;
  onTransferProject?: (project: ResearchProject) => void;
  onOpenProjectResearch?: (project: ResearchProject) => void;
  onOpenWorkspace: (workspace: ProjectWorkspace) => void;
  onRenameWorkspace: (workspace: ProjectWorkspace) => void;
  onDeleteWorkspace: (workspace: ProjectWorkspace) => void;
  filterError?: string;
}) {
  const { t } = useUISettings();
  const [expanded, setExpanded] = useState<Set<string>>(new Set());
  const [projectMenu, setProjectMenu] = useState<{ project: ResearchProject; cursor?: { x: number; y: number } } | null>(null);
  const [workspaceMenu, setWorkspaceMenu] = useState<{ workspace: ProjectWorkspace; cursor: { x: number; y: number } } | null>(null);
  const [showArchivedProjects, setShowArchivedProjects] = useState(false);
  const [editingProjectId, setEditingProjectId] = useState<string | null>(null);
  const [projectNameDraft, setProjectNameDraft] = useState("");
  const [renaming, setRenaming] = useState(false);
  const [renameError, setRenameError] = useState("");
  const projectAnchorRef = useRef<HTMLElement | null>(null);
  const renameInFlightRef = useRef(false);
  const dragRef = useRef<{ group: SidebarOrderGroup; id: string; parentId?: string } | null>(null);
  const suppressClickUntil = useRef(0);
  const [draggingItem, setDraggingItem] = useState<string | null>(null);
  const [dropTarget, setDropTarget] = useState<string | null>(null);
  const [reorderAnnouncement, setReorderAnnouncement] = useState("");
  const orderedProjects = useMemo(() => orderSidebarIds(projects, order.projects), [projects, order.projects]);
  const orderedArchivedProjects = useMemo(() => orderSidebarIds(archivedProjects, order.archivedProjects), [archivedProjects, order.archivedProjects]);

  function startDrag(event: React.DragEvent<HTMLElement>, group: SidebarOrderGroup, id: string, parentId?: string) {
    dragRef.current = { group, id, parentId };
    setDraggingItem(group === "workspaces" ? `${group}:${parentId}:${id}` : `${group}:${id}`);
    suppressClickUntil.current = Date.now() + 500;
    event.dataTransfer.effectAllowed = "move";
    event.dataTransfer.setData("text/plain", JSON.stringify({ group, id, parentId }));
  }

  function overDropTarget(event: React.DragEvent<HTMLElement>, id: string, group: SidebarOrderGroup, parentId?: string) {
    const drag = dragRef.current;
    if (!drag || drag.group !== group || drag.parentId !== parentId || drag.id === id) return;
    event.preventDefault();
    event.dataTransfer.dropEffect = "move";
    setDropTarget(group === "workspaces" ? `${group}:${parentId}:${id}` : `${group}:${id}`);
  }

  function dropOn(event: React.DragEvent<HTMLElement>, id: string, group: SidebarOrderGroup, parentId?: string) {
    const drag = dragRef.current;
    if (!drag || drag.group !== group || drag.parentId !== parentId || drag.id === id) return;
    event.preventDefault();
    event.stopPropagation();
    const rect = event.currentTarget.getBoundingClientRect();
    onReorder(group, drag.id, id, event.clientY >= rect.top + rect.height / 2, parentId);
    dragRef.current = null;
    setDropTarget(null);
    suppressClickUntil.current = Date.now() + 500;
  }

  function finishDrag() { dragRef.current = null; setDraggingItem(null); setDropTarget(null); }

  function moveWithKeyboard(event: React.KeyboardEvent<HTMLElement>, ids: string[], id: string, group: SidebarOrderGroup, parentId?: string) {
    if (!event.altKey || (event.key !== "ArrowUp" && event.key !== "ArrowDown")) return;
    const index = ids.indexOf(id);
    const target = ids[index + (event.key === "ArrowUp" ? -1 : 1)];
    if (!target) return;
    event.preventDefault();
    onReorder(group, id, target, event.key === "ArrowDown", parentId);
    setReorderAnnouncement(t("Moved to position {position} of {count}.", { position: index + (event.key === "ArrowUp" ? 0 : 2), count: ids.length }));
  }

  useEffect(() => {
    if (!projects.length) return;
    setExpanded((current) => {
      const next = new Set(current);
      if (activeProjectId) next.add(activeProjectId);
      if (!next.size) next.add(projects[0].id);
      return next;
    });
  }, [activeProjectId, projects]);

  function toggleProject(id: string) {
    setExpanded((current) => {
      const next = new Set(current);
      if (next.has(id)) next.delete(id); else next.add(id);
      return next;
    });
  }

  function beginRename(project: ResearchProject) {
    if (disabled) return;
    setRenameError("");
    setProjectNameDraft(project.name);
    setEditingProjectId(project.id);
  }

  async function finishRename(project: ResearchProject) {
    if (editingProjectId !== project.id || renameInFlightRef.current) return;
    const name = projectNameDraft.replace(/\s+/g, " ").trim();
    setEditingProjectId(null);
    if (!name || name === project.name) return;
    renameInFlightRef.current = true;
    setRenaming(true);
    try {
      await onRenameProject(project.id, name);
      setRenameError("");
    } catch (error) {
      setRenameError(t("Could not rename project: {error}", { error: String(error) }));
    } finally {
      renameInFlightRef.current = false;
      setRenaming(false);
    }
  }

  return <section className="sidebar-group projects-group work-group">
    <div className="work-heading">
      <span>{t("Projects")}</span>
      <div className="work-heading-actions">
        <button className="work-new-project" onClick={onNewProject} title={t("New project")} aria-label={t("New project")} disabled={disabled}>
          <Plus size={15} />
        </button>
      </div>
    </div>

    <div className="project-tree work-tree">
      {orderedProjects.map((project) => {
          const projectWorkspaces = orderSidebarIds(workspaces.filter((workspace) => workspace.project_id === project.id), order.workspaces[project.id]);
          const projectIds = orderedProjects.map((item) => item.id);
          const isExpanded = expanded.has(project.id);
          const menuOpen = projectMenu?.project.id === project.id;
          return <div className="project-node" key={project.id}>
            <div className="project-tree-row" onContextMenu={(event) => {
              event.preventDefault();
              projectAnchorRef.current = null;
              setProjectMenu({ project, cursor: { x: event.clientX, y: event.clientY } });
            }}>
              {editingProjectId === project.id
                ? <span className="project-rename-field"><input autoFocus value={projectNameDraft} aria-label={t("Project name")} maxLength={100} disabled={renaming} onChange={(event) => setProjectNameDraft(event.target.value)} onBlur={() => void finishRename(project)} onKeyDown={(event) => {
                  if (event.key === "Enter") {
                    event.preventDefault();
                    void finishRename(project);
                  }
                  if (event.key === "Escape") {
                    event.preventDefault();
                    setRenameError("");
                    setEditingProjectId(null);
                  }
                }} /></span>
                : <button className={`project-select${draggingItem === `projects:${project.id}` ? " sidebar-dragging" : ""}${dropTarget === `projects:${project.id}` ? " sidebar-drop-target" : ""}`} draggable onDragStart={(event) => startDrag(event, "projects", project.id)} onDragEnd={finishDrag} onDragOver={(event) => overDropTarget(event, project.id, "projects")} onDrop={(event) => dropOn(event, project.id, "projects")} onKeyDown={(event) => moveWithKeyboard(event, projectIds, project.id, "projects")} aria-keyshortcuts="Alt+ArrowUp Alt+ArrowDown" onClick={() => { if (Date.now() >= suppressClickUntil.current) toggleProject(project.id); }} title={`${project.name}${project.workspace_path ? ` · ${project.workspace_path}` : ""} · ${t("Drag to reorder. Use Alt+ArrowUp or Alt+ArrowDown.")}`} aria-expanded={isExpanded}><span className="project-name">{project.name}</span>{projectWorkspaces.length > 0 && <small>{projectWorkspaces.length}</small>}</button>}
              <span className="project-row-actions">
                <button onClick={() => onNewWorkspace(project.id)} title={t("New workspace")} aria-label={t("New workspace")} disabled={disabled}><Plus size={13} /></button>
                <button className={menuOpen ? "project-more-button active" : "project-more-button"} onClick={(event) => { projectAnchorRef.current = event.currentTarget; setProjectMenu((current) => current?.project.id === project.id ? null : { project }); }} title={t("More project actions")} aria-label={t("More project actions")} aria-haspopup="menu" aria-expanded={menuOpen} disabled={disabled}><MoreVertical size={14} /></button>
              </span>
              <MenuSurface open={menuOpen} onClose={() => setProjectMenu(null)} anchorRef={projectAnchorRef} cursor={projectMenu?.cursor} placement="bottom-end" width={300} className="project-more-menu" ariaLabel={t("Project actions")}>
                <MenuItem icon={<Plus size={18} strokeWidth={1.7} />} onClick={() => { setProjectMenu(null); onNewWorkspace(project.id); }} disabled={disabled}>{t("New workspace")}</MenuItem>
                <MenuItem icon={<FolderOpen size={18} strokeWidth={1.7} />} onClick={() => { setProjectMenu(null); onChangeProjectWorkspace(project); }} disabled={disabled}>{t("Change project folder")}</MenuItem>
                {onTransferProject && <MenuItem icon={<FolderOpen size={18} strokeWidth={1.7} />} onClick={() => { setProjectMenu(null); onTransferProject(project); }} disabled={disabled}>{t("Transfer project…")}</MenuItem>}
                {onOpenProjectResearch && <MenuItem icon={<BookOpen size={18} strokeWidth={1.7} />} onClick={() => { setProjectMenu(null); onOpenProjectResearch(project); }}>{t("Project research")}</MenuItem>}
                <MenuItem icon={<Pencil size={18} strokeWidth={1.7} />} onClick={() => { setProjectMenu(null); beginRename(project); }} disabled={disabled}>{t("Rename")}</MenuItem>
                <MenuItem icon={<Archive size={18} strokeWidth={1.7} />} onClick={() => { setProjectMenu(null); onArchiveProject(project, true); }} disabled={disabled}>{t("Archive")}</MenuItem>
                <MenuDivider />
                <MenuItem danger icon={<Trash size={18} strokeWidth={1.7} />} onClick={() => { setProjectMenu(null); onRemoveProject(project); }} disabled={disabled}>{t("Remove")}</MenuItem>
              </MenuSurface>
            </div>
            {isExpanded && <div className="project-chat-list">
              {onOpenProjectResearch && <div className="project-chat-row"><button className="project-chat-open" onClick={() => onOpenProjectResearch(project)}><BookOpen size={13} /><span className="project-chat-title">{t("Project research")}</span></button></div>}
              {projectWorkspaces.map((workspace) => <div
                className={`${activeWorkspaceId === workspace.id ? "project-chat-row active" : "project-chat-row"}${dropTarget === `workspaces:${project.id}:${workspace.id}` ? " sidebar-drop-target" : ""}`}
                key={workspace.id}
                onContextMenu={(event) => { event.preventDefault(); setWorkspaceMenu({ workspace, cursor: { x: event.clientX, y: event.clientY } }); }}
                onDragOver={(event) => overDropTarget(event, workspace.id, "workspaces", project.id)}
                onDrop={(event) => dropOn(event, workspace.id, "workspaces", project.id)}
              >
                <button className={`project-chat-open${draggingItem === `workspaces:${project.id}:${workspace.id}` ? " sidebar-dragging" : ""}${dropTarget === `workspaces:${project.id}:${workspace.id}` ? " sidebar-drop-target" : ""}`} draggable onDragStart={(event) => startDrag(event, "workspaces", workspace.id, project.id)} onDragEnd={finishDrag} onDragOver={(event) => overDropTarget(event, workspace.id, "workspaces", project.id)} onDrop={(event) => dropOn(event, workspace.id, "workspaces", project.id)} onKeyDown={(event) => moveWithKeyboard(event, projectWorkspaces.map((item) => item.id), workspace.id, "workspaces", project.id)} aria-keyshortcuts="Alt+ArrowUp Alt+ArrowDown" onClick={() => { if (Date.now() >= suppressClickUntil.current) onOpenWorkspace(workspace); }} title={`${workspace.root} · ${t("Drag to reorder. Use Alt+ArrowUp or Alt+ArrowDown.")}`}>
                  <span className="project-chat-title">{workspaceName(workspace, t)}</span>
                  {workspace.session_count > 0 && <span className="project-chat-count">{workspace.session_count}</span>}
                </button>
                <MenuSurface open={workspaceMenu?.workspace.id === workspace.id} onClose={() => setWorkspaceMenu(null)} cursor={workspaceMenu?.workspace.id === workspace.id ? workspaceMenu.cursor : null} placement="bottom-start" width={220} className="project-more-menu workspace-context-menu" ariaLabel={t("Workspace actions")}>
                  <MenuItem icon={<FolderOpen size={18} strokeWidth={1.7} />} onClick={() => { setWorkspaceMenu(null); onOpenWorkspace(workspace); }}>{t("Open workspace")}</MenuItem>
                  <WorkspaceMenuActions
                    workspace={workspace}
                    canWorktree={project.git_state === "ready"}
                    disabled={disabled}
                    onRename={() => { setWorkspaceMenu(null); onRenameWorkspace(workspace); }}
                    onDelete={() => { setWorkspaceMenu(null); onDeleteWorkspace(workspace); }}
                    onCreate={(kind) => { setWorkspaceMenu(null); onNewWorkspace(project.id, kind); }}
                  />
                </MenuSurface>
              </div>)}
              {!projectWorkspaces.length && <div className="project-chat-empty">{t("No workspaces yet")}</div>}
            </div>}
          </div>;
      })}
      {!projects.length && <div className="work-empty">{t("No projects yet")}</div>}
      {archivedProjects.length > 0 && <>
        <button className={showArchivedProjects ? "archived-toggle active" : "archived-toggle"} onClick={() => setShowArchivedProjects((visible) => !visible)} aria-expanded={showArchivedProjects}>
          <Archive size={13} /><span>{t("Archived projects")}</span><small>{archivedProjects.length}</small>
        </button>
        {showArchivedProjects && <div className="archived-project-list">
          {orderedArchivedProjects.map((project) => <div className={`archived-project-row${dropTarget === `archivedProjects:${project.id}` ? " sidebar-drop-target" : ""}`} key={project.id} onDragOver={(event) => overDropTarget(event, project.id, "archivedProjects")} onDrop={(event) => dropOn(event, project.id, "archivedProjects")}>
            <span className={draggingItem === `archivedProjects:${project.id}` ? "sidebar-dragging" : ""} draggable tabIndex={0} onDragStart={(event) => startDrag(event, "archivedProjects", project.id)} onDragEnd={finishDrag} onDragOver={(event) => overDropTarget(event, project.id, "archivedProjects")} onDrop={(event) => dropOn(event, project.id, "archivedProjects")} onKeyDown={(event) => moveWithKeyboard(event, orderedArchivedProjects.map((item) => item.id), project.id, "archivedProjects")} aria-keyshortcuts="Alt+ArrowUp Alt+ArrowDown" title={`${project.workspace_path || project.name} · ${t("Drag to reorder. Use Alt+ArrowUp or Alt+ArrowDown.")}`}><strong>{project.name}</strong>{project.chat_count > 0 && <small>{project.chat_count}</small>}</span>
            <div><button onClick={() => onArchiveProject(project, false)} title={t("Restore {name}", { name: project.name })} aria-label={t("Restore {name}", { name: project.name })} disabled={disabled}><ArchiveRestore size={12} /></button><button onClick={() => onRemoveProject(project)} title={t("Remove {name}", { name: project.name })} aria-label={t("Remove {name}", { name: project.name })} disabled={disabled}><Trash size={12} /></button></div>
          </div>)}
        </div>}
      </>}
    </div>
    {filterError && <div className="project-rename-error" role="alert">{filterError}</div>}
    {renameError && <div className="project-rename-error" role="alert">{renameError}</div>}
    <span className="sidebar-order-live" aria-live="polite">{reorderAnnouncement}</span>
  </section>;
}

export function NewProjectModal({ open, name, onName, workspacePath, onWorkspacePath, onChooseFolder, onClose, onCreate, error }: {
  open: boolean;
  name: string;
  onName: (value: string) => void;
  workspacePath: string;
  onWorkspacePath: (value: string) => void;
  onChooseFolder: () => void;
  onClose: () => void;
  onCreate: () => void;
  error?: string;
}) {
  const { t } = useUISettings();
  if (!open) return null;
  return <Dialog open onClose={onClose} size="compact" className="dialog-ref project-create-modal" overlayClassName="modal-backdrop dialog-ref-backdrop" ariaLabelledBy="new-project-title">
    <header className="dialog-ref-header">
      <div><h2 id="new-project-title">{t("New project")}</h2><p>{t("A project groups related chats and runs them inside one folder. Every chat keeps its own history.")}</p></div>
      <button className="dialog-ref-close" onClick={onClose} aria-label={t("Close")}><X size={18} /></button>
    </header>
    <div className="dialog-ref-body">
      <label className="dialog-ref-field"><span>{t("Project name")}</span><input autoFocus value={name} onChange={(event) => onName(event.target.value)} placeholder={t("Agent reliability study")} maxLength={100} onKeyDown={(event) => event.key === "Enter" && onCreate()} /><small>{t("Use a short name that makes the project easy to find later.")}</small></label>
      <label className="dialog-ref-field"><span>{t("Project folder")}</span><span className="dialog-ref-folder"><FolderOpen size={15} /><input value={workspacePath} onChange={(event) => onWorkspacePath(event.target.value)} placeholder={t("Choose a folder for this project")} /><button type="button" className="secondary-button" onClick={onChooseFolder}>{t("Choose")}</button></span><small>{t("New chats inherit this folder as their working directory. You can change it later.")}</small></label>
      {error && <p className="project-rename-error" role="alert">{error}</p>}
    </div>
    <footer className="dialog-ref-footer">
      <button className="secondary-button" onClick={onClose}>{t("Cancel")}</button>
      <button className="primary-button" onClick={onCreate} disabled={!name.trim() || !workspacePath.trim()}>{t("Create project")}</button>
    </footer>
  </Dialog>;
}

export function ProjectRemoveModal({ project, onClose, onRemove }: { project: ResearchProject | null; onClose: () => void; onRemove: () => void }) {
  const { t } = useUISettings();
  if (!project) return null;
  const chatLabel = project.chat_count === 1 ? t("1 chat") : t("{count} chats", { count: project.chat_count });
  return <Dialog open onClose={onClose} size="compact" className="workspace-modal project-remove-modal" ariaLabel={t("Remove {name}", { name: project.name })}>
    <header className="modal-header"><div><h2>{t("Remove project?")}</h2></div><button className="app-dialog-close" onClick={onClose} aria-label={t("Close")}><X size={16} /></button></header>
    <p>{t("{name} and its {chats}, research turns, and recorded Agent actions will be permanently deleted. Files in the project folder are not deleted.", { name: project.name, chats: chatLabel })}</p>
    <div className="modal-actions"><button className="secondary-button" onClick={onClose}>{t("Cancel")}</button><button className="danger-button" onClick={onRemove}><Trash size={14} />{t("Remove project")}</button></div>
  </Dialog>;
}


