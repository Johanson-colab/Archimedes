const assert = require("node:assert/strict");
const fs = require("node:fs");
const os = require("node:os");
const path = require("node:path");
const { test, before, after } = require("node:test");
const { JSDOM } = require("jsdom");

let dom, React, createRoot, Writing;
before(async () => {
  dom = new JSDOM('<!doctype html><div id="root"></div>', { url: "http://localhost", pretendToBeVisual: true });
  dom.window.matchMedia = () => ({ matches: false, addEventListener() {}, removeEventListener() {} });
  Object.assign(global, { window: dom.window, document: dom.window.document, HTMLElement: dom.window.HTMLElement, Node: dom.window.Node,
    IS_REACT_ACT_ENVIRONMENT: true, ResizeObserver: class { observe() {} disconnect() {} }, getComputedStyle: dom.window.getComputedStyle });
  React = require("react"); ({ createRoot } = require("react-dom/client"));
  const { transformWithOxc } = await import("vite");
  const helpers = await import("../src/paper-writing-state.ts");
  const search = await import("../src/paper-source-search.ts");
  const source = fs.readFileSync(path.join(__dirname, "../src/PaperWritingView.tsx"), "utf8");
  const icons = require("lucide-react");
  const names = source.match(/\{([^}]+)\} from "lucide-react"/)[1].split(",").map(name => name.trim());
  const scope = { React, ...React, ...helpers, ...search,
    ...Object.fromEntries(names.map(name => [name, icons[name]])),
    useUISettings: () => ({ t: value => value }),
    Dialog: props => props.open ? React.createElement("div", { role: "dialog" }, props.children) : null,
    StateView: props => React.createElement("div", null, props.title, props.description, props.action),
    PaperTemplateLibrary: () => null, paperTemplates: [{ id: "fake" }], SharedNoteEditor: () => null,
    fingerprintFor: () => "fake", emitProactiveSignal() {},
  };
  Object.assign(scope, await import("../src/bibliography.ts"));
  for (const [file, exported] of [["paper-writing-citations.ts", ["citationKeyFor", "prepareManuscriptCitation", "manuscriptBibliographyPaths"]], ["PaperWritingCitations.tsx", ["PaperWritingCitations"]], ["PaperWritingVersions.tsx", ["PaperWritingVersions"]]]) {
    const content = fs.readFileSync(path.join(__dirname, "../src", file), "utf8").replace(/^import[\s\S]*?from\s+"[^"]+";\r?\n/gm, "").replace(/^import "[^"]+";\r?\n/gm, "").replace(/export default function/g, "function").replace(/export function/g, "function");
    const compiled = await transformWithOxc(content, file, { jsx: { runtime: "classic" } });
    Object.assign(scope, new Function(...Object.keys(scope), `${compiled.code.replace(/^export \{\};?$/gm, "")}\nreturn {${exported.join(",")}};`)(...Object.values(scope)));
  }
  const tabsSource = fs.readFileSync(path.join(__dirname, "../src/Tabs.tsx"), "utf8").replace(/^import .*;\r?\n/gm, "").replace(/export /g, "");
  const tabs = await transformWithOxc(tabsSource, "Tabs.tsx", { jsx: { runtime: "classic" } });
  Object.assign(scope, new Function(...Object.keys(scope), `${tabs.code}\nreturn { Tabs, Tab };`)(...Object.values(scope)));
  const text = source.replace(/^import[\s\S]*?from\s+"[^"]+";\r?\n/gm, "").replace(/^import "[^"]+";\r?\n/gm, "").replace("export default function", "function");
  const { code } = await transformWithOxc(text, "PaperWritingView.tsx", { jsx: { runtime: "classic" } });
  Writing = new Function(...Object.keys(scope), `${code.replace(/^export \{\};?$/gm, "")}\nreturn PaperWritingView;`)(...Object.values(scope));
});
after(() => {
  dom.window.close();
  for (const name of ["window", "document", "HTMLElement", "Node", "IS_REACT_ACT_ENVIRONMENT", "ResizeObserver", "getComputedStyle"]) delete global[name];
});

function deferred() {
  let resolve, reject;
  const promise = new Promise((yes, no) => { resolve = yes; reject = no; });
  return { promise, resolve, reject };
}
const source = label => `\\documentclass{article}\n\\begin{document}\n${label}\n\\end{document}\n`;
async function fixture(t, overrides = {}) {
  const directory = fs.mkdtempSync(path.join(os.tmpdir(), "archimedes-writing-scope-"));
  const a = path.join(directory, "a"), b = path.join(directory, "b");
  for (const [root, label] of [[a, "Project A original"], [b, "Project B original"]]) {
    fs.mkdirSync(path.join(root, "paper"), { recursive: true });
    fs.writeFileSync(path.join(root, "paper/main.tex"), source(label));
  }
  const reads = [], writes = [], compiles = [];
  const preview = (root, name) => ({ name: path.basename(name), path: name, kind: "text", size: 100, modifiedAt: "now", content: fs.readFileSync(path.join(root, name), "utf8") });
  let progress;
  const bridge = {
    ...overrides.bridge,
    stageProjectResultFigure: async (input) => overrides.stage(input),
    listLatexProjects: async root => overrides.listProjects ? overrides.listProjects(root) : require("./latex-workspace.cjs").listLatexProjects(root),
    listWorkspaceFiles: async (root, parent) => require("./workspace-files.cjs").listWorkspaceDirectory(root, parent),
    readWorkspaceFile: async (root, name) => { reads.push({ root, name }); return overrides.read ? overrides.read(root, name, preview) : preview(root, name); },
    writeWorkspaceFile: async (root, name, content) => {
      writes.push({ root, name, content });
      if (overrides.write) await overrides.write(root, name, content);
      fs.writeFileSync(path.join(root, name), content);
      return preview(root, name);
    },
    compileLatexDocument: async (root, name, requestId) => {
      compiles.push({ root, name, requestId });
      return overrides.compile ? overrides.compile(root, name, requestId) : { ok: true, diagnostics: [], log: "fake build", duration_ms: 1 };
    },
    readManuscriptSnapshot: async (root, manifestPath) => overrides.readSnapshot ? overrides.readSnapshot(root, manifestPath) : require("./manuscript-snapshot.cjs").readManuscriptSnapshot(root, manifestPath),
    onLatexCompileProgress: callback => { progress = callback; return () => { progress = undefined; }; },
  };
  let reactRoot = createRoot(document.getElementById("root"));
  const render = (workspace, token = 1, filePath = "paper/main.tex") => React.act(async () => reactRoot.render(React.createElement(Writing, {
    bridge, workspace, projectId: overrides.projectId || (workspace === a ? "a" : "b"), workspaceId: overrides.workspaceId, threadId: overrides.threadId, figureRequest: overrides.figureRequest, openRequest: token === null ? null : { path: filePath, token }, onRefresh() {}, onAskAI() {}, onHandoff: overrides.handoff, onReturnToResult: overrides.returnResult,
  })));
  t.after(async () => { await React.act(async () => reactRoot.unmount()); fs.rmSync(directory, { recursive: true, force: true }); });
  return { a, b, bridge, render, restart: async workspace => { await React.act(async () => reactRoot.unmount()); reactRoot = createRoot(document.getElementById("root")); await render(workspace, null); }, reads, writes, compiles, disk: root => fs.readFileSync(path.join(root, "paper/main.tex"), "utf8"), progress: event => progress?.(event) };
}
async function autoCompileOff() {
  const checkbox = document.querySelector('.paper-auto-compile input');
  if (checkbox.checked) await React.act(async () => checkbox.click());
}
async function edit(content, filePath = "paper/main.tex") {
  const input = document.querySelector(`[aria-label="Edit ${filePath}"]`);
  assert.ok(input, "the real Writing textarea is open");
  await React.act(async () => {
    Object.getOwnPropertyDescriptor(dom.window.HTMLTextAreaElement.prototype, "value").set.call(input, content);
    input.dispatchEvent(new dom.window.Event("input", { bubbles: true }));
  });
  assert.equal(input.value, content);
}
async function click(label) {
  const button = [...document.querySelectorAll("button")].find(node => node.title === label || node.getAttribute("aria-label") === label);
  assert.ok(button, label);
  await React.act(async () => button.click());
}
const settle = () => React.act(async () => { await new Promise(resolve => setTimeout(resolve, 0)); });

async function clickText(label) {
  const button = [...document.querySelectorAll("button")].find(node => node.textContent.trim() === label);
  assert.ok(button, label); assert.equal(button.disabled, false, label);
  await React.act(async () => button.click());
}
async function changeInput(node, value) {
  assert.ok(node);
  await React.act(async () => {
    Object.getOwnPropertyDescriptor(dom.window.HTMLInputElement.prototype, "value").set.call(node, value);
    node.dispatchEvent(new dom.window.Event("input", { bubbles: true }));
  });
}

test("Writing inserts a project-library citation and explicitly refreshes its bibliography without replacing manual content", async t => {
  let db;
  const options = { bridge: {
    listLibraries: async id => db.listLibraries(id), listLibraryPapers: async id => db.listPapers(id), setPaperBibliography: async (...args) => db.setPaperBibliography(...args),
  } };
  const f = await fixture(t, options);
  db = require("./store.cjs").createWorkspaceStore(f.a);
  t.after(() => db.close());
  const project = db.createResearchProject({ name: "Citation manuscript", workspacePath: f.a }); options.projectId = project.id;
  const library = db.listLibraries(project.id)[0], paper = db.addPaper(library.id, require("./test-support/discovery-fixture.cjs").paper);
  db.setPaperBibliography(paper.id, { citekey: "evidence2026", entryType: "article" });
  const manual = "% Keep this manuscript annotation\n@book{manual, title={Existing hand-written reference}, note={My note}}\n";
  fs.writeFileSync(path.join(f.a, "paper/references.bib"), manual);
  await f.render(f.a); await autoCompileOff();
  const editor = document.querySelector('.latex-editor-textarea'); editor.setSelectionRange(editor.value.indexOf("\\end{document}"), editor.value.indexOf("\\end{document}"));
  await click("Insert citation"); await clickText("Insert citation and update .bib");
  assert.match(f.disk(f.a), /\\cite\{evidence2026\}/);
  const first = fs.readFileSync(path.join(f.a, "paper/references.bib"), "utf8"); assert.ok(first.startsWith(manual)); assert.match(first, /Evidence handoff fixture/);
  db.repairLibraryPaperMetadata(paper.id, { title: "Corrected source metadata" });
  await click("Close citations");
  await click("Insert citation"); await clickText("Update .bib only");
  const updated = fs.readFileSync(path.join(f.a, "paper/references.bib"), "utf8");
  assert.ok(updated.startsWith(manual)); assert.match(updated, /Corrected source metadata/); assert.equal((updated.match(/@article\{/g) || []).length, 1);
  assert.equal((f.disk(f.a).match(/\\cite\{evidence2026\}/g) || []).length, 1, "metadata updates do not insert another citation");
});

test("Writing names current drafts, compares modified sections, restores and continues through its owner save queue", async t => {
  const history = require("./paper-writing-history.cjs");
  const f = await fixture(t, { workspaceId: "workspace-a", bridge: {
    listManuscriptVersions: async input => history.listProjectManuscriptVersions(input),
    saveManuscriptVersion: async input => history.saveManuscriptVersion(input),
    compareManuscriptVersion: async input => history.compareManuscriptVersion(input),
    restoreManuscriptVersion: async input => history.restoreManuscriptVersion(input),
  } });
  await f.render(f.a); await autoCompileOff();
  await edit(source("Draft saved by the key-version action"));
  await click("Key versions");
  await changeInput(document.querySelector('.paper-version-save input'), "First complete draft");
  await React.act(async () => document.querySelector('.paper-version-save').dispatchEvent(new dom.window.Event("submit", { bubbles: true, cancelable: true })));
  assert.equal(f.disk(f.a), source("Draft saved by the key-version action"));
  await click("Close key versions");
  await edit(source("Later writing to restore"));
  await click("Key versions");
  await React.act(async () => document.querySelector('.paper-version-row').click());
  assert.match(document.querySelector('.paper-version-comparison pre').textContent, /Later writing to restore/);
  await clickText("Restore this key version");
  assert.equal(document.querySelector('.latex-editor-textarea').value, source("Draft saved by the key-version action"));
  assert.equal(document.querySelectorAll('.paper-version-row').length, 2);
  await click("Close key versions");
  await edit(source("Continued after returning to the milestone")); await click("Recompile");
  assert.equal(f.disk(f.a), source("Continued after returning to the milestone"));
  assert.equal(f.compiles.at(-1).root, f.a);
});

test("same-named papers keep their owner and autosave on departure without replaying an old open request", async t => {
  const f = await fixture(t);
  await f.render(f.b, 1); await autoCompileOff();
  const bDraft = source("B edited before changing workspace");
  await edit(bDraft);
  await f.render(f.a, 1); await settle();
  assert.equal(f.disk(f.a), source("Project A original"));
  assert.equal(f.disk(f.b), bDraft, "leaving Writing's root still saves to its original directory");
  assert.equal(f.reads.some(call => call.root === f.a), false, "the already consumed token must not open its path again in A");
  await f.render(f.a, 2);
  const aDraft = source("A independently edited");
  await edit(aDraft);
  await f.render(f.b, 2); await settle();
  assert.equal(document.querySelector('textarea').value, bDraft);
  assert.equal(f.disk(f.a), aDraft);
  assert.equal(f.disk(f.b), bDraft);
  await f.render(f.a, 2);
  assert.equal(document.querySelector('textarea').value, aDraft);
});

test("a delayed save preserves later keystrokes and drains the newest snapshot to its old root", async t => {
  const first = deferred(); let held = false;
  const f = await fixture(t, { write: async () => { if (!held) { held = true; await first.promise; } } });
  await f.render(f.a, 1); await autoCompileOff();
  const firstDraft = source("First submitted snapshot"), latest = source("Typed while the first write is pending");
  await edit(firstDraft);
  await React.act(async () => { await new Promise(resolve => setTimeout(resolve, 800)); });
  assert.equal(f.writes.length, 1);
  await edit(latest);
  await f.render(f.b, 2);
  assert.equal(document.querySelector('textarea').value, source("Project B original"));
  await React.act(async () => first.resolve()); await settle();
  assert.equal(f.disk(f.a), latest);
  assert.equal(f.disk(f.b), source("Project B original"));
  assert.equal(f.writes.every(call => call.root === f.a), true);
  assert.equal(document.querySelector('.paper-save-state').textContent, "Saved");
  await f.render(f.a, 2);
  assert.equal(document.querySelector('textarea').value, latest);
  assert.equal(document.querySelector('.paper-save-state').textContent, "Saved");
});

test("late reads, compile progress and build results update only their owner scope", async t => {
  const readA = deferred(), compileA = deferred(), compileB = deferred(); let rootA;
  const f = await fixture(t, {
    read: async (root, name, preview) => { if (root === rootA) await readA.promise; return preview(root, name); },
    compile: root => root === rootA ? compileA.promise : compileB.promise,
  });
  rootA = f.a;
  await f.render(f.a, 1); await f.render(f.b, 2); await autoCompileOff();
  await React.act(async () => readA.resolve());
  assert.equal(document.querySelector('textarea').value, source("Project B original"));
  await f.render(f.a, 2); await click("Recompile");
  const aBuild = f.compiles.find(call => call.root === f.a);
  await f.render(f.b, 2); await click("Recompile");
  const bBuild = f.compiles.find(call => call.root === f.b);
  assert.ok(aBuild.requestId && bBuild.requestId && aBuild.requestId !== bBuild.requestId);
  await React.act(async () => {
    f.progress({ workspace: f.a, requestId: aBuild.requestId, path: "paper/main.tex", stage: "A compilation", log: "A private build log" });
    f.progress({ workspace: f.b, requestId: "obsolete-request", path: "paper/main.tex", stage: "Wrong compilation", log: "Wrong request log" });
    f.progress({ workspace: f.b, requestId: bBuild.requestId, path: "paper/main.tex", stage: "B compilation", log: "B build log" });
  });
  await click("Build log");
  assert.match(document.querySelector('.latex-live-log').textContent, /B build log/);
  assert.doesNotMatch(document.querySelector('.latex-live-log').textContent, /A private|Wrong request/);
  await React.act(async () => compileA.resolve({ ok: true, preview_url: "https://example.invalid/a.pdf", diagnostics: [], log: "A result", duration_ms: 1 }));
  assert.equal(document.querySelector('iframe'), null);
  await React.act(async () => compileB.resolve({ ok: true, preview_url: "https://example.invalid/b.pdf", diagnostics: [], log: "B result", duration_ms: 1 }));
  assert.match(document.querySelector('iframe').src, /\/b\.pdf$/);
  await f.render(f.a, 2);
  assert.equal(document.querySelector('textarea').value, source("Project A original"));
  assert.match(document.querySelector('iframe').src, /\/a\.pdf$/);
});

test("failed departure autosaves keep the original draft and expose its save error on return", async t => {
  const f = await fixture(t, { write: async () => { throw new Error("Review disk is read-only"); } });
  await f.render(f.a, 1); await autoCompileOff();
  const pending = source("Draft retained after a failed write");
  await edit(pending); await f.render(f.b, 2); await settle();
  assert.equal(f.disk(f.a), source("Project A original"));
  await f.render(f.a, 2);
  assert.equal(document.querySelector('textarea').value, pending);
  assert.equal(document.querySelector('.paper-save-state').textContent, "Unsaved");
  assert.match(document.querySelector('.latex-diagnostics').textContent, /Review disk is read-only/);
});

test("switching source files during an in-flight save retains and saves the final edit to the old file", async t => {
  const first = deferred(); let held = false;
  const f = await fixture(t, { write: async () => { if (!held) { held = true; await first.promise; } } });
  fs.writeFileSync(path.join(f.a, "paper/section.tex"), "Section original");
  await f.render(f.a, 1); await autoCompileOff();
  await edit(source("First source snapshot"));
  await React.act(async () => { await new Promise(resolve => setTimeout(resolve, 800)); });
  const latest = source("Final main edit while save is pending");
  await edit(latest);
  await f.render(f.a, 2, "paper/section.tex");
  assert.equal(document.querySelector('textarea').value, "Section original");
  await f.render(f.a, 3);
  assert.equal(document.querySelector('textarea').value, latest);
  assert.equal(document.querySelector('.paper-save-state').textContent, "Unsaved");
  await React.act(async () => first.resolve()); await settle();
  assert.equal(f.disk(f.a), latest);
  assert.equal(fs.readFileSync(path.join(f.a, "paper/section.tex"), "utf8"), "Section original");
  assert.equal(document.querySelector('.paper-save-state').textContent, "Saved");
});

test("the actual preload and compile handler preserve owner ids and legacy two-argument calls", async () => {
  const vm = require("node:vm");
  const handlers = new Map(), listeners = new Map(), compilerCalls = [];
  let api;
  const main = fs.readFileSync(path.join(__dirname, "main.cjs"), "utf8");
  const begin = main.indexOf('  ipcMain.handle("paper:compile",');
  const end = main.indexOf('  ipcMain.handle("research-thread:get",', begin);
  assert.ok(begin >= 0 && end > begin, "reassess the handler probe if its source boundaries change");
  const sender = { isDestroyed: () => false, send: (channel, payload) => listeners.get(channel)?.({}, payload) };
  vm.runInNewContext(main.slice(begin, end), {
    ipcMain: { handle: (name, callback) => handlers.set(name, callback) }, resolveWorkspace: root => root,
    managedPaperCompiler: async (root, name, progress) => { compilerCalls.push({ root, name }); progress("Compiling", "Fake compiler output"); return { ok: false, diagnostics: [], log: "fake" }; },
  });
  const ipcRenderer = {
    invoke: (name, input) => handlers.get(name)({ sender }, input),
    on: (name, callback) => listeners.set(name, callback), removeListener: name => listeners.delete(name),
  };
  vm.runInNewContext(fs.readFileSync(path.join(__dirname, "preload.cjs"), "utf8"), {
    process: { platform: process.platform },
    require: name => { assert.equal(name, "electron"); return { contextBridge: { exposeInMainWorld: (_name, value) => { api = value; } }, ipcRenderer, webUtils: {} }; },
  });
  const progress = [];
  const unsubscribe = api.onLatexCompileProgress(value => progress.push(value));
  await api.compileLatexDocument("/review/a", "paper/main.tex", "request-a");
  await api.compileLatexDocument("/review/b", "paper/main.tex");
  assert.equal(progress[0].workspace, "/review/a"); assert.equal(progress[0].requestId, "request-a");
  assert.equal(progress[1].workspace, "/review/b"); assert.equal(progress[1].requestId, undefined);
  assert.deepEqual(compilerCalls, [{ root: "/review/a", name: "paper/main.tex" }, { root: "/review/b", name: "paper/main.tex" }]);
  unsubscribe(); assert.equal(listeners.size, 0);
});

test('Writing opens existing manuscripts before templates and restores the chosen document after remount', async t => {
  const f = await fixture(t);
  fs.writeFileSync(path.join(f.a, 'paper/alternate.tex'), source('Explicit alternate main'));
  fs.writeFileSync(path.join(f.a, 'paper/section.tex'), 'A section body\n');
  await f.render(f.a, null);
  assert.equal(document.querySelector('[role="tab"][aria-selected="true"]').textContent, 'Existing manuscripts');
  assert.equal(document.querySelector('.paper-template-library'), null);
  assert.equal(document.querySelector('.latex-editor-textarea'), null, 'multiple manuscripts do not cause a guessed auto-open');
  const open = [...document.querySelectorAll('.paper-existing-projects button')].find(button => button.querySelector('small')?.textContent === 'paper/alternate.tex');
  assert.ok(open);
  await React.act(async () => open.click());
  await autoCompileOff();
  assert.match(document.querySelector('.latex-editor-textarea').value, /Explicit alternate main/);
  const main = document.querySelector('.paper-main-document select');
  assert.equal(main.value, 'paper/alternate.tex');
  assert.ok([...main.options].some(option => option.value === 'paper/main.tex'));
  await React.act(async () => [...document.querySelectorAll('.paper-tree-row')].find(button => button.textContent.includes('section.tex')).click());
  assert.equal(document.querySelector('.latex-editor-textarea').value, 'A section body\n');
  await f.restart(f.a);
  assert.equal(document.querySelector('[role="dialog"]'), null);
  assert.equal(document.querySelector('.latex-editor-textarea').value, 'A section body\n');
  assert.equal(document.querySelector('.paper-main-document select').value, 'paper/alternate.tex');
  assert.equal(f.compiles.length, 0, 'opening and restoring manuscripts does not need a compiler');
});

test('a main document at the execution root opens in place and a removed recent document returns to the chooser', async t => {
  const f = await fixture(t);
  fs.writeFileSync(path.join(f.a, 'root.tex'), source('Root manuscript'));
  await f.render(f.a, null);
  const open = [...document.querySelectorAll('.paper-existing-projects button')].find(button => button.querySelector('small')?.textContent === 'root.tex');
  await React.act(async () => open.click());
  assert.match(document.querySelector('.latex-editor-textarea').value, /Root manuscript/);
  assert.equal(document.querySelector('.paper-main-document select').value, 'root.tex');
  assert.equal(fs.readFileSync(path.join(f.a, 'root.tex'), 'utf8'), source('Root manuscript'));
  fs.unlinkSync(path.join(f.a, 'root.tex'));
  await f.restart(f.a);
  assert.ok(document.querySelector('[role="dialog"]'));
  assert.equal(document.querySelector('.latex-editor-textarea'), null);
  assert.ok([...document.querySelectorAll('.paper-existing-projects small')].some(node => node.textContent === 'paper/main.tex'));
});

test('compiling main waits for a pending save of another source file in the same manuscript', async t => {
  const gate = deferred();
  let diskAtCompile = '';
  const f = await fixture(t, {
    write: async (_root, name) => { if (name === 'paper/section.tex') await gate.promise; },
    compile: async (root, name) => { diskAtCompile = fs.readFileSync(path.join(root, 'paper/section.tex'), 'utf8'); return { ok: true, source_path: name, diagnostics: [], log: 'fixture compiler read actual files', duration_ms: 1 }; },
  });
  fs.writeFileSync(path.join(f.a, 'paper/section.tex'), 'Original section\n');
  await f.render(f.a); await autoCompileOff();
  const open = name => React.act(async () => [...document.querySelectorAll('.paper-tree-row')].find(button => button.textContent.includes(name)).click());
  await open('section.tex'); await edit('Latest section for compile\n', 'paper/section.tex'); await open('main.tex');
  await React.act(async () => [...document.querySelectorAll('button')].find(button => button.textContent === 'Recompile').click());
  const callsBeforeRelease = f.compiles.length;
  gate.resolve();
  await React.act(async () => { await gate.promise; await new Promise(resolve => setImmediate(resolve)); });
  assert.equal(callsBeforeRelease, 0, `compiler ran before section save; it read ${JSON.stringify(diskAtCompile)}`);
  assert.equal(f.compiles.length, 1);
  assert.equal(diskAtCompile, 'Latest section for compile\n');
});

test('typing during the compile save barrier retains the new edit and does not compile an older source set', async t => {
  const gate = deferred();
  const f = await fixture(t, { write: async (_root, name) => { if (name === 'paper/section.tex') await gate.promise; } });
  fs.writeFileSync(path.join(f.a, 'paper/section.tex'), 'Original section\n');
  await f.render(f.a); await autoCompileOff();
  const open = name => React.act(async () => [...document.querySelectorAll('.paper-tree-row')].find(button => button.textContent.includes(name)).click());
  await open('section.tex'); await edit('Pending section\n', 'paper/section.tex'); await open('main.tex');
  await React.act(async () => [...document.querySelectorAll('button')].find(button => button.textContent === 'Recompile').click());
  const latestMain = source('Main typed after compile was requested');
  await edit(latestMain);
  gate.resolve();
  await React.act(async () => { await gate.promise; await new Promise(resolve => setImmediate(resolve)); });
  assert.equal(f.compiles.length, 0);
  assert.equal(document.querySelector('.latex-editor-textarea').value, latestMain);
  assert.match(document.body.textContent, /sources changed while saving/);
  assert.equal(f.disk(f.a), source('Project A original'), 'the later main edit remains visibly unsaved instead of being represented as compiled');
});

function compileSnapshotFixture(root, name) {
  return require("./latex-workspace.cjs").compileLatexDocument(root, name, { executable: "tectonic", spawnImpl: (_command, args) => {
    const { EventEmitter } = require("node:events");
    const child = new EventEmitter(); child.stdout = new EventEmitter(); child.stderr = new EventEmitter(); child.kill = () => {};
    const output = args[args.indexOf("--outdir") + 1];
    setImmediate(() => { fs.writeFileSync(path.join(output, path.basename(name, ".tex") + ".pdf"), "%PDF-controlled-handoff-fixture"); child.emit("close", 0, null); });
    return child;
  } });
}
async function compileCurrentSnapshot() {
  await click("Recompile");
  for (let index = 0; index < 50 && document.querySelector(".paper-compile-state.compiling"); index++) await settle();
  assert.ok(document.querySelector(".paper-compile-state.success"), document.body.textContent);
}

test("Writing hands off only a fresh whole-manuscript snapshot and keeps source/PDF identity for returning", async t => {
  const handoffs = [];
  const f = await fixture(t, { compile: compileSnapshotFixture, handoff: async (target, value) => handoffs.push({ target, source: value }) });
  await f.render(f.a); await autoCompileOff();
  await click("Review current PDF"); assert.equal(handoffs.length, 0); assert.match(document.body.textContent, /Compile the current manuscript/);
  await compileCurrentSnapshot(); await click("Review current PDF");
  assert.equal(handoffs.length, 1); assert.equal(handoffs[0].target, "paper-review");
  assert.equal(handoffs[0].source.workspace, fs.realpathSync(f.a)); assert.equal(handoffs[0].source.mainPath, "paper/main.tex");
  assert.equal(handoffs[0].source.projectId, "a"); assert.match(handoffs[0].source.pdfSha256, /^[a-f0-9]{64}$/);
  assert.equal(require("./manuscript-snapshot.cjs").readManuscriptSnapshot(f.a, handoffs[0].source.manifestPath).current, true);
  fs.writeFileSync(path.join(f.a, "paper/refs.bib"), "Changed bibliography outside the open editor");
  await click("Slides from current PDF"); assert.equal(handoffs.length, 1); assert.match(document.body.textContent, /no longer matches/);
  await compileCurrentSnapshot(); await edit(source("Unsaved newer main"));
  await click("Slides from current PDF"); assert.equal(handoffs.length, 1); assert.match(document.body.textContent, /Save and recompile/);
});

test("a late snapshot check cannot hand off a newer unsaved editing version as its old PDF", async t => {
  const gate = deferred(), handoffs = [];
  const f = await fixture(t, { compile: compileSnapshotFixture, handoff: async (_target, value) => handoffs.push(value), readSnapshot: async (root, manifestPath) => {
    const verified = require("./manuscript-snapshot.cjs").readManuscriptSnapshot(root, manifestPath);
    await gate.promise; return verified;
  } });
  await f.render(f.a); await autoCompileOff(); await compileCurrentSnapshot();
  await React.act(async () => [...document.querySelectorAll("button")].find((button) => button.textContent === "Review current PDF").click());
  await edit(source("Typed during PDF verification")); gate.resolve();
  await React.act(async () => { await gate.promise; await new Promise((resolve) => setImmediate(resolve)); });
  assert.equal(handoffs.length, 0); assert.match(document.body.textContent, /changed while preparing the handoff/);
  assert.match(document.querySelector(".latex-editor-textarea").value, /Typed during PDF verification/);
});


test("a registered figure is copied by the real IPC handler and inserted without losing later manuscript typing", async t => {
  const gate = deferred(), reached = deferred(), returns = [], options = { returnResult: id => returns.push(id) };
  const f = await fixture(t, options), database = require("./store.cjs").createWorkspaceStore(f.a);
  t.after(() => database.close());
  const project = database.createResearchProject({ name: "Figure paper", workspacePath: f.a }), workspace = database.defaultProjectWorkspace(project.id);
  const thread = database.createResearchThread({ projectId: project.id, workspaceId: workspace.id, mode: "free-chat" });
  const handlers = new Map(); require("./project-result-commands.cjs").registerProjectResultCommands({ ipcMain: { handle: (name, handler) => handlers.set(name, handler) }, store: database });
  const image = "iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+/l9sAAAAASUVORK5CYII=";
  const saved = handlers.get("project-results:save")({}, { projectId: project.id, workspaceId: workspace.id, kind: "analysis", title: "Actual local chart", manifest: { output: { file: "plot.png" } }, files: [{ name: "plot.png", role: "output", encoding: "base64", content: image }] });
  Object.assign(options, { projectId: project.id, workspaceId: workspace.id, threadId: thread.id,
    figureRequest: { dataRoot: f.a, projectId: project.id, resultId: saved.id, fileName: "plot.png", title: saved.title, token: "figure-insertion" },
    stage: async input => { const receipt = handlers.get("project-results:stage-figure")({}, input); reached.resolve(receipt); await gate.promise; return receipt; },
  });
  await f.render(f.a); await autoCompileOff();
  const before = source("ALL_EXISTING_UNSAVED_PARAGRAPHS"); await edit(before);
  const button = () => [...document.querySelectorAll("button")].find(node => node.textContent === "Insert figure" || node.textContent === "Insert at current cursor");
  await React.act(async () => button().click()); const receipt = await reached.promise;
  assert.equal(f.disk(f.a), source("Project A original"), "staging never writes the manuscript itself");
  const newer = before.replace("ALL_EXISTING_UNSAVED_PARAGRAPHS", "ALL_EXISTING_UNSAVED_PARAGRAPHS\nTYPED_WHILE_COPYING"); await edit(newer);
  await React.act(async () => { gate.resolve(); await gate.promise; });
  assert.equal(document.querySelector(".latex-editor-textarea").value, newer);
  assert.ok(document.body.textContent.includes("Your newer text was kept."));
  const editor = document.querySelector(".latex-editor-textarea"); editor.setSelectionRange(newer.indexOf("\\end{document}"), newer.indexOf("\\end{document}"));
  await React.act(async () => button().click());
  const final = editor.value;
  assert.ok(final.includes("TYPED_WHILE_COPYING")); assert.match(final, /\\includegraphics\[width=\\linewidth\]\{figures\/results\//);
  assert.equal(final.replace(/\n\\begin\{figure\}\[htbp\][\s\S]*?\\end\{figure\}\n/, ""), newer);
  assert.equal(fs.readFileSync(path.join(f.a, receipt.path)).toString("base64"), image);
  const provenance = JSON.parse(fs.readFileSync(path.join(f.a, receipt.path + ".source.json")));
  assert.equal(provenance.source.resultId, saved.id); assert.equal(provenance.source.sha256, receipt.sha256);
  await React.act(async () => [...document.querySelectorAll("button")].find(node => node.textContent === "Add graphicx to main").click());
  assert.match(editor.value, /\\usepackage\{graphicx\}\n\\begin\{document\}/);
  assert.ok(editor.value.includes("TYPED_WHILE_COPYING"));
  await click("Recompile"); await settle();
  assert.ok(f.disk(f.a).includes("\\usepackage{graphicx}"));
  assert.ok(f.disk(f.a).includes("TYPED_WHILE_COPYING"));
  await React.act(async () => [...document.querySelectorAll("button")].find(node => node.textContent === "Open source result").click());
  assert.deepEqual(returns, [saved.id]);
});
