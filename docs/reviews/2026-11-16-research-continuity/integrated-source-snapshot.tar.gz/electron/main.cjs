const { app, BrowserWindow, Menu, ipcMain: electronIpcMain, dialog, nativeTheme, net, protocol, clipboard, shell, session, safeStorage, systemPreferences, Notification } = require("electron");
const { spawn } = require("node:child_process");
const { randomUUID } = require("node:crypto");
const os = require("node:os");
const fs = require("node:fs");
const path = require("node:path");
const { windowIconPath, configureAppIcon, configureWindowIcon } = require("./app-icons.cjs");
const { pathToFileURL } = require("node:url");
const pty = require("node-pty");
const agent = require("./agent.cjs");
const { registerThreadCommands } = require("./thread-commands.cjs");
const { generateDeepReading, createCodexReadingCall } = require("./paper-deep-reading.cjs");
const { renderReport: renderDeepReading, markdown: deepReadingMarkdown } = require("./paper-deep-reading-render.cjs");
const deepReadingRuns = new Map();
const kimiSlidesSkill = require("./kimi-slides-skill.cjs");
const runKimiSlidesPlan = kimiSlidesSkill.runKimiSlidesPlan || kimiSlidesSkill.runKimiSlidesPresentation;
const runPaperPresentationPlan = kimiSlidesSkill.runPaperPresentationPlan || runKimiSlidesPlan;
const { generateNativePptx } = require("./native-pptx.cjs");
const { browserUse } = require("./agent/browser-use.cjs");
const { loadLocalAgentEnvironment } = require("./config.cjs");
const terminalSettings = require("./terminal-settings.cjs");
const journeySettings = require("./journey-settings.cjs");
const journeySnapshots = require("./journey-snapshots.cjs");
const workbenchSettings = require("./workbench-settings.cjs");
const sidebarSettings = require("./sidebar-settings.cjs");
const news = require("./news.cjs");
const paperReview = require("./paper-review.cjs");
const workbenchNotes = require("./workbench-notes.cjs");
const localIdentity = require("./local-identity.cjs");
const { createClient } = require("@supabase/supabase-js");
const { createSupabaseAuth } = require("./supabase-auth.cjs");
const { createAuthFlow } = require("./auth-flow.cjs");
const { createCollaborationApi } = require("./collaboration-api.cjs");
const { createLibrarySync } = require("./library-sync.cjs");
const { createAnnotationSync } = require("./annotation-sync.cjs");
const { createThreadSync } = require("./thread-sync.cjs");
const { createPresence } = require("./presence.cjs");
const { createSupabaseServer } = require("../server/supabase-server.cjs");
const supabaseConfig = require("../shared/supabase-config.json");
const journeySummarizer = require("./journey-summarizer.cjs");
const modelConfig = require("./model-config.cjs");
const agentBackendConfig = require("./agent-backend-config.cjs");
const nativeAgent = require("./agent/external-backend.cjs");
const { registerNativeAgentCommands } = require("./native-agent-commands.cjs");
const { runWindowAgent } = require("./window-agent-run.cjs");
const { closeAllNativeClients } = require("./agent/external-backend.cjs");
const { planReproduction } = require("./reproduction/planner.cjs");
const { normalizeContract } = require("./reproduction/contract.cjs");
const { prepareRepositoryItem } = require("./reproduction/repository-context.cjs");
const { runPreflight } = require("./reproduction/preflight.cjs");
const { repoNameFromUrl } = require("./reproduction/paths.cjs");
const { findRepositoryUrl } = require("./paper-repository.cjs");
const { findRepository, githubSearchCandidates } = require("./reproduction/find-repository.cjs");
const { runPilot } = require("./reproduction/pilot.cjs");
const { createReproductionRunManager } = require("./reproduction/run-manager.cjs");
const { localCheckoutSnapshot, snapshotApplicability } = require("./reproduction/run-snapshot.cjs");
const { completeJson } = require("./paper-review-model.cjs");
const { createDockerBackend } = require("./reproduction/docker.cjs");
const { createSshBackend } = require("./reproduction/remote.cjs");
const reproductionEnv = require("./reproduction/env-store.cjs");
const { testHuggingFaceToken } = require("./reproduction/env-test.cjs");
const proactiveAgent = require("./proactive-agent.cjs");
const figureForge = require("./figure-forge.cjs");
const { getModelCapabilities, normalizeContextLength, normalizeReasoningEffort } = require("./agent/model-capabilities.cjs");
const webSearch = require("./web-search.cjs");
const sshServers = require("./ssh-servers.cjs");
const { discoverDailyPapers, normalizeDailyOptions, resolveArxivFigure, searchAcademicPapers } = require("./literature.cjs");
const { createDailyFigureCache } = require("./daily-figure-cache.cjs");
const { deepSearchPapers } = require("./deep-paper-search.cjs");
const { searchConferencePapers } = require("./conferences.cjs");
const skillCatalog = require("./skill-catalog.cjs");
const speech = require("./speech.cjs");
const store = require("./store.cjs");
const { createWorkspaceIpc, resolveResearchContext } = require("./workspace-context.cjs");
const { registerProjectResultCommands } = require("./project-result-commands.cjs");
const { registerProjectResearchCommands } = require("./project-research-commands.cjs");
const { registerPaperWritingCommands } = require("./paper-writing-commands.cjs");
const { listProjectManuscriptVersions, listProjectManuscriptVersionOwners } = require("./paper-writing-history.cjs");
const { registerProjectTransferCommands } = require("./project-transfer-commands.cjs");
const { registerMetricComparisonCommands } = require("./metric-comparison-commands.cjs");
const workspaceFiles = require("./workspace-files.cjs");
const latexWorkspace = require("./latex-workspace.cjs");
const { preparePaperReader } = require("./library-reader.cjs");
const { importLocalPaper } = require("./library-local-import.cjs");
const { loadGithubRepository, normalizeGithubRepositoryUrl } = require("./github-repository.cjs");
const { cloneRepositoryCheckout, getRepositoryCheckout, listRepositoryCheckoutDirectory, readRepositoryCheckoutFile, resolveAuditPath, resolveRepositoryCodeReference } = require("./repository-checkout.cjs");
const { getBenchmarkRadarData } = require("./benchmark-radar.cjs");
const extensionMarketplace = require("./extensions-marketplace.cjs");
const sidebarPlugins = require("./sidebar-plugins.cjs");

let shutdownReproductionRuns = async () => {};
let quitting = false, readyToQuit = false;
const commandSessions = new Map();
const interactiveTerminalSessions = new Map();
const windowWorkspaces = new Map();
const windowPreviewTokens = new Map();
const previewTokenWorkspaces = new Map();
const workspaceWatchers = new Map();
const allowedContextPaths = new Set();
const WORKSPACE_STATE_FILE = "last-workspace.json";
const MAX_CLIPBOARD_IMAGE_BYTES = 6 * 1024 * 1024;
const WORKBENCH_BROWSER_PARTITION = "archimedes-browser";
let browserSessionHardened = false;

app.setName("Archimedes");
app.setAppUserModelId("com.archimedes.research");
protocol.registerSchemesAsPrivileged([
  {
    scheme: "archimedes-file",
    privileges: { standard: true, secure: true, supportFetchAPI: true, stream: true, corsEnabled: true },
  },
  {
    scheme: "archimedes-plugin",
    privileges: { standard: true, secure: true, supportFetchAPI: true, stream: true, corsEnabled: true },
  },
]);

function cleanTerminalEnvironment() {
  return Object.fromEntries(Object.entries({
    ...process.env,
    TERM: "xterm-256color",
    COLORTERM: "truecolor",
    TERM_PROGRAM: "Archimedes",
    TERM_PROGRAM_VERSION: app.getVersion(),
  }).filter(([, value]) => typeof value === "string"));
}

function getInteractiveTerminal(event, sessionId) {
  const session = interactiveTerminalSessions.get(sessionId);
  if (!session || session.senderId !== event.sender.id) throw new Error("Terminal session not found.");
  return session;
}

function closeInteractiveTerminal(sessionId) {
  const session = interactiveTerminalSessions.get(sessionId);
  if (!session) return;
  interactiveTerminalSessions.delete(sessionId);
  try {
    session.process.kill();
  } catch {
    // The shell may already have exited.
  }
}

function closeAllTerminals() {
  for (const sessionId of interactiveTerminalSessions.keys()) closeInteractiveTerminal(sessionId);
  for (const session of commandSessions.values()) session.process.kill("SIGTERM");
  commandSessions.clear();
}

function closeWindowTerminals(senderId) {
  for (const [sessionId, session] of interactiveTerminalSessions) {
    if (session.senderId === senderId) closeInteractiveTerminal(sessionId);
  }
  for (const [sessionId, session] of commandSessions) {
    if (session.senderId !== senderId) continue;
    session.process.kill("SIGTERM");
    commandSessions.delete(sessionId);
  }
}

function stopWorkspaceWatcher(senderId) {
  const current = workspaceWatchers.get(senderId);
  if (!current) return;
  if (current.timer) clearTimeout(current.timer);
  current.watcher.close();
  workspaceWatchers.delete(senderId);
}

function setWindowWorkspace(senderId, workspace) {
  windowWorkspaces.set(senderId, workspace);
  let token = windowPreviewTokens.get(senderId);
  if (!token) {
    token = randomUUID();
    windowPreviewTokens.set(senderId, token);
  }
  previewTokenWorkspaces.set(token, workspace);
  return token;
}

function createPreviewToken(senderId, workspace) {
  // Execution folders (project directories) can differ from the window's data
  // workspace. Preview tokens must not move the window's primary workspace.
  let token = windowPreviewTokens.get(senderId);
  if (!token) {
    token = randomUUID();
    windowPreviewTokens.set(senderId, token);
  }
  previewTokenWorkspaces.set(token, workspace);
  return token;
}

function workspaceStatePath() {
  return path.join(app.getPath("userData"), WORKSPACE_STATE_FILE);
}

function validWorkspace(value) {
  return typeof value === "string" && value.trim() && fs.existsSync(value) && fs.statSync(value).isDirectory();
}

function rememberWorkspace(workspace) {
  if (!validWorkspace(workspace)) return;
  try {
    fs.writeFileSync(workspaceStatePath(), JSON.stringify({ workspace, updatedAt: new Date().toISOString() }, null, 2));
  } catch {
    // The active window still works if user-data storage is temporarily unavailable.
  }
}

function lastWorkspace() {
  try {
    const saved = JSON.parse(fs.readFileSync(workspaceStatePath(), "utf8"));
    return validWorkspace(saved?.workspace) ? saved.workspace : null;
  } catch {
    return null;
  }
}

function startupWorkspace() {
  const saved = lastWorkspace();
  if (saved) return saved;
  // During local development, the application lives inside its default research workspace.
  const developmentWorkspace = process.env.VITE_DEV_SERVER_URL ? path.dirname(app.getAppPath()) : null;
  return validWorkspace(developmentWorkspace) ? developmentWorkspace : null;
}

function watchWorkspace(sender, workspace) {
  stopWorkspaceWatcher(sender.id);
  try {
    const state = { watcher: null, timer: null };
    state.watcher = fs.watch(workspace, { recursive: true }, (_eventType, filename) => {
      const changedPath = String(filename || "").replaceAll("\\", "/");
      if (changedPath.split("/").some((part) => [".archimedes", ".git", "node_modules", "dist", "build", ".next"].includes(part))) return;
      if (state.timer) clearTimeout(state.timer);
      state.timer = setTimeout(() => {
        if (!sender.isDestroyed()) sender.send("workspace:files-changed", { path: changedPath });
      }, 180);
    });
    workspaceWatchers.set(sender.id, state);
  } catch {
    // Recursive watching is not available on every platform; manual refresh remains available.
  }
}

function titleBarOverlay(theme) {
  const dark = theme !== "paper";
  return {
    // Match the 44px main toolbar exactly; a taller overlay makes the native
    // caption buttons (and their hover highlight) spill below the bar.
    color: dark ? "#141414" : "#fffdf8",
    symbolColor: dark ? "#e6e5e0" : "#33332f",
    height: 44,
  };
}

function createWindow(workspace) {
  const overlay = process.platform === "win32";
  const initialTheme = nativeTheme.shouldUseDarkColors ? "charcoal" : "paper";
  const browserWindow = new BrowserWindow({
    show: !overlay,
    width: 1560,
    height: 980,
    minWidth: 1100,
    minHeight: 720,
    backgroundColor: initialTheme === "paper" ? "#f6f7f5" : "#111111",
    titleBarStyle: process.platform === "darwin" ? "hiddenInset" : overlay ? "hidden" : undefined,
    titleBarOverlay: overlay ? titleBarOverlay(initialTheme) : undefined,
    autoHideMenuBar: process.platform !== "darwin",
    icon: windowIconPath(process.platform, app.isPackaged ? process.resourcesPath : undefined),
    webPreferences: {
      preload: path.join(__dirname, "preload.cjs"),
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: true,
      plugins: true,
      webviewTag: true,
    },
  });

  configureWindowIcon(app, browserWindow);
  if (overlay) browserWindow.show();
  if (process.platform !== "darwin") browserWindow.setMenuBarVisibility(false);

  const senderId = browserWindow.webContents.id;
  browserWindow.webContents.on("will-attach-webview", (event, webPreferences, params) => {
    const browserTab = params.partition === WORKBENCH_BROWSER_PARTITION;
    const allowed = browserTab ? isWebPage(params.src) : isEmbeddableProjectPage(params.src);
    if (!allowed) {
      event.preventDefault();
      return;
    }
    if (!browserTab && isGithubPage(params.src)) {
      try {
        const repository = normalizeGithubRepositoryUrl(params.src);
        params.src = repository.url;
      } catch {
        event.preventDefault();
        return;
      }
    }
    delete webPreferences.preload;
    webPreferences.contextIsolation = true;
    webPreferences.nodeIntegration = false;
    webPreferences.sandbox = true;
  });
  browserWindow.webContents.on("did-attach-webview", (_event, guestContents) => {
    const browserTab = guestContents.session === session.fromPartition(WORKBENCH_BROWSER_PARTITION);
    guestContents.setWindowOpenHandler(({ url }) => {
      if (browserTab && isWebPage(url)) void shell.openExternal(url);
      if (!browserTab && isEmbeddableProjectPage(url)) void guestContents.loadURL(url);
      return { action: "deny" };
    });
    guestContents.on("will-navigate", (event, url) => {
      if (!(browserTab ? isWebPage(url) : isEmbeddableProjectPage(url))) event.preventDefault();
    });
    if (browserTab) hardenBrowserSession(guestContents.session);
  });
  if (workspace) setWindowWorkspace(senderId, resolveWorkspace(workspace));

  const devServerUrl = process.env.VITE_DEV_SERVER_URL;
  if (devServerUrl) {
    browserWindow.loadURL(devServerUrl);
  } else {
    browserWindow.loadFile(path.join(__dirname, "..", "dist", "index.html"));
  }

  browserWindow.on("closed", () => {
    closeWindowTerminals(senderId);
    stopWorkspaceWatcher(senderId);
    void presence?.leave(String(senderId));
    const token = windowPreviewTokens.get(senderId);
    if (token) previewTokenWorkspaces.delete(token);
    windowPreviewTokens.delete(senderId);
    windowWorkspaces.delete(senderId);
  });

  return browserWindow;
}

function resolveWorkspace(value) {
  const requested = typeof value === "string" ? value.trim() : "";
  const expanded = requested === "~" || requested.startsWith("~/")
    ? path.join(app.getPath("home"), requested.slice(2))
    : requested;
  if (!expanded) return fs.realpathSync(app.getPath("home"));
  if (fs.existsSync(expanded) && fs.statSync(expanded).isDirectory()) return fs.realpathSync(expanded);
  // Do not silently fall back to the home folder when a project folder was
  // deleted or moved; the user needs to rebind the project instead.
  throw new Error(`The folder "${expanded}" is no longer available. Rebind the project folder and try again.`);
}

function focusedWindow() {
  return BrowserWindow.getFocusedWindow() ?? BrowserWindow.getAllWindows()[0] ?? null;
}

function isGithubPage(value) {
  try {
    const url = new URL(value);
    return url.protocol === "https:" && (url.hostname === "github.com" || url.hostname.endsWith(".github.com"));
  } catch {
    return false;
  }
}

function isEmbeddableProjectPage(value) {
  try {
    return new URL(value).protocol === "https:";
  } catch {
    return false;
  }
}

function isWebPage(value) {
  try {
    const protocol = new URL(value).protocol;
    return protocol === "https:" || protocol === "http:";
  } catch {
    return false;
  }
}

function hardenBrowserSession(session) {
  if (browserSessionHardened) return;
  browserSessionHardened = true;
  session.setPermissionRequestHandler((_contents, _permission, callback) => callback(false));
  session.setPermissionCheckHandler(() => false);
  session.on("will-download", (event, item) => {
    event.preventDefault();
    const url = item.getURL();
    if (isWebPage(url)) void shell.openExternal(url);
  });
}

function workspaceForWindow(browserWindow) {
  return browserWindow ? windowWorkspaces.get(browserWindow.webContents.id) : undefined;
}

function readerStateForWindow(senderId, workspace, paperId, projectId = null) {
  const reader = store.getPaperReader(paperId, projectId);
  if (!reader.asset?.relative_path || reader.asset.status !== "ready") return reader;
  try {
    const target = workspaceFiles.workspacePath(workspace, reader.asset.relative_path);
    if (!fs.statSync(target).isFile()) return { ...reader, asset: { ...reader.asset, status: "missing", error: "The cached PDF is no longer available." } };
    const token = setWindowWorkspace(senderId, workspace);
    return { ...reader, asset: { ...reader.asset, preview_url: `archimedes-file://${token}/${encodeURIComponent(reader.asset.relative_path)}` } };
  } catch {
    return { ...reader, asset: { ...reader.asset, status: "missing", error: "The cached PDF is no longer available." } };
  }
}

async function chooseFolderForWindow(browserWindow, title = "Open Folder") {
  const options = {
    properties: ["openDirectory"],
    title,
    defaultPath: workspaceForWindow(browserWindow) ?? app.getPath("home"),
  };
  const result = browserWindow
    ? await dialog.showOpenDialog(browserWindow, options)
    : await dialog.showOpenDialog(options);
  return result.canceled ? null : resolveWorkspace(result.filePaths[0]);
}

async function openFolderFromMenu() {
  const browserWindow = focusedWindow();
  if (!browserWindow) return;
  const workspace = await chooseFolderForWindow(browserWindow);
  if (!workspace || browserWindow.isDestroyed()) return;
  setWindowWorkspace(browserWindow.webContents.id, workspace);
  rememberWorkspace(workspace);
  browserWindow.webContents.send("menu:open-folder", workspace);
}

function installApplicationMenu() {
  const template = [];
  if (process.platform === "darwin") {
    template.push({
      label: app.name,
      submenu: [
        { role: "about" },
        { type: "separator" },
        { role: "services" },
        { type: "separator" },
        { role: "hide" },
        { role: "hideOthers" },
        { role: "unhide" },
        { type: "separator" },
        { role: "quit" },
      ],
    });
  }

  template.push(
    {
      label: "File",
      submenu: [
        {
          label: "New Window",
          accelerator: "CmdOrCtrl+Shift+N",
          click: () => createWindow(workspaceForWindow(focusedWindow())),
        },
        {
          label: "New Chat",
          accelerator: "CmdOrCtrl+N",
          click: () => focusedWindow()?.webContents.send("menu:new-chat"),
        },
        {
          label: "Open Folder...",
          accelerator: "CmdOrCtrl+O",
          click: () => void openFolderFromMenu(),
        },
        { type: "separator" },
        process.platform === "darwin" ? { role: "close" } : { role: "quit" },
      ],
    },
    { role: "editMenu" },
    { role: "viewMenu" },
    { role: "windowMenu" },
  );

  Menu.setApplicationMenu(Menu.buildFromTemplate(template));
}

function contextItem(type, resourcePath, detail = "") {
  const resolved = path.resolve(resourcePath);
  allowedContextPaths.add(resolved);
  let size;
  try {
    const stats = fs.statSync(resolved);
    if (stats.isFile()) size = stats.size;
  } catch {
    // The caller will surface an unreadable path if it matters.
  }
  return { id: `${type}:${resolved}`, type, name: path.basename(resolved), path: resolved, detail, ...(size === undefined ? {} : { size }) };
}

function installedSkills(workspace) {
  const roots = [
    path.join(workspace, ".agents", "skills"),
    path.join(workspace, ".codex", "skills"),
    path.join(app.getPath("home"), ".agents", "skills"),
    path.join(app.getPath("home"), ".codex", "skills"),
  ];
  const seen = new Set();
  const results = [];
  for (const root of roots) {
    if (!fs.existsSync(root)) continue;
    for (const entry of fs.readdirSync(root, { withFileTypes: true })) {
      if ((!entry.isDirectory() && !entry.isSymbolicLink()) || entry.name.startsWith(".")) continue;
      const skillPath = path.join(root, entry.name);
      const manifest = path.join(skillPath, "SKILL.md");
      if (!fs.existsSync(manifest)) continue;
      const key = fs.realpathSync(skillPath);
      if (seen.has(key)) continue;
      seen.add(key);
      const parsed = skillCatalog.parseSkillDocument(fs.readFileSync(manifest, "utf8"), entry.name);
      const item = contextItem("skill", skillPath, path.relative(workspace, skillPath).startsWith("..") ? "Installed skill" : "Workspace skill");
      item.name = parsed.name || item.name;
      item.description = parsed.description;
      results.push(item);
    }
  }
  for (const skill of skillCatalog.listSkills(workspace)) {
    const key = fs.realpathSync(skill.path);
    if (seen.has(key)) continue;
    seen.add(key);
    const item = contextItem("skill", skill.path, `${skill.collectionName} · ${skill.category}`);
    item.name = skill.name;
    item.description = skill.description;
    results.push(item);
  }
  return results.sort((left, right) => left.name.localeCompare(right.name)).slice(0, 400);
}

function installedPlugins() {
  const cacheRoot = path.join(app.getPath("home"), ".codex", "plugins", "cache");
  if (!fs.existsSync(cacheRoot)) return [];
  const results = [];
  for (const provider of fs.readdirSync(cacheRoot, { withFileTypes: true })) {
    if (!provider.isDirectory() || provider.name.startsWith(".")) continue;
    const providerPath = path.join(cacheRoot, provider.name);
    for (const plugin of fs.readdirSync(providerPath, { withFileTypes: true })) {
      if (!plugin.isDirectory() || plugin.name.startsWith(".")) continue;
      const pluginPath = path.join(providerPath, plugin.name);
      const versions = fs.readdirSync(pluginPath, { withFileTypes: true }).filter((entry) => entry.isDirectory()).map((entry) => entry.name).sort();
      const resolved = versions.length ? path.join(pluginPath, versions.at(-1)) : pluginPath;
      results.push(contextItem("plugin", resolved, provider.name.replace(/^openai-/, "")));
    }
  }
  return results.sort((left, right) => left.name.localeCompare(right.name)).slice(0, 80);
}

async function sanitizeAgentContext(items, workspace) {
  if (!Array.isArray(items)) return [];
  const sanitized = [];
  for (const item of items.slice(0, 12)) {
    if (!item || typeof item !== "object" || typeof item.id !== "string" || typeof item.name !== "string") continue;
    if (item.type === "paper") {
      const paper = item.paper;
      if (!paper || typeof paper.title !== "string") continue;
      sanitized.push({
        id: item.id.slice(0, 500), type: "paper", name: item.name.slice(0, 1000),
        detail: String(item.detail || "").slice(0, 2000),
        paper: {
          title: paper.title.slice(0, 1000), authors: Array.isArray(paper.authors) ? paper.authors.slice(0, 100).map((author) => String(author).slice(0, 300)) : [],
          year: Number.isInteger(paper.year) ? paper.year : null, abstract: String(paper.abstract || "").slice(0, 100_000),
          url: String(paper.url || "").slice(0, 3000), pdfUrl: String(paper.pdfUrl || "").slice(0, 3000),
        },
      });
      continue;
    }
    if (item.type === "repository") {
      const repository = item.repository;
      if (!repository || typeof repository.url !== "string" || !Array.isArray(repository.files)) continue;
      const cleanFiles = repository.files.slice(0, 12).flatMap((file) => {
        if (!file || typeof file.path !== "string" || typeof file.content !== "string") return [];
        return [{ path: file.path.slice(0, 800), size: Math.max(0, Number(file.size) || 0), language: String(file.language || "Text").slice(0, 80), content: file.content.slice(0, 48_000) }];
      });
      let checkout = null;
      if (repository.audit === true) {
        try { checkout = await getRepositoryCheckout(workspace, repository.url); }
        catch { checkout = null; }
      }
      sanitized.push({
        id: item.id.slice(0, 500), type: "repository", name: item.name.slice(0, 1000), detail: String(item.detail || "").slice(0, 2000),
        repository: {
          url: repository.url.slice(0, 3_000), branch: String(repository.branch || "").slice(0, 160), description: String(repository.description || "").slice(0, 4_000),
          language: String(repository.language || "").slice(0, 160), stars: Math.max(0, Number(repository.stars) || 0),
          data_paths: Array.isArray(repository.data_paths) ? repository.data_paths.slice(0, 100).map((entry) => String(entry).slice(0, 800)) : [],
          readme: String(repository.readme || "").slice(0, 20_000), files: cleanFiles,
          checkout: checkout ? { branch: checkout.branch, commit: checkout.commit, file_count: checkout.file_count } : null,
        },
      });
      continue;
    }
    if (item.type === "image") {
      const image = item.image;
      const match = typeof image?.dataUrl === "string" && image.dataUrl.match(/^data:(image\/(?:png|jpeg|webp|gif));base64,([A-Za-z0-9+/=]+)$/);
      if (!match) continue;
      const bytes = Buffer.from(match[2], "base64");
      if (!bytes.length || bytes.length > MAX_CLIPBOARD_IMAGE_BYTES) continue;
      const mimeType = match[1];
      sanitized.push({
        id: item.id.slice(0, 500), type: "image", name: item.name.slice(0, 1000), detail: String(item.detail || "").slice(0, 2000),
        image: {
          dataUrl: `data:${mimeType};base64,${bytes.toString("base64")}`,
          mimeType,
          sizeBytes: bytes.length,
          width: Number.isInteger(image.width) ? Math.max(1, Math.min(image.width, 20_000)) : undefined,
          height: Number.isInteger(image.height) ? Math.max(1, Math.min(image.height, 20_000)) : undefined,
        },
      });
      continue;
    }
    if (!["file", "folder", "plugin", "skill"].includes(item.type) || typeof item.path !== "string") continue;
    const resolved = path.resolve(item.path);
    const resolvedWorkspace = path.resolve(workspace);
    const belongsToWorkspace = resolved === resolvedWorkspace || resolved.startsWith(`${resolvedWorkspace}${path.sep}`);
    if ((!allowedContextPaths.has(resolved) && !belongsToWorkspace) || !fs.existsSync(resolved)) continue;
    const stats = fs.statSync(resolved);
    if (item.type === "file" && !stats.isFile()) continue;
    if (item.type !== "file" && !stats.isDirectory()) continue;
    sanitized.push({ id: `${item.type}:${resolved}`, type: item.type, name: path.basename(resolved), path: resolved, detail: String(item.detail || "").slice(0, 2000) });
  }
  return sanitized;
}

const journeySummariesInFlight = new Map();
let supabaseAuth = null;
let authReady = Promise.resolve();
let collaborationApi = null;
let collaborationServer = null;
let presence = null;
let authFlow = null;
let dailyFigureCache = null;

const singleInstanceLock = app.requestSingleInstanceLock();
if (!singleInstanceLock) {
  app.quit();
} else {
  // A second launch must not open a second process: both would write the same
  // workspace SQLite database and last-workspace file. Focus the first window.
  app.on("second-instance", () => {
    const [existing] = BrowserWindow.getAllWindows();
    if (!existing) return;
    if (existing.isMinimized()) existing.restore();
    existing.show();
    existing.focus();
  });
}

app.whenReady().then(async () => {
  configureAppIcon(app);
  if (!singleInstanceLock) return;
  const ipcMain = createWorkspaceIpc({ ipcMain: electronIpcMain, store,
    workspaceForEvent: (event, channel, args) => channel === "workspace:open"
      ? resolveWorkspace(args[0]) : windowWorkspaces.get(event.sender.id),
  });
  loadLocalAgentEnvironment();
  dailyFigureCache = createDailyFigureCache({ directory: path.join(app.getPath("userData"), "Cache", "daily-figures"), resolveFigure: resolveArxivFigure });
  modelConfig.initializeModelConfig(app.getPath("userData"));
  agentBackendConfig.initialize(app.getPath("userData"));
  webSearch.initializeWebSearch(app.getPath("userData"));
  // Passwords and reproduction tokens share one OS keychain-backed codec; both
  // are useless if the machine cannot encrypt, so both refuse to save instead.
  const secretCodec = {
    encrypt: (value) => (safeStorage.isEncryptionAvailable() ? safeStorage.encryptString(value).toString("base64") : ""),
    decrypt: (value) => {
      try { return safeStorage.decryptString(Buffer.from(value, "base64")); } catch { return ""; }
    },
  };
  sshServers.initialize(app.getPath("userData"), secretCodec);
  reproductionEnv.initialize(app.getPath("userData"), secretCodec);
  terminalSettings.initialize(app.getPath("userData"));
  journeySettings.initialize(app.getPath("userData"));
  journeySnapshots.initialize(app.getPath("userData"));
  workbenchSettings.initialize(app.getPath("userData"));
  workbenchNotes.initialize(app.getPath("userData"));
  extensionMarketplace.initialize(app.getPath("userData"));
  sidebarPlugins.initialize(app.getPath("userData"));
  sidebarSettings.initialize(app.getPath("userData"));
  news.initialize(app.getPath("userData"));
  paperReview.initialize(app.getPath("userData"));
  localIdentity.initialize(app.getPath("userData"));
  store.setLocalIdentity(localIdentity.localIdentity());
  const authStorageValues = new Map();
  const authStorage = {
    getItem: (key) => authStorageValues.get(key) || null,
    setItem: (key, value) => { authStorageValues.set(key, value); },
    removeItem: (key) => { authStorageValues.delete(key); },
  };
  const supabaseClient = createClient(supabaseConfig.url, supabaseConfig.publishableKey, {
    auth: { persistSession: false, autoRefreshToken: false, detectSessionInUrl: false, flowType: "pkce", storage: authStorage },
  });
  supabaseAuth = createSupabaseAuth({
    client: supabaseClient,
    storagePath: app.getPath("userData"),
    safeStorage,
    configured: Boolean(supabaseConfig.url && supabaseConfig.publishableKey),
  });
  authFlow = createAuthFlow({
    client: supabaseClient,
    openExternal: (url) => shell.openExternal(url),
    port: Number(process.env.ARCHIMEDES_AUTH_PORT) || 45871,
  });
  authReady = supabaseAuth.initialize().then(async () => {
    try {
      const response = await fetch(`${supabaseConfig.url}/auth/v1/settings`, { headers: { apikey: supabaseConfig.publishableKey } });
      const settings = response.ok ? await response.json() : {};
      supabaseAuth.setProviders({ email: settings.external?.email !== false, google: Boolean(settings.external?.google), magicLink: process.env.ARCHIMEDES_AUTH_MAGIC_LINK === "1" });
    } catch { /* provider discovery is best effort */ }
    return supabaseAuth.state();
  });
  presence = createPresence({
    createClient,
    supabaseUrl: supabaseConfig.url,
    publishableKey: supabaseConfig.publishableKey,
    getToken: () => supabaseAuth.accessToken(),
  });
  try {
    collaborationServer = createSupabaseServer({ supabaseUrl: supabaseConfig.url, publishableKey: supabaseConfig.publishableKey });
    const address = await collaborationServer.listen(0, "127.0.0.1");
    collaborationApi = createCollaborationApi({
      baseUrl: `http://127.0.0.1:${address.port}`,
      getToken: () => supabaseAuth.accessToken(),
    });
  } catch (error) {
    console.error("Could not start the local collaboration API.", error);
  }
  installApplicationMenu();
  protocol.handle("archimedes-file", (request) => {
    try {
      const url = new URL(request.url);
      const workspace = previewTokenWorkspaces.get(url.hostname);
      if (!workspace) return new Response("Preview token expired.", { status: 403 });
      const relative = decodeURIComponent(url.pathname.slice(1));
      const target = workspaceFiles.workspacePath(workspace, relative);
      if (!fs.statSync(target).isFile()) return new Response("File not found.", { status: 404 });
      return net.fetch(pathToFileURL(target).toString());
    } catch {
      return new Response("File preview unavailable.", { status: 404 });
    }
  });
  protocol.handle("archimedes-plugin", (request) => {
    try {
      const url = new URL(request.url);
      const target = sidebarPlugins.resolvePluginFile(url.hostname, decodeURIComponent(url.pathname.slice(1)));
      if (!target) return new Response("Plugin file not found.", { status: 404 });
      if (fs.statSync(target).size > 5_000_000) return new Response("Plugin file is too large.", { status: 413 });
      const type = path.extname(target).toLowerCase();
      const mime = { ".mjs": "text/javascript", ".js": "text/javascript", ".json": "application/json", ".css": "text/css", ".html": "text/html", ".svg": "image/svg+xml", ".png": "image/png" }[type] ?? "application/octet-stream";
      return new Response(fs.readFileSync(target), {
        headers: { "content-type": mime, "access-control-allow-origin": "*" },
      });
    } catch {
      return new Response("Plugin file unavailable.", { status: 404 });
    }
  });

  ipcMain.handle("app:build-info", () => require("./build-info.cjs").getBuildInfo({
    isPackaged: app.isPackaged, appPath: app.getAppPath(), platform: process.platform, arch: process.arch,
  }));

  ipcMain.handle("window:initial-workspace", (event) => {
    return windowWorkspaces.get(event.sender.id) ?? null;
  });

  ipcMain.handle("window:set-titlebar-theme", (event, theme) => {
    const browserWindow = BrowserWindow.fromWebContents(event.sender);
    if (!browserWindow || browserWindow.isDestroyed()) return;
    const dark = theme !== "paper";
    try {
      browserWindow.setTitleBarOverlay(titleBarOverlay(theme));
    } catch {
      // Linux window managers may not expose an overlay title bar.
    }
    browserWindow.setBackgroundColor(dark ? "#111111" : "#f6f7f5");
  });

  ipcMain.handle("window:set-ui-zoom", (event, factor) => {
    const browserWindow = BrowserWindow.fromWebContents(event.sender);
    const numeric = Number(factor);
    const next = Number.isFinite(numeric) ? Math.min(1.5, Math.max(.75, numeric)) : 1;
    if (browserWindow && !browserWindow.isDestroyed()) browserWindow.webContents.setZoomFactor(next);
    return next;
  });

  ipcMain.handle("workspace:choose", async (event) => {
    return chooseFolderForWindow(BrowserWindow.fromWebContents(event.sender), "Choose a research workspace");
  });

  ipcMain.handle("workspace:watch", (event, requestedWorkspace) => {
    const workspace = resolveWorkspace(requestedWorkspace);
    watchWorkspace(event.sender, workspace);
    return workspace;
  });

  ipcMain.handle("workspace:reveal", async (_event, requestedWorkspace) => {
    if (!validWorkspace(requestedWorkspace)) throw new Error("The folder is no longer available.");
    const error = await shell.openPath(path.resolve(requestedWorkspace));
    if (error) throw new Error(error);
    return { opened: true };
  });

  ipcMain.handle("context:choose-paths", async (event, input = {}) => {
    const kind = input.kind === "folder" ? "folder" : "file";
    const browserWindow = BrowserWindow.fromWebContents(event.sender);
    const options = {
      title: kind === "folder" ? "Add a folder to Archimedes context" : "Add files to Archimedes context",
      defaultPath: resolveWorkspace(input.workspace),
      properties: kind === "folder" ? ["openDirectory", "multiSelections"] : ["openFile", "multiSelections"],
    };
    const result = browserWindow
      ? await dialog.showOpenDialog(browserWindow, options)
      : await dialog.showOpenDialog(options);
    if (result.canceled) return [];
    return result.filePaths.map((selectedPath) => contextItem(kind, selectedPath, path.dirname(selectedPath)));
  });

  ipcMain.handle("context:attach-dropped-paths", async (_event, paths) => {
    if (!Array.isArray(paths) || paths.length > 12 || paths.some((p) => typeof p !== "string" || !path.isAbsolute(p) || p.length > 4000)) throw new Error("Invalid dropped files.");
    return paths.map((p) => {
      const stats = fs.statSync(p);
      if (!stats.isFile() && !stats.isDirectory()) throw new Error("Only files and folders can be attached.");
      return contextItem(stats.isDirectory() ? "folder" : "file", p, path.dirname(p));
    });
  });

  ipcMain.handle("context:attach-repository-path", async (event, { url, workspace, path: filePath } = {}) => {
    if (typeof url !== "string" || url.length > 3000 || typeof filePath !== "string" || !filePath || filePath.length > 2000) throw new Error("Invalid repository path.");
    const resolved = await resolveAuditPath(resolveWorkspace(workspace || windowWorkspaces.get(event.sender.id)), url, filePath);
    const stats = fs.statSync(resolved.target);
    if (!stats.isFile() && !stats.isDirectory()) throw new Error("Only files and folders can be attached.");
    return contextItem(stats.isDirectory() ? "folder" : "file", resolved.target, filePath);
  });

  ipcMain.handle("context:list-resources", (_event, input = {}) => {
    const workspace = resolveWorkspace(input.workspace);
    return input.kind === "plugin" ? installedPlugins() : installedSkills(workspace);
  });

  ipcMain.handle("skills:list-collections", (_event, input = {}) => {
    return skillCatalog.listSkillCollections(resolveWorkspace(input.workspace));
  });

  ipcMain.handle("skills:list", (_event, input = {}) => {
    const skills = skillCatalog.listSkills(resolveWorkspace(input.workspace), input.collectionId);
    for (const skill of skills) allowedContextPaths.add(path.resolve(skill.path));
    return skills;
  });

  ipcMain.handle("skills:read", (_event, input = {}) => {
    const skill = skillCatalog.readSkill(resolveWorkspace(input.workspace), input.skillId);
    allowedContextPaths.add(path.resolve(skill.path));
    return skill;
  });

  ipcMain.handle("extensions:sources-list", () => extensionMarketplace.listSources());
  ipcMain.handle("extensions:sources-save", (_event, sources) => extensionMarketplace.saveSources(sources));
  ipcMain.handle("extensions:sources-reset", () => extensionMarketplace.resetSources());
  ipcMain.handle("extensions:list", (_event, input = {}) => extensionMarketplace.listExtensions({
    workspace: resolveWorkspace(input.workspace),
    limit: input.limit,
    refresh: Boolean(input.refresh),
  }));
  ipcMain.handle("extensions:preview", (_event, input = {}) => extensionMarketplace.previewExtension({
    id: input.id,
    workspace: resolveWorkspace(input.workspace),
  }));
  ipcMain.handle("extensions:install", (_event, input = {}) => extensionMarketplace.installExtension({
    id: input.id,
    workspace: input.workspace ? resolveWorkspace(input.workspace) : "",
    scope: input.scope === "global" ? "global" : "workspace",
    hostVersion: app.getVersion(),
  }));
  ipcMain.handle("extensions:list-installed", (_event, input = {}) => ({
    skills: installedSkills(resolveWorkspace(input.workspace)),
    plugins: installedPlugins(),
    uiPlugins: sidebarPlugins.listPlugins(),
  }));
  ipcMain.handle("plugins:list", () => sidebarPlugins.listPlugins());
  ipcMain.handle("plugins:set-enabled", (_event, input = {}) => sidebarPlugins.setEnabled(String(input?.id || ""), Boolean(input?.enabled)));
  ipcMain.handle("plugins:remove", (_event, input = {}) => sidebarPlugins.removePlugin(String(input?.id || "")));
  ipcMain.handle("sidebar:get-settings", () => sidebarSettings.getSettings());
  ipcMain.handle("sidebar:set-core-enabled", (_event, input = {}) => sidebarSettings.setCoreEnabled(String(input?.id || ""), Boolean(input?.enabled)));
  ipcMain.handle("sidebar:set-layout", (_event, input = {}) => sidebarSettings.setLayout(String(input?.layout || "flat")));
  ipcMain.handle("news:get-settings", () => news.getSettings());
  ipcMain.handle("news:set-settings", (_event, patch = {}) => news.setSettings(patch));
  ipcMain.handle("news:list", (_event, filters = {}) => news.list(filters));
  ipcMain.handle("news:refresh", (_event, input = {}) => news.refresh({ force: Boolean(input?.force) }));
  ipcMain.handle("news:mark-read", (_event, input = {}) => news.markRead(String(input?.id || ""), Boolean(input?.read)));
  ipcMain.handle("news:set-saved", (_event, input = {}) => news.setSaved(String(input?.id || ""), Boolean(input?.saved)));
  ipcMain.handle("paper-review-app:get-settings", () => paperReview.getSettings());
  ipcMain.handle("paper-review-app:save-settings", (_event, patch = {}) => paperReview.saveSettings(patch));
  ipcMain.handle("paper-review-app:list-venues", () => paperReview.listVenues());
  ipcMain.handle("paper-review-app:list-papers", (event, input = {}) => {
    return paperReview.listPapers({ projectId: String(input?.projectId || "") });
  });
  ipcMain.handle("paper-to-slides:stage", (event, input = {}) => {
    const workspace = resolveWorkspace(input.workspace || windowWorkspaces.get(event.sender.id));
    if (input.manuscript) return require("./paper-to-slides.cjs").stageManuscriptPdf(store.currentStore(), workspace, input.path, { manuscript: input.manuscript, threadId: input.threadId });
    return require("./paper-to-slides.cjs").stagePdf(workspace, input.path);
  });
  ipcMain.handle("paper-to-slides:setup", (_event, input = {}) => require("./paper-to-slides-setup.cjs").checkPaperToSlidesSetup(input));
  ipcMain.handle("paper-review-app:choose-pdf", async (event) => {
    const browserWindow = BrowserWindow.fromWebContents(event.sender);
    const options = {
      title: "Choose a paper PDF",
      properties: ["openFile"],
      filters: [{ name: "PDF", extensions: ["pdf"] }],
    };
    const result = browserWindow ? await dialog.showOpenDialog(browserWindow, options) : await dialog.showOpenDialog(options);
    return result.canceled ? "" : result.filePaths[0] || "";
  });
  ipcMain.handle("paper-review-app:create", async (event, input = {}) => {
    const resolvedWorkspace = resolveWorkspace(input?.workspace || windowWorkspaces.get(event.sender.id));
    if (!input.manuscript) {
      const context = resolveResearchContext(store.currentStore(), { projectId: input.projectId, workspace: resolvedWorkspace });
      input = { ...input, projectId: context.projectId };
    }
    const sender = event.sender;
    return paperReview.createRun(input, {
      workspace: resolvedWorkspace,
      dataStore: store.currentStore(),
      emit: (payload) => {
        if (!sender.isDestroyed()) sender.send("paper-review-app:progress", payload);
      },
    });
  });
  const reviewVisible = (run, role = "viewer") => Boolean(run && (!run.ownerDataRoot || run.ownerDataRoot === store.currentStore().workspace)
    && (!run.projectId || store.canAccessProject(run.projectId, role)));
  const requireReview = (runId, role = "viewer") => {
    const run = paperReview.getRun(runId);
    if (!reviewVisible(run, role)) throw new Error("This review is not available in the current project workspace.");
    return run;
  };
  ipcMain.handle("paper-review-app:get-run", (_event, input = {}) => requireReview(String(input?.runId || "")));
  ipcMain.handle("paper-review-app:list-runs", (_event, input = {}) => paperReview.listRuns({ projectId: String(input?.projectId || ""), limit: Number(input?.limit) || 50,
    ownerDataRoot: store.currentStore().workspace }).filter(run => reviewVisible(run)));
  ipcMain.handle("paper-review-app:cancel-run", (_event, input = {}) => { requireReview(String(input?.runId || ""), "editor"); return paperReview.cancelRun(String(input?.runId || "")); });
  ipcMain.handle("paper-review-app:delete-run", (_event, input = {}) => { requireReview(String(input?.runId || ""), "editor"); return paperReview.deleteRun(String(input?.runId || "")); });
  ipcMain.handle("paper-review-app:export-run", async (event, input = {}) => {
    requireReview(String(input?.runId || ""));
    const exported = paperReview.exportRun(String(input?.runId || ""));
    const browserWindow = BrowserWindow.fromWebContents(event.sender);
    const options = {
      title: "Export simulated review",
      defaultPath: path.join(app.getPath("documents"), exported.filename),
      filters: [{ name: "Markdown", extensions: ["md"] }],
    };
    const result = browserWindow ? await dialog.showSaveDialog(browserWindow, options) : await dialog.showSaveDialog(options);
    if (result.canceled || !result.filePath) return { saved: false, path: "" };
    fs.writeFileSync(result.filePath, exported.markdown, "utf8");
    return { saved: true, path: result.filePath };
  });
  ipcMain.handle("extensions:read-local", (_event, input = {}) => {
    const target = path.resolve(String(input.path || ""));
    if (!allowedContextPaths.has(target)) throw new Error("This skill is not available in the current context.");
    const manifest = path.join(target, "SKILL.md");
    if (!fs.existsSync(manifest) || !fs.statSync(manifest).isFile()) throw new Error("SKILL.md was not found for this skill.");
    if (fs.statSync(manifest).size > 500_000) throw new Error("This SKILL.md is too large to preview.");
    return { filename: "SKILL.md", content: fs.readFileSync(manifest, "utf8") };
  });

  ipcMain.handle("workspace:open", (event, requestedWorkspace) => {
    const workspace = resolveWorkspace(requestedWorkspace);
    setWindowWorkspace(event.sender.id, workspace);
    rememberWorkspace(workspace);
    watchWorkspace(event.sender, workspace);
    const snapshot = store.openWorkspace(workspace);
    void reproductionRuns.recoverWorkspace(store.currentStore()).catch(() => {});
    return snapshot;
  });

  ipcMain.handle("workspace:list-files", (_event, input = {}) => {
    const workspace = resolveWorkspace(input.workspace);
    return workspaceFiles.listWorkspaceDirectory(workspace, input.directory);
  });

  ipcMain.handle("workspace:inspect-path", (_event, input = {}) => {
    const workspace = resolveWorkspace(input.workspace);
    return workspaceFiles.inspectWorkspacePath(workspace, input.path);
  });

  ipcMain.handle("workspace:read-file", (event, input = {}) => {
    const workspace = resolveWorkspace(input.workspace);
    const file = workspaceFiles.readWorkspaceFile(workspace, input.path);
    if (file.kind === "pdf" || file.kind === "image") {
      const token = createPreviewToken(event.sender.id, workspace);
      const encodedPath = file.path.split("/").map(encodeURIComponent).join("/");
      return { ...file, previewUrl: `archimedes-file://${token}/${encodedPath}` };
    }
    return file;
  });

  ipcMain.handle("workspace:write-file", (event, input = {}) => {
    const workspace = resolveWorkspace(input.workspace);
    const file = workspaceFiles.writeWorkspaceTextFile(workspace, input.path, input.content);
    if (!event.sender.isDestroyed()) event.sender.send("workspace:files-changed", { path: file.path });
    return file;
  });

  ipcMain.handle("artifacts:list", (_event, input = {}) => store.listArtifacts(input.threadId));
  ipcMain.handle("artifacts:mark-seen", (_event, input = {}) => store.markArtifactsSeen(input.threadId));
  ipcMain.handle("artifacts:unseen-count", (_event, input = {}) => store.countUnseenArtifacts(input.threadId));
  ipcMain.handle("artifacts:delete", (_event, id) => store.deleteArtifact(id));

  ipcMain.handle("paper:list-projects", (_event, input = {}) => {
    return latexWorkspace.listLatexProjects(resolveWorkspace(input.workspace));
  });

  ipcMain.handle("paper:create-project", async (event, input = {}) => {
    const workspace = resolveWorkspace(input.workspace);
    const file = await require("./official-latex-templates.cjs").createPaperProject(workspace, input.directory, input.template, {
      cacheDirectory: require("node:path").join(app.getPath("userData"), "latex-template-cache"),
      fetchImpl: (...args) => net.fetch(...args),
    });
    if (!event.sender.isDestroyed()) event.sender.send("workspace:files-changed", { path: file.path });
    return file;
  });

  ipcMain.handle("paper:create-file", (event, input = {}) => {
    const workspace = resolveWorkspace(input.workspace);
    const file = latexWorkspace.createLatexFile(workspace, input.path);
    if (!event.sender.isDestroyed()) event.sender.send("workspace:files-changed", { path: file.path });
    return file;
  });

  ipcMain.handle("paper:create-directory", (event, input = {}) => {
    const workspace = resolveWorkspace(input.workspace);
    const directory = latexWorkspace.createLatexDirectory(workspace, input.path);
    if (!event.sender.isDestroyed()) event.sender.send("workspace:files-changed", { path: directory.path });
    return directory;
  });

  ipcMain.handle("paper:import-folder", async (event, input = {}) => {
    const workspace = resolveWorkspace(input.workspace);
    const browserWindow = BrowserWindow.fromWebContents(event.sender);
    const options = { title: "Import a LaTeX project folder", properties: ["openDirectory"] };
    const selection = browserWindow
      ? await dialog.showOpenDialog(browserWindow, options)
      : await dialog.showOpenDialog(options);
    if (selection.canceled || !selection.filePaths[0]) return { canceled: true };
    const imported = latexWorkspace.importLatexProject(workspace, selection.filePaths[0]);
    if (!event.sender.isDestroyed()) event.sender.send("workspace:files-changed", { path: imported.directory });
    return { canceled: false, ...imported };
  });

  const managedPaperCompiler = require("./managed-latex-engine.cjs").createManagedCompiler({
    runtimeRoot: require("node:path").join(app.getPath("userData"), "latex-runtime"),
    resolveProxy: (url) => session.defaultSession.resolveProxy(url),
    resourcesPath: app.isPackaged ? process.resourcesPath : undefined,
    fetchImpl: (...args) => net.fetch(...args),
  });

  ipcMain.handle("paper:build-snapshot", (_event, input = {}) => {
    const workspace = resolveWorkspace(input.workspace);
    return require("./manuscript-snapshot.cjs").readManuscriptSnapshot(workspace, input.manifestPath);
  });

  ipcMain.handle("paper:compile", async (event, input = {}) => {
    const workspace = resolveWorkspace(input.workspace);
    const requestId = typeof input.requestId === "string" ? input.requestId.slice(0, 200) : undefined;
    const result = await managedPaperCompiler(workspace, input.path, (stage, log) => {
      if (!event.sender.isDestroyed()) event.sender.send("paper:compile-progress", { workspace, requestId, path: input.path, stage, log });
    });
    if (!result.ok || !result.pdf_path) return result;
    const token = createPreviewToken(event.sender.id, workspace);
    const encodedPath = result.pdf_path.split("/").map(encodeURIComponent).join("/");
    return { ...result, preview_url: `archimedes-file://${token}/${encodedPath}?v=${Date.now()}` };
  });

  ipcMain.handle("research-thread:get", (_event, input = {}) => {
    if (typeof input.threadId !== "string") throw new Error("A research thread ID is required.");
    const workspace = resolveWorkspace(input.workspace);
    store.openWorkspace(workspace);
    return store.getResearchThread(input.threadId);
  });

  ipcMain.handle("research-thread:attachment-image", (event, input = {}) => {
    if (typeof input.threadId !== "string" || typeof input.turnId !== "string") throw new Error("A thread and turn ID are required.");
    const workspace = workspaceForWindow(BrowserWindow.fromWebContents(event.sender)) || resolveWorkspace(input.workspace);
    store.openWorkspace(workspace);
    return store.getResearchTurnImage(input.threadId, input.turnId, input.position);
  });

  ipcMain.handle("research:snapshot", () => store.getSnapshot());
  registerThreadCommands({ ipcMain, store, agent, modelConfig, dialog, BrowserWindow,
    dataWorkspace: (event, input) => workspaceForWindow(BrowserWindow.fromWebContents(event.sender)) || resolveWorkspace(input.workspace),
    nativeBackend: { getConfig: () => agentBackendConfig.get(), compact: (input) => nativeAgent.compactNative({ ...input, runtimeId: store.runtimeThreadId(input.thread.id) }) },
  });
  registerNativeAgentCommands({ ipcMain, store, native: {
    steerNative: (id, text) => nativeAgent.steerNative(store.runtimeThreadId(id), text),
    answerNativeQuestion: (id, questionId, answers) => nativeAgent.answerNativeQuestion(store.runtimeThreadId(id), questionId, answers),
  },
    dataWorkspace: (event, input) => workspaceForWindow(BrowserWindow.fromWebContents(event.sender)) || resolveWorkspace(input.workspace),
  });

  ipcMain.handle("research-project:create", (_event, input = {}) => {
    return store.createResearchProject(input);
  });

  ipcMain.handle("research-project:rename", (_event, input = {}) => {
    if (typeof input.id !== "string") throw new Error("A research project ID is required.");
    return store.renameResearchProject(input.id, input.name);
  });

  ipcMain.handle("research-project:set-workspace", (_event, input = {}) => {
    if (typeof input.id !== "string") throw new Error("A research project ID is required.");
    return store.setResearchProjectWorkspace(input.id, input.workspacePath);
  });

  ipcMain.handle("research-workspace:list", (_event, input = {}) => {
    if (input.projectId != null && typeof input.projectId !== "string") throw new Error("A project ID must be a string.");
    return store.listProjectWorkspaces(input.projectId || null);
  });

  ipcMain.handle("research-workspace:create", (_event, input = {}) => {
    if (typeof input.projectId !== "string" || !input.projectId) throw new Error("A research project is required.");
    return store.createProjectWorkspace({
      projectId: input.projectId,
      kind: input.kind || "shared",
      name: typeof input.name === "string" ? input.name : "",
    });
  });

  ipcMain.handle("research-workspace:rename", (_event, input = {}) => {
    if (typeof input.id !== "string" || !input.id) throw new Error("A workspace ID is required.");
    return store.renameProjectWorkspace(input.id, input.name);
  });

  ipcMain.handle("research-workspace:suggest-name", () => store.suggestProjectWorkspaceName());

  ipcMain.handle("research-workspace:delete", (_event, input = {}) => {
    if (typeof input.id !== "string" || !input.id) throw new Error("A workspace ID is required.");
    return store.deleteProjectWorkspace(input.id);
  });

  ipcMain.handle("research-thread:pin", (_event, input = {}) => {
    if (typeof input.id !== "string" || !input.id) throw new Error("A research thread ID is required.");
    return store.pinResearchThread(input.id, input.pinned !== false);
  });

  ipcMain.handle("research-thread:mark-viewed", (_event, input = {}) => {
    if (typeof input.id !== "string" || !input.id) throw new Error("A research thread ID is required.");
    return store.markResearchThreadViewed(input.id);
  });

  ipcMain.handle("research-project:archive", (_event, input = {}) => {
    if (typeof input.id !== "string") throw new Error("A research project ID is required.");
    return store.archiveResearchProject(input.id, input.archived !== false);
  });

  ipcMain.handle("research-project:delete", (_event, input = {}) => {
    if (typeof input.id !== "string") throw new Error("A research project ID is required.");
    return store.deleteResearchProject(input.id);
  });

  ipcMain.handle("research-thread:archive", (_event, input = {}) => {
    if (typeof input.id !== "string") throw new Error("A research thread ID is required.");
    return store.archiveResearchThread(input.id, input.archived !== false);
  });

  ipcMain.handle("research-thread:delete", (_event, input = {}) => {
    if (typeof input.id !== "string") throw new Error("A research thread ID is required.");
    const result = store.deleteResearchThread(input.id);
    journeySnapshots.remove(input.id);
    return result;
  });

  ipcMain.handle("model-config:get", (_event, role) => modelConfig.getPublicModelConfig(role));
  ipcMain.handle("agent-backend:get", () => agentBackendConfig.get());
  ipcMain.handle("agent-backend:save", (_event, input) => agentBackendConfig.save(input));
  ipcMain.handle("agent-backend:check", (_event, input) => agentBackendConfig.check(input));
  ipcMain.handle("agent-backend:codex-models", (_event, input) => agentBackendConfig.listCodexModelCatalog(input));

  ipcMain.handle("model-config:list-models", (_event, input = {}, role) => modelConfig.listProviderModels(input, role));

  ipcMain.handle("model-config:save", (_event, input = {}, role) => modelConfig.saveModelConfig(input, role));
  ipcMain.handle("speech:transcribe", async (_event, input = {}) => {
    const config = modelConfig.getActiveModelConfig("agent");
    return speech.transcribeSpeech({ audio: input.audio, mimeType: input.mimeType, language: input.language }, config);
  });
  ipcMain.handle("speech:request-permission", async () => {
    if (process.platform !== "darwin") return true;
    const status = systemPreferences.getMediaAccessStatus("microphone");
    if (status === "granted") return true;
    if (status === "denied" || status === "restricted") return false;
    return systemPreferences.askForMediaAccess("microphone");
  });

  ipcMain.handle("model-config:test", (_event, input = {}, role) => modelConfig.testModelConfig(input, role));

  ipcMain.handle("proactive:reply", (_event, input = {}) => proactiveAgent.runProactiveReply(input));
  const figureConfig = (input) => figureForge.resolveFigureConfig(input.connection, modelConfig.getActiveModelConfig("agent"));
  ipcMain.handle("figure-forge:prepare", (_event, input = {}) => figureForge.prepareFigurePlan(input, { config: figureConfig(input), complete: agent.complete }));
  ipcMain.handle("figure-forge:analyze-references", (_event, input = {}) => figureForge.analyzeReferences(input, { config: figureConfig(input), complete: agent.complete }));
  ipcMain.handle("figure-forge:generate-svg", (_event, input = {}) => figureForge.generateSvg(input, { config: figureConfig(input), complete: agent.complete }));
  ipcMain.handle("figure-forge:generate-bitmap", (_event, input = {}) => figureForge.generateBitmap(input, { config: figureConfig(input) }));
  ipcMain.handle("figure-forge:reconstruct", (_event, input = {}) => figureForge.reconstructFigure(input, { config: figureConfig(input), complete: agent.complete }));
  ipcMain.handle("figure-forge:reconstruction-evidence", (_event, input = {}) => figureForge.requestReconstructionEvidence(input, { config: figureConfig(input), complete: agent.complete }));

  ipcMain.handle("proactive:observe", (_event, input = {}) => proactiveAgent.runProactiveObservation(input));

  ipcMain.handle("proactive:screenshot", (event) => proactiveAgent.captureAppWindow(BrowserWindow.fromWebContents(event.sender)));

  ipcMain.handle("ssh:list-servers", () => sshServers.listServers());
  ipcMain.handle("ssh:save-server", (_event, input = {}) => sshServers.saveServer(input));
  ipcMain.handle("ssh:delete-server", (_event, { id } = {}) => sshServers.deleteServer(id));
  ipcMain.handle("ssh:test-server", async (_event, input = {}) => {
    // Accept either a saved id or an unsaved form, so the test button works
    // before the server is written.
    const saved = input?.id ? sshServers.listServers().find((server) => server.id === input.id) : null;
    const target = saved ? { ...saved, ...input } : input;
    return sshServers.testConnection(target);
  });

  ipcMain.handle("web-search:get-config", () => webSearch.getPublicWebSearchConfig());

  ipcMain.handle("web-search:save-config", (_event, input = {}) => webSearch.saveWebSearchConfig(input));

  registerProjectResultCommands({ ipcMain, store });
  registerPaperWritingCommands({ ipcMain, store });
  registerProjectResearchCommands({ ipcMain, store, reviewDbPath: path.join(app.getPath("userData"), "paper-review.sqlite"), listManuscriptVersions: listProjectManuscriptVersions, listManuscriptVersionOwners: listProjectManuscriptVersionOwners });
  registerProjectTransferCommands({ ipcMain, store, dialog, BrowserWindow, reviewDbPath: path.join(app.getPath("userData"), "paper-review.sqlite") });
  registerMetricComparisonCommands({ ipcMain, store, dialog, BrowserWindow });

  ipcMain.handle("library:list", (_event, input = {}) => store.listLibraries(input.projectId ?? null));

  ipcMain.handle("library:create", (_event, input) => {
    if (!input || typeof input.name !== "string" || !input.name.trim() || input.name.length > 120) {
      throw new Error("A library name of at most 120 characters is required.");
    }
    return store.createLibrary(input);
  });

  ipcMain.handle("library:update", (_event, { id, patch }) => {
    if (typeof id !== "string" || !patch || typeof patch !== "object") throw new Error("A library and update payload are required.");
    return store.updateLibrary(id, patch);
  });

  ipcMain.handle("library:delete", (_event, id) => {
    if (typeof id !== "string") throw new Error("A library ID is required.");
    return store.deleteLibrary(id);
  });

  ipcMain.handle("library:list-projects", () => store.listLibraryProjects());

  ipcMain.handle("library:list-papers", (_event, { libraryId, query = "" }) => {
    if (typeof libraryId !== "string" || typeof query !== "string" || query.length > 300) {
      throw new Error("A library ID and a short search query are required.");
    }
    return store.listPapers(libraryId, query);
  });

  ipcMain.handle("library:search-external", (_event, { query, limit }) => searchAcademicPapers(query, limit));

  ipcMain.handle("library:search-conferences", async (event, input = {}) => {
    if (!input || typeof input !== "object") throw new Error("Conference search options are required.");
    const workspace = resolveWorkspace(windowWorkspaces.get(event.sender.id));
    store.openWorkspace(workspace);
    return searchConferencePapers(input, {
      scope: workspace,
      readCache: (key, age) => { store.openWorkspace(workspace); return store.getDailyFeedCache(key, age); },
      writeCache: (key, value) => { store.openWorkspace(workspace); return store.setDailyFeedCache(key, value); },
    });
  });

  ipcMain.handle("library:discover-daily", async (_event, input = {}) => {
    if (!input || typeof input !== "object") throw new Error("Daily discovery options are required.");
    const options = normalizeDailyOptions(input);
    const cacheKey = JSON.stringify(options);
    const cacheTtl = 20 * 60 * 1000;
    if (!input.forceRefresh) {
      const cached = store.getDailyFeedCache(cacheKey, cacheTtl);
      if (cached) return { ...cached, options, cached: true, stale: false };
    }

    try {
      const response = await discoverDailyPapers(options);
      const saved = store.setDailyFeedCache(cacheKey, response);
      return { ...saved, options, cached: false, stale: false };
    } catch (error) {
      const stale = store.getDailyFeedCache(cacheKey);
      if (stale) {
        return {
          ...stale,
          options,
          cached: true,
          stale: true,
          warning: error instanceof Error ? error.message : "Live refresh failed; showing cached papers.",
        };
      }
      throw error;
    }
  });

  ipcMain.handle("library:daily-figure", async (_event, { arxivId, thumbnail = false } = {}) => {
    if (typeof arxivId !== "string" || !arxivId.trim()) throw new Error("An arXiv id is required.");
    return dailyFigureCache.get(arxivId.trim(), { thumbnail: thumbnail === true });
  });

  // Contracts are stored as written. Older ones predate steps, and a partial
  // write should never crash the renderer, so upgrade on the way out.
  const presentReproduction = (record) => {
    if (!record || !record.contract) return record;
    try {
      return { ...record, contract: normalizeContract(record.contract, { paperTitle: record.title }) };
    } catch {
      return record;
    }
  };

  const presentReproductionRun = (run) => {
    if (!run) return null;
    const record = store.getReproduction(run.reproduction_id);
    if (!record) throw new Error("That reproduction does not exist.");
    return { ...run, snapshot_state: snapshotApplicability(run.snapshot, record,
      record.paper_id ? store.getPaperReader(record.paper_id, record.project_id) : null) };
  };
  ipcMain.handle("reproduction:list", (_event, input = {}) => store.listReproductions(input).map(presentReproduction));
  ipcMain.handle("reproduction:list-runs", (_event, { reproductionId, limit } = {}) => {
    if (!store.getReproduction(reproductionId)) throw new Error("That reproduction does not exist.");
    return store.listReproductionRuns(reproductionId, limit).map(presentReproductionRun);
  });
  ipcMain.handle("reproduction:get-run", (_event, { runId } = {}) => presentReproductionRun(store.getReproductionRun(runId)));

  ipcMain.handle("reproduction:create", (_event, input = {}) => {
    const paperId = typeof input.paperId === "string" && input.paperId ? input.paperId : null;
    if (paperId && !store.getPaper(paperId)) throw new Error("That paper does not exist in this workspace.");
    return store.createReproduction({
      projectId: input.projectId,
      workspaceId: input.workspaceId,
      paperId,
      repoUrl: typeof input.repoUrl === "string" ? input.repoUrl : "",
      title: typeof input.title === "string" ? input.title : "",
      source: { kind: paperId ? "paper" : "repo", paper_id: paperId || undefined, repo_url: input.repoUrl || undefined },
      budget: input.budget,
    });
  });

  ipcMain.handle("reproduction:get", (_event, { id } = {}) => {
    if (typeof id !== "string" || !id) throw new Error("A reproduction id is required.");
    const record = presentReproduction(store.getReproduction(id));
    if (!record) return record;
    const run = store.getLatestReproductionRun(record.id);
    return { ...record, run: presentReproductionRun(run), attempts: run ? store.listReproductionAttempts(run.id) : [] };
  });

  ipcMain.handle("reproduction:update", (_event, { id, patch } = {}) => {
    if (typeof id !== "string" || !id) throw new Error("A reproduction id is required.");
    return presentReproduction(store.updateReproduction(id, patch && typeof patch === "object" ? patch : {}));
  });

  ipcMain.handle("reproduction:delete", (_event, { id } = {}) => {
    if (typeof id !== "string" || !id) throw new Error("A reproduction id is required.");
    return store.deleteReproduction(id);
  });

  /**
   * Requirements come from the plan; values come from the encrypted store. The
   * renderer only ever sees whether a name is set, never what it is set to.
   */
  const reproductionEnvItems = (id, owner = store.currentStore()) => {
    const record = presentReproduction(owner.getReproduction(id));
    if (!record) throw new Error("That reproduction does not exist.");
    const stored = reproductionEnv.list(record.id);
    const has = new Map(stored.map((entry) => [entry.name, entry.hasValue]));
    const items = [];
    const seen = new Set();
    for (const requirement of record.contract?.env || []) {
      items.push({
        name: requirement.name,
        reason: requirement.reason || "",
        source: requirement.source || "",
        required: requirement.required !== false,
        hasValue: Boolean(has.get(requirement.name)),
      });
      seen.add(requirement.name);
    }
    for (const entry of stored) {
      if (seen.has(entry.name)) continue;
      items.push({ name: entry.name, reason: "", source: "added by you", required: false, hasValue: entry.hasValue });
    }
    return items;
  };

  ipcMain.handle("reproduction:env-list", (_event, { id } = {}) => {
    if (typeof id !== "string" || !id) throw new Error("A reproduction id is required.");
    return reproductionEnvItems(id);
  });

  ipcMain.handle("reproduction:env-set", (_event, { id, name, value } = {}) => {
    if (typeof id !== "string" || !id) throw new Error("A reproduction id is required.");
    reproductionEnvItems(id);
    reproductionEnv.setValue(id, name, value);
    return reproductionEnvItems(id);
  });

  ipcMain.handle("reproduction:env-remove", (_event, { id, name } = {}) => {
    if (typeof id !== "string" || !id) throw new Error("A reproduction id is required.");
    reproductionEnvItems(id);
    reproductionEnv.removeValue(id, name);
    return reproductionEnvItems(id);
  });

  ipcMain.handle("reproduction:env-test", async (_event, { id, name } = {}) => {
    if (typeof id !== "string" || !id) throw new Error("A reproduction id is required.");
    const key = reproductionEnv.normalizeName(name);
    // The value is read here, in the main process, and never sent to the
    // renderer. Only the identity of the token comes back.
    const value = reproductionEnv.values(id)[key];
    if (!value) throw new Error(`${key} has no saved value.`);
    if (key !== "HF_TOKEN") return { ok: false, detail: "No test is available for this variable yet." };
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), 15_000);
    try {
      return await testHuggingFaceToken(value, { fetchImpl: net.fetch, signal: controller.signal });
    } finally {
      clearTimeout(timer);
    }
  });

  ipcMain.handle("reproduction:preflight", async (event, { id, workspace } = {}) => {
    const record = presentReproduction(store.getReproduction(id));
    if (!record) throw new Error("That reproduction does not exist.");
    if (!record.contract) throw new Error("Generate a plan before checking it.");
    const resolvedWorkspace = resolveWorkspace(workspace || windowWorkspaces.get(event.sender.id));
    const dataWorkspace = workspaceForWindow(BrowserWindow.fromWebContents(event.sender)) || resolvedWorkspace;
    store.openWorkspace(dataWorkspace);
    return runPreflight({
      workspace: dataWorkspace,
      repoUrl: record.contract.repo?.url || record.repo_url,
      branch: record.contract.repo?.branch || "",
      steps: record.contract.steps,
    });
  });

  const notifyRunFinished = (record, summary) => {
    // The user is told when they are not looking; a run that finishes while the
    // window is focused already shows its result on screen.
    try {
      if (!Notification.isSupported()) return;
      if (BrowserWindow.getAllWindows().some((window) => window.isFocused())) return;
      new Notification({ title: `${record.title} stopped`, body: summary || "The run stopped before it finished." }).show();
    } catch {
      // Notifications are best effort and must never fail a run.
    }
  };

  const reproductionModel = () => {
    const active = modelConfig.getActiveModelConfig("agent");
    if (!active.apiKey && active.provider !== "openrouter") {
      throw new Error("Configure the main agent model in Settings before running a reproduction.");
    }
    return active;
  };

  const reproductionRuns = createReproductionRunManager({ store, runPilot, notify: notifyRunFinished,
    environmentItems: reproductionEnvItems,
    recoverResource: async (resource, owner) => {
      if (resource.kind === "docker") {
        await createDockerBackend({ checkoutDir: owner.workspace, name: resource.container, runId: resource.runId, ownerToken: resource.ownerToken }).dispose();
      } else if (resource.kind === "ssh") {
        const server = sshServers.listServers().find(entry => entry.id === resource.serverId);
        if (!server) throw new Error("This run's SSH server is no longer configured. No remote resources were touched.");
        if (server.host !== resource.host || server.user !== resource.user || Number(server.port) !== Number(resource.port)) throw new Error("The SSH connection changed after this run. Its old resources were left untouched.");
        await createSshBackend({ server, runId: resource.runId, ownerToken: resource.ownerToken, resourceRoot: resource.root, resourceEnvPath: resource.envPath || "" }).dispose();
      } else throw new Error("Unknown resource type. It was left untouched.");
    },
  });
  shutdownReproductionRuns = () => reproductionRuns.shutdown();

  ipcMain.handle("reproduction:run", async (event, { id, workspace, projectId, workspaceId, backend: backendKind = "docker", serverId = "" } = {}) => {
    const owner = store.currentStore();
    await reproductionRuns.recoverWorkspace(owner);
    let record = presentReproduction(owner.getReproduction(id));
    if (!record) throw new Error("That reproduction does not exist.");
    if (!record.project_id) {
      if (!projectId || !workspaceId) throw new Error("Select a project workspace before running this older reproduction.");
      record = presentReproduction(owner.bindReproductionContext(id, { projectId, workspaceId }));
    } else if ((projectId && projectId !== record.project_id) || (workspaceId && workspaceId !== record.workspace_id)) throw new Error("This reproduction belongs to a different project workspace.");
    if (!owner.canAccessProject(record.project_id, "editor")) throw new Error("You do not have permission to run this reproduction.");
    if (!record.contract) throw new Error("Generate a plan before running it.");
    const config = reproductionModel(); // Capture the selected model for this run.
    const repoUrl = record.contract.repo?.url || record.repo_url;
    if (!repoUrl) throw new Error("This reproduction has no repository to run against.");
    const dataWorkspace = owner.workspace;
    const wantsSsh = backendKind === "ssh";
    if (!["docker", "ssh"].includes(backendKind)) throw new Error("Unknown reproduction backend.");
    const server = wantsSsh ? sshServers.listServers().find(entry => entry.id === serverId) : null;
    if (wantsSsh && !server) throw new Error("Choose an SSH server before running this reproduction.");
    const secrets = reproductionEnv.values(record.id);
    const session = reproductionRuns.start({ record, backendKind: wantsSsh ? "ssh" : "docker", repoName: repoNameFromUrl(repoUrl),
      send: payload => { if (!event.sender.isDestroyed()) event.sender.send("reproduction:run-event", { ...payload,
        dataRoot: dataWorkspace, projectId: record.project_id, workspaceId: record.workspace_id, reproductionId: record.id }); },
      completion: ({ system, prompt, signal }) => completeJson(config, { system, prompt, signal, maxTokens: 2400, timeoutMs: 180_000 }),
      prepare: async (session, signal) => {
        const branch = session.contract.repo?.branch || "";
        const backendOptions = { signal, runId: session.run.id, ownerToken: session.ownerToken, secrets };
        if (server) {
          let copyFrom = "";
          const local = await session.stage(() => getRepositoryCheckout(dataWorkspace, repoUrl, { branch }).catch(() => null));
          if (local) copyFrom = (await session.stage(() => resolveAuditPath(dataWorkspace, repoUrl, "", branch))).root;
          const backend = session.adoptBackend(() => createSshBackend({ ...backendOptions, server, repoUrl, branch, copyFrom, emit: session.send }));
          owner.updateReproductionRun(session.run.id, { backend: backend.describe(), image: "" });
          session.send({ type: "preparing", detail: `Checking ${server.host}…` });
          const probe = await session.stage(() => backend.probe());
          session.send({ type: "preparing", detail: [probe.os || server.host, `${probe.diskFreeGb} GB free`, probe.docker ? "docker" : "", probe.gpu].filter(Boolean).join(" · ") });
          if (probe.diskFreeGb > 0 && probe.diskFreeGb < 5) throw new Error(`${server.host} has only ${probe.diskFreeGb} GB free. Free some space before running.`);
          const prepared = await session.stage(() => backend.prepare());
          return { checkout: { url: repoUrl, branch: prepared.branch || branch, commit: prepared.commit || null,
            dirty: prepared.dirty ?? null, location: prepared.repo || null, storage: "remote" } };
        }
        session.send({ type: "preparing", detail: "Getting the repository checkout…" });
        const existing = await session.stage(() => getRepositoryCheckout(dataWorkspace, repoUrl, { branch }).catch(() => null));
        if (!existing) {
          session.send({ type: "preparing", detail: branch ? `Cloning ${branch}…` : "Cloning the repository…" });
          await session.stage(() => cloneRepositoryCheckout(dataWorkspace, repoUrl, { branch, signal }));
        }
        const { root } = await session.stage(() => resolveAuditPath(dataWorkspace, repoUrl, "", branch));
        const backend = session.adoptBackend(() => createDockerBackend({ ...backendOptions, checkoutDir: root, dataRoot: dataWorkspace, environment: session.contract.environment }));
        owner.updateReproductionRun(session.run.id, { image: backend.image, backend: backend.describe() });
        session.send({ type: "preparing", detail: `Starting ${backend.image}…` });
        await session.stage(() => backend.prepare());
        return { checkout: await session.stage(() => localCheckoutSnapshot(root, { url: repoUrl, branch, signal })) };
      },
    });
    return { ...presentReproduction(owner.getReproduction(record.id)), run: session.run };
  });

  ipcMain.handle("reproduction:stop", (_event, { id } = {}) => reproductionRuns.stop(String(id || "")));

  ipcMain.handle("reproduction:plan", async (event, { id, workspace, projectId, workspaceId } = {}) => {
    let reproduction = store.getReproduction(id);
    if (!reproduction) throw new Error("That reproduction does not exist.");
    if (!reproduction.project_id) {
      if (!projectId || !workspaceId) throw new Error("Select a project workspace before planning this older reproduction.");
      reproduction = store.bindReproductionContext(id, { projectId, workspaceId });
    } else if ((projectId && projectId !== reproduction.project_id) || (workspaceId && workspaceId !== reproduction.workspace_id)) throw new Error("This reproduction belongs to a different project workspace.");
    if (!reproduction.paper_id) throw new Error("Reproduction planning is only available for papers.");
    const paper = store.getPaper(reproduction.paper_id);
    if (!paper) throw new Error("The paper for this reproduction is missing.");
    const resolvedWorkspace = resolveWorkspace(workspace || windowWorkspaces.get(event.sender.id));
    const dataWorkspace = store.currentStore().workspace;
    store.openWorkspace(dataWorkspace);
    const reader = store.getPaperReader(reproduction.paper_id, reproduction.project_id);
    const review = store.getPaperReview(reproduction.paper_id, reproduction.project_id);
    store.updateReproduction(id, { status: "draft", error: "" });
    const emit = (payload) => {
      if (!event.sender.isDestroyed()) event.sender.send("reproduction:plan-event", { ...payload, reproductionId: id, paperId: reproduction.paper_id,
        dataRoot: dataWorkspace, projectId: reproduction.project_id, workspaceId: reproduction.workspace_id });
    };
    try {
      // A record made from a paper carries the paper's URL (usually arXiv). The
      // code is named inside the paper; use it rather than planning blind.
      let found = findRepositoryUrl({ recordUrl: reproduction.repo_url, paper, pages: reader.pages || [] });
      if (!found.url) {
        // Nothing in the record or the abstract names the code. Ask the agent to
        // search, but accept an answer only when the repository proves itself.
        emit({ type: "planning", detail: "Searching for the repository…" });
        const discovered = await findRepository({
          paper,
          pages: reader.pages || [],
          runAgent: agent.runAgent,
          searcher: githubSearchCandidates,
          workspace: dataWorkspace,
          emit,
        }).catch(() => null);
        if (discovered?.url) {
          found = { url: discovered.url, source: "search" };
        } else if (discovered?.evidence) {
          emit({ type: "warning", detail: discovered.evidence });
        }
      }
      if (found.url && found.url !== reproduction.repo_url) {
        store.updateReproduction(id, { repoUrl: found.url });
        emit({ type: "planning", detail: `Repository found in the ${found.source === "search" ? "web" : "paper"}: ${found.url}` });
      }
      if (found.url && !paper.github_url) {
        // Keep it on the paper so the next reproduction does not search again.
        try { store.updatePaper(paper.id, { github_url: found.url }); } catch { /* not fatal */ }
      }
      const repoUrl = found.url || reproduction.repo_url;
      let repoItem = null;
      if (repoUrl) {
        emit({ type: "planning", detail: "Cloning the repository…" });
        repoItem = await prepareRepositoryItem(dataWorkspace, repoUrl).catch((error) => {
          emit({ type: "warning", detail: `Repository unavailable: ${error instanceof Error ? error.message : "clone failed"}` });
          return null;
        });
      }
      emit({ type: "planning", detail: repoItem ? "Reading the paper and the repository…" : "Reading the paper…" });
      const contract = await planReproduction({
        paper,
        pages: reader.pages || [],
        review: review?.review || review,
        repoUrl,
        repoItem,
        workspace: dataWorkspace,
        runAgent: agent.runAgent,
        emit,
      });
      return presentReproduction(store.updateReproduction(id, { status: "planned", contract, error: "" }));
    } catch (error) {
      const message = error instanceof Error ? error.message : "Planning failed.";
      store.updateReproduction(id, { status: "draft", error: message });
      throw error;
    }
  });

  ipcMain.handle("library:deep-search", async (_event, input = {}) => {
    if (!input || typeof input !== "object") throw new Error("Deep-search input is required.");
    return deepSearchPapers(input, { modelConfig: modelConfig.getActiveModelConfig() });
  });

  ipcMain.handle("benchmark-radar:get-data", () => getBenchmarkRadarData({
    cachePath: path.join(app.getPath("userData"), "benchmark-radar", "public-index.json"),
    seedPath: path.join(__dirname, "assets", "benchmark-radar", "public-index.json"),
  }));

  ipcMain.handle("library:add-paper", (_event, { libraryId, paper, selection }) => {
    if (typeof libraryId !== "string" || !paper || typeof paper.title !== "string" || !paper.title.trim()) {
      throw new Error("Choose a library and a valid paper before importing.");
    }
    if (paper.title.length > 1000 || String(paper.abstract || "").length > 100_000) throw new Error("Paper metadata is too large.");
    return store.addPaper(libraryId, paper, selection);
  });

  ipcMain.handle("library:get-project-selection", (_event, { paperId, projectId }) => store.getProjectPaperSelection(paperId, projectId));
  ipcMain.handle("library:save-project-selection", (_event, { paperId, projectId, patch }) => store.saveProjectPaperSelection(paperId, projectId, patch));
  ipcMain.handle("library:get-bibliography", (_event, { paperId }) => store.getPaperBibliography(paperId));
  ipcMain.handle("library:set-bibliography", (_event, { paperId, patch }) => store.setPaperBibliography(paperId, patch));
  ipcMain.handle("library:repair-metadata", (_event, { paperId, patch }) => store.repairLibraryPaperMetadata(paperId, patch));

  ipcMain.handle("library:import-local-pdf", async (event, { libraryId, workspace } = {}) => {
    if (typeof libraryId !== "string") throw new Error("Choose a library before importing a paper.");
    const resolvedWorkspace = workspaceForWindow(BrowserWindow.fromWebContents(event.sender)) || resolveWorkspace(workspace);
    store.openWorkspace(resolvedWorkspace);
    const browserWindow = BrowserWindow.fromWebContents(event.sender);
    const options = { title: "Import local paper PDF", properties: ["openFile"], filters: [{ name: "PDF", extensions: ["pdf"] }] };
    const result = browserWindow ? await dialog.showOpenDialog(browserWindow, options) : await dialog.showOpenDialog(options);
    if (result.canceled || !result.filePaths[0]) return null;
    return importLocalPaper({ workspace: resolvedWorkspace, libraryId, localPath: result.filePaths[0], store });
  });

  ipcMain.handle("library:update-paper", (_event, { paperId, patch }) => {
    if (typeof paperId !== "string" || !patch || typeof patch !== "object") throw new Error("A paper and update payload are required.");
    return store.updatePaper(paperId, patch);
  });

  ipcMain.handle("library:remove-paper", (_event, { libraryId, paperId }) => {
    if (typeof libraryId !== "string" || typeof paperId !== "string") throw new Error("A library and paper are required.");
    return store.removePaper(libraryId, paperId);
  });

  ipcMain.handle("library:get-reader", (event, { paperId, workspace, projectId } = {}) => {
    if (typeof paperId !== "string") throw new Error("A paper is required.");
    const resolvedWorkspace = resolveWorkspace(workspace || windowWorkspaces.get(event.sender.id));
    store.openWorkspace(resolvedWorkspace);
    return readerStateForWindow(event.sender.id, resolvedWorkspace, paperId, projectId);
  });

  ipcMain.handle("library:get-paper-chat-thread", (_event, { paperId, workspace, projectId } = {}) => {
    if (typeof paperId !== "string") throw new Error("A paper is required.");
    store.openWorkspace(resolveWorkspace(workspace));
    return store.getPaperChatThread(paperId, projectId);
  });

  ipcMain.handle("library:set-paper-chat-thread", (_event, { paperId, threadId, workspace, projectId } = {}) => {
    if (typeof paperId !== "string" || typeof threadId !== "string") throw new Error("A paper and research thread are required.");
    store.openWorkspace(resolveWorkspace(workspace));
    return store.setPaperChatThread(paperId, threadId, projectId);
  });

  ipcMain.handle("library:prepare-reader", async (event, { paperId, workspace, projectId } = {}) => {
    if (typeof paperId !== "string") throw new Error("A paper is required.");
    const resolvedWorkspace = resolveWorkspace(workspace || windowWorkspaces.get(event.sender.id));
    store.openWorkspace(resolvedWorkspace);
    const paper = store.getPaper(paperId);
    if (!paper) throw new Error("Paper not found.");
    try {
      const asset = await preparePaperReader({ workspace: resolvedWorkspace, paper });
      store.replacePaperReaderAsset(paperId, asset);
      return readerStateForWindow(event.sender.id, resolvedWorkspace, paperId, projectId);
    } catch (error) {
      store.setPaperReaderFailed(paperId, error instanceof Error ? error.message : String(error));
      throw error;
    }
  });

  ipcMain.handle("library:attach-reader-pdf", async (event, { paperId, workspace, projectId } = {}) => {
    if (typeof paperId !== "string") throw new Error("A paper is required.");
    const resolvedWorkspace = resolveWorkspace(workspace || windowWorkspaces.get(event.sender.id));
    store.openWorkspace(resolvedWorkspace);
    const paper = store.getPaper(paperId);
    if (!paper) throw new Error("Paper not found.");
    const browserWindow = BrowserWindow.fromWebContents(event.sender);
    const result = browserWindow
      ? await dialog.showOpenDialog(browserWindow, { title: "Attach paper PDF", properties: ["openFile"], filters: [{ name: "PDF", extensions: ["pdf"] }] })
      : await dialog.showOpenDialog({ title: "Attach paper PDF", properties: ["openFile"], filters: [{ name: "PDF", extensions: ["pdf"] }] });
    if (result.canceled || !result.filePaths[0]) return readerStateForWindow(event.sender.id, resolvedWorkspace, paperId, projectId);
    try {
      const asset = await preparePaperReader({ workspace: resolvedWorkspace, paper, localPath: result.filePaths[0] });
      store.replacePaperReaderAsset(paperId, asset);
      return readerStateForWindow(event.sender.id, resolvedWorkspace, paperId, projectId);
    } catch (error) {
      store.setPaperReaderFailed(paperId, error instanceof Error ? error.message : String(error));
      throw error;
    }
  });

  ipcMain.handle("library:find-passages", (_event, { paperId, query, workspace } = {}) => {
    if (typeof paperId !== "string" || typeof query !== "string") throw new Error("A paper and search phrase are required.");
    store.openWorkspace(resolveWorkspace(workspace));
    return store.findPaperPassages(paperId, query);
  });

  ipcMain.handle("library:create-highlight", (_event, { paperId, input, workspace, projectId } = {}) => {
    if (typeof paperId !== "string" || !input || typeof input !== "object") throw new Error("A paper and text selection are required.");
    store.openWorkspace(resolveWorkspace(workspace));
    return store.createPaperHighlight(paperId, input, projectId);
  });

  ipcMain.handle("library:delete-highlight", (_event, { id, workspace, projectId } = {}) => {
    if (typeof id !== "string") throw new Error("A highlight is required.");
    store.openWorkspace(resolveWorkspace(workspace));
    return store.deletePaperHighlight(id, projectId);
  });

  ipcMain.handle("library:translate-selection", async (_event, { text } = {}) => {
    if (typeof text !== "string" || !text.trim() || text.length > 12_000) {
      throw new Error("Select between 1 and 12,000 characters to translate.");
    }
    return agent.translatePaperSelection({ text });
  });

  ipcMain.handle("library:load-github-repository", async (_event, { url } = {}) => {
    if (typeof url !== "string" || url.length > 3_000) throw new Error("A public GitHub repository URL is required.");
    return loadGithubRepository(url);
  });

  ipcMain.handle("library:get-github-repository-checkout", async (event, { url, workspace } = {}) => {
    if (typeof url !== "string" || url.length > 3_000) throw new Error("A public GitHub repository URL is required.");
    const resolvedWorkspace = resolveWorkspace(workspace || windowWorkspaces.get(event.sender.id));
    store.openWorkspace(resolvedWorkspace);
    return getRepositoryCheckout(resolvedWorkspace, url);
  });

  ipcMain.handle("library:clone-github-repository", async (event, { url, workspace } = {}) => {
    if (typeof url !== "string" || url.length > 3_000) throw new Error("A public GitHub repository URL is required.");
    const resolvedWorkspace = resolveWorkspace(workspace || windowWorkspaces.get(event.sender.id));
    store.openWorkspace(resolvedWorkspace);
    return cloneRepositoryCheckout(resolvedWorkspace, url);
  });

  ipcMain.handle("library:list-github-repository-checkout", async (event, { url, workspace, directory } = {}) => {
    if (typeof url !== "string" || typeof directory !== "string" || url.length > 3_000 || directory.length > 2_000) throw new Error("A repository URL and valid directory are required.");
    return listRepositoryCheckoutDirectory(resolveWorkspace(workspace || windowWorkspaces.get(event.sender.id)), url, directory);
  });

  ipcMain.handle("library:read-github-repository-checkout-file", async (event, { url, workspace, path: filePath } = {}) => {
    if (typeof url !== "string" || typeof filePath !== "string" || url.length > 3_000 || filePath.length > 2_000) throw new Error("A repository URL and valid file path are required.");
    return readRepositoryCheckoutFile(resolveWorkspace(workspace || windowWorkspaces.get(event.sender.id)), url, filePath);
  });

  ipcMain.handle("library:resolve-github-repository-reference", async (event, { url, workspace, path: filePath } = {}) => {
    if (typeof url !== "string" || typeof filePath !== "string" || url.length > 3_000 || filePath.length > 2_000) throw new Error("A repository URL and valid file path are required.");
    return resolveRepositoryCodeReference(resolveWorkspace(workspace || windowWorkspaces.get(event.sender.id)), url, filePath);
  });

  ipcMain.handle("clipboard:read-text", () => clipboard.readText().slice(0, 100_000));

  ipcMain.handle("app:open-external", async (_event, url) => {
    if (typeof url !== "string" || url.length > 4_096 || !isWebPage(url)) {
      throw new Error("Only http:// and https:// links can be opened.");
    }
    await shell.openExternal(url);
    return { opened: true };
  });

  ipcMain.handle("clipboard:write-text", (_event, { text } = {}) => {
    if (typeof text !== "string") throw new Error("Clipboard text must be a string.");
    clipboard.writeText(text.slice(0, 100_000));
  });

  ipcMain.handle("clipboard:read-image", () => {
    const image = clipboard.readImage();
    if (image.isEmpty()) return null;
    const png = image.toPNG();
    if (!png.length || png.length > MAX_CLIPBOARD_IMAGE_BYTES) {
      throw new Error("The pasted image must be 6 MB or smaller.");
    }
    const size = image.getSize();
    return {
      dataUrl: `data:image/png;base64,${png.toString("base64")}`,
      mimeType: "image/png",
      sizeBytes: png.length,
      width: size.width,
      height: size.height,
    };
  });

  ipcMain.handle("task:save", (_event, task) => {
    if (!task || typeof task.prompt !== "string" || typeof task.response !== "string") {
      throw new Error("A task requires prompt and response text.");
    }
    if (task.prompt.length > 20_000 || task.response.length > 100_000) {
      throw new Error("Task payload is too large.");
    }
    return store.saveTask(task);
  });

  ipcMain.handle("agent:run", async (event, input) => {
    if (!input || typeof input.prompt !== "string" || !input.prompt.trim() || input.prompt.length > 20_000) {
      throw new Error("An Agent task requires a prompt of at most 20000 characters.");
    }
    const researchModes = new Set(["standard", "research", "create", "free-chat", "idea-spark", "experiment-setup", "paper-generation", "paper-review", "deep-research"]);
    const mode = researchModes.has(input.mode) ? input.mode : "standard";
    const workspace = resolveWorkspace(input.workspace);
    // Research data stays in the window's primary workspace, while the Agent
    // operates inside the project/session folder.
    const dataWorkspace = workspaceForWindow(BrowserWindow.fromWebContents(event.sender)) || workspace;
    store.openWorkspace(dataWorkspace);
    const owner = store.currentStore();
    const context = resolveResearchContext(owner, { ...input, workspace });
    const contextItems = await sanitizeAgentContext(input.contextItems, context.workspace);
    const clientRunId = typeof input.clientRunId === "string" && input.clientRunId ? input.clientRunId : undefined;
    const configuredBackend = agentBackendConfig.get();
    const selectedBackend = input.backend || configuredBackend.backend;
    if (!["api", "codex", "claude", "opencode"].includes(selectedBackend)) throw new Error("Unknown Agent backend.");
    const backend = selectedBackend === "api" ? configuredBackend : { ...configuredBackend, ...configuredBackend.profiles[selectedBackend], backend: selectedBackend };
    const externalBackend = input.origin === "research" && selectedBackend !== "api" ? backend : null;
    if (input.researchSkill != null && !["idea-spark", "paper-to-slides"].includes(input.researchSkill)) throw new Error("Unknown Research skill.");
    if (input.researchSkill === "paper-to-slides" && !["codex", "claude"].includes(selectedBackend)) throw new Error("Paper to Slides requires Codex or Claude Code.");
    if (input.researchSkill && input.origin !== "research") throw new Error("Research skills are available only in Work conversations.");
    if (input.mineruToken != null && (input.researchSkill !== "paper-to-slides" || typeof input.mineruToken !== "string" || input.mineruToken.length > 8192 || /[\r\n]/.test(input.mineruToken))) throw new Error("Invalid MinerU token.");
    const config = externalBackend ? null : modelConfig.getActiveModelConfig();
    const reasoningEffort = externalBackend ? undefined : normalizeReasoningEffort(config, input.reasoningEffort);
    const contextLength = externalBackend ? undefined : normalizeContextLength(config, input.contextLength);
    if (externalBackend && input.threadId && store.getResearchThread(input.threadId).kind === "paper") throw new Error("Paper chat uses the API harness in this version.");
    return runWindowAgent({ sender: event.sender, native: Boolean(externalBackend), run: ({ externalSignal, emit }) => agent.runAgent({
      externalBackend,
      dataStore: owner,
      researchSkill: input.researchSkill,
      mineruToken: input.mineruToken || undefined,
      externalSignal,
      prompt: input.prompt.trim(),
      workspace: context.workspace,
      threadId: typeof input.threadId === "string" && input.threadId ? input.threadId : undefined,
      projectId: context.projectId,
      workspaceId: context.workspaceId,
      visibility: input.visibility === "private" ? "private" : "project",
      mode,
      reasoningEffort,
      contextLength,
      contextItems,
      capabilities: input.capabilities,
      origin: typeof input.origin === "string" && input.origin ? input.origin : undefined,
      title: typeof input.title === "string" && input.title ? input.title : undefined,
      browser: (args, signal, activeThreadId) => browserUse(event.sender, activeThreadId, args, signal),
      emit: (payload) => emit({ ...payload, ...(clientRunId ? { clientRunId } : {}) }),
    }) });
  });

  ipcMain.handle("paper-review:run", async (event, input = {}) => {
    if (typeof input.paper?.id !== "string") throw new Error("A library paper is required.");
    const dataWorkspace = workspaceForWindow(BrowserWindow.fromWebContents(event.sender)) || resolveWorkspace(input.workspace);
    store.openWorkspace(dataWorkspace);
    const paper = store.getPaper(input.paper.id);
    if (!paper) throw new Error("Paper not found.");
    if (input.projectId && !store.canAccessProject(input.projectId, "editor")) throw new Error("You do not have permission to generate a reading in this project.");
    const reader = store.getPaperReader(paper.id, input.projectId);
    if (reader.asset?.status !== "ready" || !reader.asset.relative_path) throw new Error("Prepare or attach the original PDF before starting the reading.");
    const clientRunId = typeof input.clientRunId === "string" ? input.clientRunId.slice(0, 100) : randomUUID();
    const key = JSON.stringify([dataWorkspace, input.projectId || null, paper.id]);
    if (deepReadingRuns.has(key)) throw new Error("This paper already has a reading in progress.");
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(new Error("The reading exceeded its 3-hour time limit. Its saved progress can be resumed.")), 3 * 60 * 60_000);
    const onDestroyed = () => controller.abort(new Error("The reading window was closed. Saved progress can be resumed."));
    event.sender.once("destroyed", onDestroyed);
    deepReadingRuns.set(key, { controller, clientRunId, senderId: event.sender.id });
    try {
      const configuredBackend = agentBackendConfig.get();
      const config = { ...configuredBackend.profiles.codex, backend: "codex" };
      const emit = payload => { if (!event.sender.isDestroyed()) event.sender.send("paper-review:event", { ...payload, clientRunId }); };
      const approve = async ({ command, cwd, reason, signal }) => {
        if (signal?.aborted || controller.signal.aborted || event.sender.isDestroyed() || command.length > 6000) return false;
        const owner = BrowserWindow.fromWebContents(event.sender);
        if (!owner) return false;
        const result = await dialog.showMessageBox(owner, { type: "question", title: "Codex approval", message: "Allow this Codex operation?", detail: `${reason ? `${reason}\n\n` : ""}Directory: ${cwd}\n\n${command}`, buttons: ["Deny", "Allow once"], defaultId: 0, cancelId: 0, noLink: true });
        return result.response === 1 && !signal?.aborted && !controller.signal.aborted;
      };
      const pdfPath = workspaceFiles.workspacePath(dataWorkspace, reader.asset.relative_path);
      const call = createCodexReadingCall({ workspace: dataWorkspace, pdfPath, config, emit, approve });
      const result = await generateDeepReading({ paper, workspace: dataWorkspace,
        pdfPath,
        config, call, projectId: input.projectId, ownerId: localIdentity.localIdentity().userId, deferCheckpointCleanup: true, signal: controller.signal, emit,
      });
      if (controller.signal.aborted) throw controller.signal.reason || new Error("The reading was cancelled.");
      store.openWorkspace(dataWorkspace);
      store.savePaperReview(paper.id, result, input.projectId);
      if (result.checkpointFile) { try { fs.unlinkSync(result.checkpointFile); } catch { /* A stale checkpoint is safe to resume. */ } }
      const { checkpointFile: ignoredCheckpoint, ...savedResult } = result;
      return { ...savedResult, readingHtml: renderDeepReading(result.reading, dataWorkspace, { sourceButtons: true }) };
    } finally {
      clearTimeout(timer); event.sender.removeListener("destroyed", onDestroyed); deepReadingRuns.delete(key);
    }
  });

  ipcMain.handle("paper-deep-reading:cancel", (event, { clientRunId } = {}) => {
    for (const run of deepReadingRuns.values()) if (run.senderId === event.sender.id && run.clientRunId === clientRunId) { run.controller.abort(new Error("The reading was cancelled. Saved progress can be resumed.")); return { cancelled: true }; }
    return { cancelled: false };
  });

  ipcMain.handle("paper-deep-reading:export", async (event, { paperId, workspace, projectId } = {}) => {
    if (typeof paperId !== "string") throw new Error("A paper is required.");
    const dataWorkspace = workspaceForWindow(BrowserWindow.fromWebContents(event.sender)) || resolveWorkspace(workspace);
    store.openWorkspace(dataWorkspace);
    const saved = store.getPaperReview(paperId, projectId);
    if (!saved?.reading) throw new Error("Generate an illustrated reading before exporting.");
    const report = saved.reading;
    const browserWindow = BrowserWindow.fromWebContents(event.sender);
    const options = { title: "Export illustrated paper reading", properties: ["openDirectory", "createDirectory"] };
    const picked = browserWindow ? await dialog.showOpenDialog(browserWindow, options) : await dialog.showOpenDialog(options);
    if (picked.canceled || !picked.filePaths[0]) return { saved: false, path: "" };
    const directory = path.join(picked.filePaths[0], `paper-deep-reading-${Date.now()}-${randomUUID().slice(0, 6)}`);
    const html = renderDeepReading(report, dataWorkspace);
    fs.mkdirSync(path.join(directory, "assets"), { recursive: true });
    for (const asset of report.assets) fs.copyFileSync(workspaceFiles.workspacePath(dataWorkspace, asset.path), path.join(directory, "assets", path.basename(asset.path)));
    fs.writeFileSync(path.join(directory, "paper_report.html"), html);
    for (const lang of ["zh", "en"]) fs.writeFileSync(path.join(directory, `paper_report.${lang}.md`), deepReadingMarkdown(report, lang));
    fs.writeFileSync(path.join(directory, "report.json"), JSON.stringify(report, null, 2));
    return { saved: true, path: directory };
  });

  ipcMain.handle("project:list-members", (_event, { projectId } = {}) => {
    if (typeof projectId !== "string" || !projectId) throw new Error("A project is required.");
    return store.listProjectMembers(projectId);
  });
  ipcMain.handle("project:add-member", (_event, input = {}) => store.addProjectMember(input));
  ipcMain.handle("project:update-member", (_event, { projectId, userId, role } = {}) => store.updateProjectMemberRole(projectId, userId, role));
  ipcMain.handle("project:remove-member", (_event, { projectId, userId } = {}) => store.removeProjectMember(projectId, userId));
  ipcMain.handle("audit:list", (_event, { projectId = null, limit = 100 } = {}) => store.listAuditEvents({ projectId, limit }));

  function requireCollaboration() {
    if (!collaborationApi) throw new Error("The collaboration service is not available. Restart Archimedes and try again.");
    return collaborationApi;
  }

  async function currentCloudEmail() {
    await authReady;
    return supabaseAuth.state().user?.email || "";
  }

  async function syncCloudProject(projectId) {
    const project = store.getResearchProject(projectId);
    if (!project) throw new Error("Research project not found.");
    if (!project.cloud_project_id) throw new Error("Share this project before syncing cloud members.");
    const [members, email] = await Promise.all([
      requireCollaboration().listMembers(project.cloud_project_id),
      currentCloudEmail(),
    ]);
    return { project: store.getResearchProject(projectId), members: store.syncProjectMembersFromCloud(projectId, members, { currentEmail: email }) };
  }

  ipcMain.handle("collab:status", async () => {
    await authReady;
    if (!collaborationApi) return { signedIn: false, user: null, error: "The collaboration service is not available." };
    return collaborationApi.status();
  });
  ipcMain.handle("collab:list-projects", async () => requireCollaboration().listProjects());
  ipcMain.handle("collab:sync-libraries", async (_event, { projectId } = {}) => createLibrarySync({ store, api: requireCollaboration() }).syncProjectLibraries(projectId));
  ipcMain.handle("collab:sync-annotations", async (_event, { projectId } = {}) => {
    await authReady;
    return createAnnotationSync({ store, api: requireCollaboration() }).syncProjectAnnotations(projectId, { currentCloudUserId: supabaseAuth.state().user?.id || "" });
  });
  ipcMain.handle("collab:sync-threads", async (_event, { projectId } = {}) => {
    await authReady;
    return createThreadSync({ store, api: requireCollaboration() }).syncProjectThreads(projectId, {
      currentCloudUserId: supabaseAuth.state().user?.id || "",
      localUserId: localIdentity.localIdentity().userId,
    });
  });
  ipcMain.handle("collab:export-project", async (_event, { projectId } = {}) => requireCollaboration().exportProject(projectId));
  ipcMain.handle("collab:list-remote-audit", async (_event, { projectId } = {}) => requireCollaboration().listAuditEvents(projectId));
  ipcMain.handle("collab:get-shared-document", async (_event, { projectId, key } = {}) => requireCollaboration().getSharedDocument(projectId, key));
  ipcMain.handle("collab:apply-shared-document", async (_event, { projectId, key, update } = {}) => requireCollaboration().applySharedDocumentUpdate(projectId, key, update));
  ipcMain.handle("collab:list-agent-runs", async (_event, { projectId } = {}) => requireCollaboration().listAgentRuns(projectId));
  ipcMain.handle("collab:start-agent-run", async (_event, { projectId, threadId, contextManifest } = {}) => requireCollaboration().startAgentRun(projectId, threadId, contextManifest));
  ipcMain.handle("collab:join-agent-run", async (_event, { runId, role } = {}) => requireCollaboration().joinAgentRun(runId, role));
  ipcMain.handle("collab:enqueue-agent-prompt", async (_event, { runId, body } = {}) => requireCollaboration().enqueueAgentPrompt(runId, body));
  ipcMain.handle("collab:claim-agent-prompt", async (_event, { runId } = {}) => requireCollaboration().claimAgentPrompt(runId));
  ipcMain.handle("collab:finish-agent-run", async (_event, { runId, status } = {}) => requireCollaboration().finishAgentRun(runId, status));
  ipcMain.handle("collab:request-agent-action", async (_event, { projectId, action } = {}) => requireCollaboration().requestAgentAction(projectId, action));
  ipcMain.handle("collab:resolve-agent-action", async (_event, { actionId, approved } = {}) => requireCollaboration().resolveAgentAction(actionId, approved));
  ipcMain.handle("collab:create-share-link", async (_event, { projectId, resourceType = "thread", resourceId, role = "viewer", expiresInDays = 7 } = {}) => {
    return requireCollaboration().createShareLink(projectId, { resourceType, resourceId, role, expiresInDays });
  });
  ipcMain.handle("collab:revoke-share-link", async (_event, { shareId } = {}) => requireCollaboration().revokeShareLink(shareId));
  ipcMain.handle("collab:redeem-share-link", async (_event, { token } = {}) => requireCollaboration().redeemShareLink(token));
  ipcMain.handle("collab:publish-project", async (_event, { projectId } = {}) => {
    const api = requireCollaboration();
    let project = store.getResearchProject(projectId);
    if (!project) throw new Error("Research project not found.");
    if (!store.canAccessProject(projectId, "admin")) throw new Error("You do not have permission to share this project.");
    if (!project.cloud_project_id) {
      const cloud = await api.createProject({ name: project.name, description: project.description });
      project = store.linkResearchProjectToCloud(projectId, cloud.id);
    }
    const warnings = [];
    for (const member of store.listProjectMembers(projectId)) {
      if (member.role === "owner" || !member.email) continue;
      try {
        await api.addMember(project.cloud_project_id, { email: member.email, role: member.role === "owner" ? "admin" : member.role });
      } catch (error) {
        warnings.push(`${member.display_name || member.email}: ${error instanceof Error ? error.message : String(error)}`);
      }
    }
    return { ...(await syncCloudProject(projectId)), warnings };
  });
  ipcMain.handle("collab:sync-project", async (_event, { projectId } = {}) => syncCloudProject(projectId));
  ipcMain.handle("collab:add-member", async (_event, { projectId, email, role = "viewer" } = {}) => {
    const project = store.getResearchProject(projectId);
    if (!project) throw new Error("Research project not found.");
    if (!project.cloud_project_id) throw new Error("Share this project before inviting cloud members.");
    await requireCollaboration().addMember(project.cloud_project_id, { email, role });
    return syncCloudProject(projectId);
  });
  ipcMain.handle("collab:update-member", async (_event, { projectId, userId, role } = {}) => {
    const project = store.getResearchProject(projectId);
    if (!project?.cloud_project_id) throw new Error("This project is not linked to the cloud.");
    await requireCollaboration().updateMember(project.cloud_project_id, userId, role);
    return syncCloudProject(projectId);
  });
  ipcMain.handle("collab:remove-member", async (_event, { projectId, userId } = {}) => {
    const project = store.getResearchProject(projectId);
    if (!project?.cloud_project_id) throw new Error("This project is not linked to the cloud.");
    await requireCollaboration().removeMember(project.cloud_project_id, userId);
    return syncCloudProject(projectId);
  });
  ipcMain.handle("collab:import-project", async (_event, { cloudProjectId } = {}) => {
    const cloudProject = await requireCollaboration().getProject(cloudProjectId);
    const project = store.importCloudProject({
      cloudProjectId: cloudProject.id,
      name: cloudProject.name,
      description: cloudProject.description,
    });
    return syncCloudProject(project.id);
  });

  ipcMain.handle("comments:list", (_event, { workspace, projectId, resourceType, resourceId, includeResolved = true } = {}) => {
    if (workspace) store.openWorkspace(resolveWorkspace(workspace));
    return store.listComments({ projectId, resourceType, resourceId, includeResolved });
  });
  ipcMain.handle("comments:create", (_event, { workspace, projectId, resourceType, resourceId, body, parentId, anchor } = {}) => {
    if (workspace) store.openWorkspace(resolveWorkspace(workspace));
    return store.createComment({ projectId, resourceType, resourceId, body, parentId, anchor });
  });
  ipcMain.handle("comments:resolve", (_event, { workspace, id, resolved = true } = {}) => {
    if (workspace) store.openWorkspace(resolveWorkspace(workspace));
    return store.setCommentResolved(id, resolved);
  });
  ipcMain.handle("comments:delete", (_event, { workspace, id } = {}) => {
    if (workspace) store.openWorkspace(resolveWorkspace(workspace));
    return store.deleteComment(id);
  });

  ipcMain.handle("research-thread:set-visibility", (_event, { threadId, visibility } = {}) => {
    if (typeof threadId !== "string" || !threadId) throw new Error("A research thread is required.");
    return store.setResearchThreadVisibility(threadId, visibility);
  });
  ipcMain.handle("research-thread:create-snapshot", (_event, { threadId } = {}) => {
    if (typeof threadId !== "string" || !threadId) throw new Error("A research thread is required.");
    return store.createThreadSnapshot(threadId);
  });
  ipcMain.handle("research-thread:list-snapshots", (_event, { threadId } = {}) => {
    if (typeof threadId !== "string" || !threadId) throw new Error("A research thread is required.");
    return store.listThreadSnapshots(threadId);
  });
  ipcMain.handle("research-thread:get-snapshot", (_event, snapshotId) => store.getThreadSnapshot(snapshotId));

  ipcMain.handle("paper-review:get", (event, { paperId, workspace, projectId } = {}) => {
    if (typeof paperId !== "string" || !paperId) throw new Error("A paper ID is required to restore an evidence review.");
    const resolvedWorkspace = resolveWorkspace(workspace || windowWorkspaces.get(event.sender.id));
    const dataWorkspace = workspaceForWindow(BrowserWindow.fromWebContents(event.sender)) || resolvedWorkspace;
    store.openWorkspace(dataWorkspace);
    const saved = store.getPaperReview(paperId, projectId);
    if (!saved?.reading) return saved;
    try {
      const digest = store.getPaperReader(paperId, projectId).asset?.sha256;
      return { ...saved, ...(digest && digest !== saved.reading.sourceDigest ? { readingWarning: "The original PDF has changed since this reading. Read again to update its evidence." } : {}), readingHtml: renderDeepReading(saved.reading, dataWorkspace, { sourceButtons: true }) };
    }
    catch (error) { return { ...saved, readingError: error.message || String(error) }; }
  });

  ipcMain.handle("paper-presentation:run", async (event, input) => {
    if (!input?.paper || typeof input.paper.id !== "string" || typeof input.paper.title !== "string") {
      throw new Error("A paper record is required to generate a presentation.");
    }
    const workspace = resolveWorkspace(input.workspace);
    const dataWorkspace = workspaceForWindow(BrowserWindow.fromWebContents(event.sender)) || workspace;
    store.openWorkspace(dataWorkspace);
    const requestedSourceMode = input.sourceMode === "paper" ? "paper" : "review";
    const review = store.getPaperReview(input.paper.id, input.projectId);
    if (requestedSourceMode === "review" && !review) {
      throw new Error("Finish and save the text review, or choose Generate from original paper.");
    }
    const config = modelConfig.getActiveModelConfig();
    const reasoningEffort = normalizeReasoningEffort(config, input.reasoningEffort || "high");
    const contextLength = normalizeContextLength(config, input.contextLength || "extra-long");
    const contextItems = await sanitizeAgentContext(input.contextItems, workspace);
    const presentationLanguage = input.language === "en" ? "en" : "zh";
    const paper = {
      id: input.paper.id,
      title: input.paper.title.slice(0, 1_000),
      authors: Array.isArray(input.paper.authors) ? input.paper.authors.slice(0, 50).map((author) => String(author).slice(0, 300)) : [],
      year: Number.isInteger(input.paper.year) ? input.paper.year : null,
      venue: String(input.paper.venue || "").slice(0, 1_000),
      abstract: String(input.paper.abstract || "").slice(0, 12_000),
      url: String(input.paper.url || "").slice(0, 4_000),
      pdf_url: String(input.paper.pdf_url || "").slice(0, 4_000),
    };
    const reader = store.getPaperReader(paper.id);
    if (reader.asset?.status !== "ready" || !reader.asset.relative_path) {
      throw new Error("Prepare or attach the original paper PDF before generating a presentation.");
    }
    const sourcePdfPath = workspaceFiles.workspacePath(dataWorkspace, reader.asset.relative_path);
    const clientRunId = typeof input.clientRunId === "string" ? input.clientRunId.slice(0, 100) : "";
    const emitPresentation = (detail, extra = {}) => {
      if (!event.sender.isDestroyed()) event.sender.send("paper-presentation:event", { paperId: paper.id, clientRunId, detail, ...extra });
    };
    emitPresentation(requestedSourceMode === "paper" ? "Reading the original paper and planning the presentation…" : "Reading the paper and saved review to plan the presentation…");
    const result = await (requestedSourceMode === "paper" ? runPaperPresentationPlan : runKimiSlidesPlan)({
      paper,
      review: requestedSourceMode === "review" ? review : null,
      pageCount: Math.max(0, Math.min(5_000, Number(input.pageCount) || 0)),
      workspace,
      projectId: typeof input.projectId === "string" && input.projectId ? input.projectId : undefined,
      contextItems,
      reasoningEffort,
      contextLength,
      browser: (args, signal, activeThreadId) => browserUse(event.sender, activeThreadId, args, signal),
      language: presentationLanguage,
    });
    const presentationPlan = { ...result.presentation, generation_mode: requestedSourceMode };
    const artifact = await generateNativePptx({ paper, plan: presentationPlan, workspace: dataWorkspace,
      sourcePdfPath, emit: emitPresentation,
      onPage: async (page) => {
        const token = createPreviewToken(event.sender.id, dataWorkspace);
        const previewUrl = `archimedes-file://${token}/${page.pdfPath.split("/").map(encodeURIComponent).join("/")}?v=${Date.now()}`;
        emitPresentation(`Page ${page.index + 1} of ${page.total} is ready to view.`, {
          kind: "page-ready",
          page: { ...page, preview_url: previewUrl },
          presentation: {
            title: presentationPlan.title,
            subtitle: presentationPlan.subtitle,
            source_sufficiency: presentationPlan.source_sufficiency,
            generation_mode: presentationPlan.generation_mode,
            slides: presentationPlan.slides,
          },
        });
      } });
    const sourceMarker = requestedSourceMode === "review"
      ? review.updated_at
      : `paper:${reader.asset.updated_at || reader.asset.sha256 || "prepared"}`;
    const saved = store.savePaperPresentation(paper.id, { ...presentationPlan, artifact }, sourceMarker, input.projectId);
    const token = createPreviewToken(event.sender.id, dataWorkspace);
    return { ...saved, artifact: { ...saved.artifact,
      preview_url: `archimedes-file://${token}/${saved.artifact.pdf_path.split("/").map(encodeURIComponent).join("/")}?v=${Date.now()}` } };
  });

  ipcMain.handle("paper-presentation:get", (event, { paperId, workspace, projectId } = {}) => {
    if (typeof paperId !== "string" || !paperId) throw new Error("A paper ID is required to restore a presentation.");
    const resolvedWorkspace = resolveWorkspace(workspace || windowWorkspaces.get(event.sender.id));
    const dataWorkspace = workspaceForWindow(BrowserWindow.fromWebContents(event.sender)) || resolvedWorkspace;
    store.openWorkspace(dataWorkspace);
    const saved = store.getPaperPresentation(paperId, projectId);
    if (!saved?.artifact || !["pptd", "pptx"].includes(saved.artifact.kind)) return saved;
    try {
      workspaceFiles.workspacePath(dataWorkspace, saved.artifact.pdf_path);
      const token = createPreviewToken(event.sender.id, dataWorkspace);
      return { ...saved, artifact: { ...saved.artifact,
        preview_url: `archimedes-file://${token}/${saved.artifact.pdf_path.split("/").map(encodeURIComponent).join("/")}?v=${Date.now()}` } };
    } catch {
      return { ...saved, artifact: { ...saved.artifact, missing: true } };
    }
  });

  ipcMain.handle("paper-presentation:reveal", (event, { paperId, workspace, projectId } = {}) => {
    if (typeof paperId !== "string" || !paperId) throw new Error("A paper ID is required to locate a presentation.");
    const resolvedWorkspace = resolveWorkspace(workspace || windowWorkspaces.get(event.sender.id));
    const dataWorkspace = workspaceForWindow(BrowserWindow.fromWebContents(event.sender)) || resolvedWorkspace;
    store.openWorkspace(dataWorkspace);
    const artifact = store.getPaperPresentation(paperId, projectId)?.artifact;
    if (!artifact || !["pptd", "pptx"].includes(artifact.kind)) throw new Error("This paper has no saved presentation.");
    const pptxPath = workspaceFiles.workspacePath(dataWorkspace, artifact.pptx_path);
    if (!fs.existsSync(pptxPath)) throw new Error("The saved presentation file is missing.");
    shell.showItemInFolder(pptxPath);
  });

  ipcMain.handle("paper-review:cleanup-internal-runs", (event, { workspace } = {}) => {
    const resolvedWorkspace = resolveWorkspace(workspace || windowWorkspaces.get(event.sender.id));
    store.openWorkspace(resolvedWorkspace);
    return store.deleteInternalPaperReviewThreads();
  });

  ipcMain.handle("model-config:capabilities", (_event, role) => getModelCapabilities(modelConfig.getActiveModelConfig(role)));

  ipcMain.handle("agent:approve-action", (event, actionId) => {
    if (typeof actionId !== "string") throw new Error("An Agent action ID is required.");
    let action;
    try { action = store.approveAction(actionId); }
    catch (error) {
      if (error.code === "WORKSPACE_CONFLICT") {
        store.resolveAction(actionId, "rejected");
        agent.resolveApproval(actionId, false, "file_changed_while_awaiting_approval");
      }
      throw error;
    }
    agent.resolveApproval(actionId, true);
    if (action.kind === "write" && action.payload.change && !event.sender.isDestroyed()) {
      event.sender.send("workspace:change-set", {
        id: action.id,
        actionId: action.id,
        taskId: action.task_id,
        threadId: store.getResearchThreadIdForTask(action.task_id),
        kind: action.kind,
        changes: [action.payload.change],
        createdAt: action.created_at,
      });
    }
    return action;
  });

  ipcMain.handle("agent:reject-action", (_event, actionId) => {
    if (typeof actionId !== "string") throw new Error("An Agent action ID is required.");
    const action = store.resolveAction(actionId, "rejected");
    agent.resolveApproval(actionId, false);
    return action;
  });

  ipcMain.handle("agent:claim-approvals", (_event, threadId, claimed) => {
    if (typeof threadId !== "string" || !threadId) throw new Error("A research thread ID is required.");
    return { claimed: agent.setApprovalSurface(threadId, Boolean(claimed)) };
  });

  ipcMain.handle("agent:interrupt", (_event, threadId) => {
    if (typeof threadId !== "string") throw new Error("A research thread ID is required.");
    return { interrupted: agent.interruptAgent(threadId) };
  });

  ipcMain.handle("terminal:run", (event, { command, cwd, actionId }) => {
    if (typeof command !== "string" || command.trim().length === 0 || command.length > 2000) {
      throw new Error("A non-empty command of at most 2000 characters is required.");
    }

    const workspace = resolveWorkspace(cwd);
    const beforeSnapshot = typeof actionId === "string" ? workspaceFiles.snapshotWorkspace(workspace) : null;
    const sessionId = randomUUID();
    const owner = store.currentStore();
    const commandRun = owner.startCommand({ command, cwd: workspace });
    const shell = process.platform === "win32" ? "cmd.exe" : "/bin/zsh";
    const args = process.platform === "win32" ? ["/d", "/s", "/c", command] : ["-lc", command];
    const child = spawn(shell, args, { cwd: workspace, env: process.env });
    const captured = owner.captureStore();

    commandSessions.set(sessionId, { process: child, senderId: event.sender.id });
    const send = (data) => {
      owner.appendCommandOutput(commandRun.id, data);
      if (!event.sender.isDestroyed()) {
        event.sender.send("terminal:data", { sessionId, commandRunId: commandRun.id, data });
      }
    };
    child.stdout.on("data", (chunk) => send(chunk.toString()));
    child.stderr.on("data", (chunk) => send(chunk.toString()));
    child.on("error", (error) => send(`\n[process error] ${error.message}\n`));
    child.on("close", (code) => {
      try {
        send(`\n[process exited with code ${code ?? "unknown"}]\n`);
        owner.finishCommand(commandRun.id, code, code === 0 ? "completed" : "failed");
        if (beforeSnapshot && typeof actionId === "string") {
          const changes = workspaceFiles.compareWorkspaceSnapshots(beforeSnapshot, workspaceFiles.snapshotWorkspace(workspace));
          if (changes.length) {
            const action = owner.updateActionPayload(actionId, { changes });
            if (!event.sender.isDestroyed()) {
              event.sender.send("workspace:change-set", {
                id: action.id,
                actionId: action.id,
                taskId: action.task_id,
                threadId: owner.getResearchThreadIdForTask(action.task_id),
                kind: action.kind,
                changes,
                createdAt: action.created_at,
              });
            }
          }
        }
      } finally {
        commandSessions.delete(sessionId);
        captured.release();
      }
    });
    return { sessionId, commandRunId: commandRun.id, workspace };
  });

  ipcMain.handle("terminal:stop", (event, sessionId) => {
    const session = commandSessions.get(sessionId);
    if (session?.senderId === event.sender.id) session.process.kill("SIGTERM");
  });

  ipcMain.handle("journey:get-settings", () => journeySettings.journeySettings());
  ipcMain.handle("auth:get-state", () => authReady.then(() => supabaseAuth.state()));
  ipcMain.handle("auth:providers", () => authReady.then(() => supabaseAuth.state().providers));
  ipcMain.handle("auth:magic-link", async (_event, { email } = {}) => {
    await authReady;
    if (!String(email || "").trim()) throw new Error("Enter your email address.");
    const result = await authFlow.run({
      mode: "signin",
      trigger: (redirectTo) => supabaseAuth.sendMagicLink(email, redirectTo),
    });
    return supabaseAuth.setSession(result.session);
  });
  ipcMain.handle("auth:sign-up-flow", async (_event, { email, password, displayName } = {}) => {
    await authReady;
    const result = await authFlow.run({
      mode: "signup",
      trigger: async (redirectTo) => supabaseAuth.signUp(email, password, displayName, { emailRedirectTo: redirectTo }),
    });
    return supabaseAuth.setSession(result.session);
  });
  ipcMain.handle("auth:oauth", async (_event, { provider } = {}) => {
    await authReady;
    const providers = supabaseAuth.state().providers;
    if (provider !== "google" || !providers?.google) throw new Error("Google sign-in is not configured for this project.");
    const result = await authFlow.run({
      mode: "signin",
      trigger: async (redirectTo) => ({ url: await supabaseAuth.startOAuth("google", redirectTo) }),
    });
    return supabaseAuth.setSession(result.session);
  });
  ipcMain.handle("auth:reset-password", async (_event, { email } = {}) => {
    await authReady;
    if (!String(email || "").trim()) throw new Error("Enter your email address.");
    const result = await authFlow.run({
      mode: "recovery",
      trigger: (redirectTo) => supabaseAuth.sendPasswordReset(email, redirectTo),
    });
    return { ...(await supabaseAuth.setSession(result.session)), recovery: true };
  });
  ipcMain.handle("auth:update-password", async (_event, { password } = {}) => {
    await authReady;
    if (String(password || "").length < 8) throw new Error("Use at least 8 characters.");
    return supabaseAuth.updatePassword(password);
  });
  ipcMain.handle("auth:update-profile", async (_event, { displayName } = {}) => {
    await authReady;
    return supabaseAuth.updateProfile(displayName);
  });
  ipcMain.handle("auth:resend-confirmation", async (_event, { email } = {}) => {
    await authReady;
    const result = await authFlow.run({
      mode: "signup",
      trigger: (redirectTo) => supabaseAuth.resendConfirmation(email, redirectTo),
    });
    return supabaseAuth.setSession(result.session);
  });
  ipcMain.handle("auth:sign-in", async (_event, { email, password } = {}) => {
    await authReady;
    return supabaseAuth.signIn(email, password);
  });
  ipcMain.handle("auth:sign-up", async (_event, { email, password, displayName } = {}) => {
    await authReady;
    return supabaseAuth.signUp(email, password, displayName);
  });
  ipcMain.handle("auth:sign-out", async () => {
    await authReady;
    return supabaseAuth.signOut();
  });
  ipcMain.handle("auth:access-token", async () => {
    await authReady;
    return supabaseAuth.accessToken();
  });
  ipcMain.handle("presence:join", async (event, { projectId, threadId = null } = {}) => {
    await authReady;
    const user = supabaseAuth.state().user;
    if (!user) throw new Error("Sign in to see live collaborators.");
    if (!presence) throw new Error("Presence is not available.");
    await presence.join(String(event.sender.id), projectId, {
      userId: user.id,
      displayName: user.displayName || user.email,
      email: user.email,
      threadId,
    }, (members) => {
      if (!event.sender.isDestroyed()) event.sender.send("presence:update", members);
    });
    return { joined: true };
  });
  ipcMain.handle("presence:update", async (event, { threadId = null } = {}) => {
    await presence?.update(String(event.sender.id), { thread_id: threadId });
    return { updated: true };
  });
  ipcMain.handle("presence:leave", async (event) => {
    await presence?.leave(String(event.sender.id));
    return { left: true };
  });
  ipcMain.handle("identity:get", () => localIdentity.localIdentity());
  ipcMain.handle("identity:update", (_event, patch = {}) => {
    const identity = localIdentity.updateLocalIdentity({ displayName: patch.displayName });
    store.setLocalIdentity(identity);
    return identity;
  });
  ipcMain.handle("workbench:get-settings", () => workbenchSettings.workbenchSettings());
  ipcMain.handle("workbench:save-settings", (_event, input = {}) => workbenchSettings.saveWorkbenchSettings(input));
  ipcMain.handle("workbench:reset-settings", () => workbenchSettings.resetWorkbenchSettings());
  ipcMain.handle("workbench:get-note", (_event, key) => workbenchNotes.getNote(key));
  ipcMain.handle("workbench:save-note", (_event, input = {}) => workbenchNotes.saveNote(input.key, input.content));
  ipcMain.handle("workbench:delete-note", (_event, key) => workbenchNotes.deleteNote(key));
  ipcMain.handle("journey:get-summary", (_event, threadId) => journeySnapshots.get(String(threadId || "")));
  ipcMain.handle("journey:clear-summary", (_event, threadId) => { journeySnapshots.remove(String(threadId || "")); return { cleared: true }; });
  ipcMain.handle("journey:summarize", async (_event, input = {}) => {
    const threadId = String(input.threadId || "").trim();
    if (!threadId) throw new Error("A thread is required to summarize a journey.");
    const inFlight = journeySummariesInFlight.get(threadId);
    if (inFlight) return inFlight;
    const settings = journeySettings.journeySettings();
    const previous = journeySnapshots.get(threadId);
    if (!settings.liveSummaries && !input.force) return previous;
    if (previous && Number(previous.coversTo) === Number(input.coversTo) && !input.force) return previous;
    const task = journeySummarizer.summarizeJourney({ input: { ...input, threadId }, settings, previous })
      .then((snapshot) => journeySnapshots.save(snapshot))
      .finally(() => journeySummariesInFlight.delete(threadId));
    journeySummariesInFlight.set(threadId, task);
    return task;
  });
  ipcMain.handle("journey:save-settings", (_event, input = {}) => journeySettings.saveJourneySettings(input));
  ipcMain.handle("journey:reset-settings", () => journeySettings.resetJourneySettings());

  ipcMain.handle("terminal:get-settings", () => terminalSettings.terminalSettings());
  ipcMain.handle("terminal:save-settings", (_event, input = {}) => terminalSettings.saveTerminalSettings(input));
  ipcMain.handle("terminal:open-external", (_event, input = {}) => terminalSettings.openExternalTerminal(input));

  ipcMain.handle("terminal:create", (event, input = {}) => {
    const workspace = resolveWorkspace(input.cwd);
    const cols = Math.max(2, Math.min(500, Number(input.cols) || 80));
    const rows = Math.max(1, Math.min(200, Number(input.rows) || 24));
    const { shell, args } = terminalSettings.shellLaunch();
    const sessionId = randomUUID();
    const terminalProcess = pty.spawn(shell, args, {
      name: "xterm-256color",
      cols,
      rows,
      cwd: workspace,
      env: cleanTerminalEnvironment(),
    });
    const session = { process: terminalProcess, senderId: event.sender.id, sender: event.sender, ready: false, buffer: "" };
    interactiveTerminalSessions.set(sessionId, session);

    terminalProcess.onData((data) => {
      if (!interactiveTerminalSessions.has(sessionId)) return;
      if (!session.ready) {
        session.buffer = (session.buffer + data).slice(-200_000);
      } else if (!session.sender.isDestroyed()) {
        session.sender.send("terminal:pty-data", { sessionId, data });
      }
    });
    terminalProcess.onExit(({ exitCode, signal }) => {
      interactiveTerminalSessions.delete(sessionId);
      if (!session.sender.isDestroyed()) session.sender.send("terminal:pty-exit", { sessionId, exitCode, signal });
    });

    event.sender.once("destroyed", () => closeInteractiveTerminal(sessionId));
    return { sessionId, workspace, shell: path.basename(shell), pid: terminalProcess.pid };
  });

  ipcMain.handle("terminal:ready", (event, sessionId) => {
    const session = getInteractiveTerminal(event, sessionId);
    session.ready = true;
    if (session.buffer && !session.sender.isDestroyed()) {
      session.sender.send("terminal:pty-data", { sessionId, data: session.buffer });
      session.buffer = "";
    }
  });

  ipcMain.on("terminal:write", (event, { sessionId, data }) => {
    if (typeof data !== "string" || data.length > 65_536) return;
    try {
      getInteractiveTerminal(event, sessionId).process.write(data);
    } catch {
      // Ignore input racing with a shell exit.
    }
  });

  ipcMain.on("terminal:resize", (event, { sessionId, cols, rows }) => {
    const width = Math.max(2, Math.min(500, Number(cols) || 80));
    const height = Math.max(1, Math.min(200, Number(rows) || 24));
    try {
      getInteractiveTerminal(event, sessionId).process.resize(width, height);
    } catch {
      // Ignore resize events racing with a shell exit.
    }
  });

  ipcMain.handle("terminal:close", (event, sessionId) => {
    getInteractiveTerminal(event, sessionId);
    closeInteractiveTerminal(sessionId);
  });

  createWindow(startupWorkspace());
});

app.on("window-all-closed", () => {
  if (process.platform !== "darwin") app.quit();
});

app.on("activate", () => {
  if (BrowserWindow.getAllWindows().length === 0) createWindow(startupWorkspace());
});

app.on("before-quit", (event) => {
  if (readyToQuit) return;
  event.preventDefault();
  if (quitting) return;
  quitting = true;
  closeAllNativeClients();
  closeAllTerminals();
  void Promise.resolve().then(() => Promise.allSettled([shutdownReproductionRuns(), agent.shutdownAgents()])).finally(() => {
    collaborationServer?.close?.();
    void presence?.closeAll();
    store.closeAllWorkspaces();
    readyToQuit = true;
    app.quit();
  });
});
